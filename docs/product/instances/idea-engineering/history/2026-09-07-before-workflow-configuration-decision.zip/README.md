# IDEA Engineering Product-Definition Instance Set

This directory contains the controlled working instances for the internal IDEA Engineering product.
The instruction-only class templates remain under [`docs/product/definition`](../../definition/README.md)
and are not edited as product content.

## Baseline

| Field | Value |
|---|---|
| Baseline ID | `IDEA-C1-ANALYSIS-DESIGN-001` |
| Purpose | Analysis and design through `PG4`; no production implementation authorization |
| Product boundary | Internal IDEA Engineering `C1` product |
| Principal author | `Principal Product Author` — assistant prepares the documents; accountable attribution must be recorded before `Proposed` |
| Internal document reviewer | Project user; this assignment does not establish required independent/specialist qualification |
| Product decision authority | The boss, acting as `Product Decision Authority`, decides Feature, Spec and Tech |
| Editable authority | English Markdown source under version control |
| Boss-facing language | Vietnamese decision briefs, with common technical terms retained |
| Current Core source versions | DOC-04/05/06 and DOC-07 at `Draft 0.4`; DOC-01/03/08 at `Draft 0.3`; DOC-02 at `Draft 0.2`; GOV at `Draft 0.3`; VVP at `Draft 0.5`; CHG records at `Draft 0.1` |
| First approved version | `Approved 1.0` only after the applicable controlled decision |

## December 2026 roadmap package

[DOC-07 section 3.2](DOC-07-mvp-roadmap-and-delivery-plan.md#32-december-2026-schedule-and-task-appendix)
now contains the conditional 7 September–31 December 2026 plan: **56 tasks / 676 work hours +
80 contingency hours = 756 hours**, with 11 proposed Saturdays and external prerequisites still
to confirm.

- [Appendix A — task details, outputs, hours and dependencies](planning/DOC-07-appendix-A-task-breakdown-december-2026.md)
- [Interactive Gantt — unchanged captured schedule view](planning/idea-roadmap-december-2026.html)
- [Change record — retained predecessor, source hashes and review limitations](registers/CHG-2026-09-05-roadmap-task-integration.md)

The appendix belongs to DOC-07, not a ninth Core Product Document or a competing Spec Kit execution
plan. The Gantt is a rendition of the same schedule, not a separate planning authority. This update
does not authorize coding or change any Feature/Spec/Tech decision or product-gate state.

FEATURE-001@0.6 now refers to DOC-07@0.4 and the current requirement source. Existing Word/Human
copies remain the submitted editorial versions and are not silently regenerated from this Markdown
update. A new decision packet must identify its exact source versions.

## Two-layer reading model

The eight Core Product Documents are the detailed internal authority. The Product Decision
Authority is not expected to read all eight. Three briefs present the features, testable
requirements and justified technology choices, and pin the exact source versions they use.

| Boss-facing brief | Decision axis | Detailed source set | Current state |
|---|---|---|---|
| [`FEATURE-001`](decision-briefs/FEATURE-001-feature-definition-and-scope.md) | Feature scope and priority | DOC-01, DOC-02, DOC-03, DOC-04, DOC-07 and governed reference coverage | `Draft 0.6`; 14 feature IDs; Version semantics and CAD-derived representations clarified; full new-version review and boss decision `NOT-RUN` |
| [`SPEC-001`](decision-briefs/SPEC-001-product-specification.md) | Required behavior and acceptance | DOC-04, requirement-bearing DOC-06/08 content, VVP | `Draft 0.8`; 68 unchanged requirements; SR-01…06 and CR-01…05 cases added; seven Spec points remain open; full review and boss decision `NOT-RUN` |
| [`TECH-001`](decision-briefs/TECH-001-technology-and-architecture-proposal.md) | Architecture and technology selection | DOC-02, DOC-04/05/06/08, accepted ADRs, confirmed context and official technology sources | `Draft 0.5`; per-CAD Adapter/worker and manual fallback clarified; full internal review and boss decision `NOT-RUN`; no selected production stack |

A brief is a controlled decision view, not a second requirement or architecture authority. It
becomes `Stale` when a pinned source changes. A boss decision must identify the exact brief and
source baseline; the author then records its consequences in the affected Core Product Documents.

## Current context, review and retained versions

The user's Tech-context confirmation “Duyệt” on 2026-09-03 accepts the planning inputs recorded in
[IE-CHG-TECH-001](registers/CHG-2026-09-03-tech-context-and-proposal.md), not a stack or implementation
decision. The proposal now reflects Windows engineering PCs, approximately 50–100 intended users
at one site, administrator-issued IDEA accounts first, initial account administration by the user,
and possible user-led operations without an assumed DevOps team. Company login is a future method,
not an initial prerequisite. File volumes are unmeasured. RTO ≤4 working hours and RPO ≤1 hour are
preliminary evaluation objectives, not a tested SLA or rollout acceptance.

The project user previously accepted Feature 0.3 and Spec 0.4 in internal review:
[RVW-FEATURE-SPEC-20260903-001](decision-briefs/VERSION-HISTORY.md#5-ghi-nhận-review-nội-bộ-ngày-03-09-2026).
That result remains attached to those exact versions. It does not automatically apply to Feature
0.6, Spec 0.8 or Tech 0.5. The Version-model point was separately confirmed on 04-09-2026, but the
complete successor briefs still require review.

The [version history](decision-briefs/VERSION-HISTORY.md) records current source hashes, prior
review inputs and a verified [pre-change source archive](history/2026-09-03-before-tech-context.zip).
No retained historical brief was overwritten. Earlier Spec 0.3 acceptance remains withdrawn.

`SPEC-OPEN-01` is recorded as resolved: Versions within each Revision are numbered `1, 2, 3…`,
while Generation is the exact immutable snapshot; there is no additional Version Sequence field.
The seven records `SPEC-OPEN-02…08` remain open. A complete draft does not imply that these gaps,
product tests or gates have passed.

## Staged-release clarification — 7 September 2026

[SPEC-001 section 8.1](decision-briefs/SPEC-001-product-specification.md#81-phát-hành-cụm-bơm-trước-tủ-điện-tiếp-tục-thiết-kế)
now explains releasing the completed pump while the cabinet and whole-machine records remain
In Work. [VVP section 1.2](registers/VVP-core-v0-verification-validation-plan.md#12-staged-release-acceptance-detail)
owns six planned procedures under the existing VVP-005/006 objectives. They distinguish an unrelated
sibling from a required dependency, check commit-time eligibility and rollback, and reproduce the
original package after later edits. All results remain `NOT-RUN`.

The user confirmed the scenario direction and requested this documentation update. It created no
new FTR/REQ IDs and, at that update point, left DOC-04@0.3 and all other Core document contents unchanged. See
[IE-CHG-STAGED-RELEASE-001](registers/CHG-2026-09-07-staged-release-scenario.md) for the predecessor
archive and exact scope.

## CAD Representation clarification — 7 September 2026

[SPEC-001 section 8.2](decision-briefs/SPEC-001-product-specification.md#82-tạo-pdf-từ-cad-và-giữ-đúng-bản-nguồn)
and [VVP section 1.3](registers/VVP-core-v0-verification-validation-plan.md#13-cad-representation-acceptance-detail)
now define automatic and manual PDF/neutral-file paths through the same Representation boundary.
The output pins the exact source Generation and digest, records producer versions, becomes
`Needs update` after source advance, and affects Release only through a versioned policy.

Core v0 does not assume a universal CAD renderer or require an in-application add-in. The exact
IRONCAD version, export path, converter, license, execution host, corpus and limits remain part of
`SPEC-OPEN-04` and VVP-008 qualification. Public reference-product evidence and its limits are kept
in [IE-KNW-DDM-004](../../knowledge/2026-09-07-ddm-cad-neutral-representation-evidence.md). See
[IE-CHG-CAD-REP-001](registers/CHG-2026-09-07-cad-neutral-representation.md) for the accepted design
direction, predecessor archive and exact source impact.

Current brief pins are reconciled for this decision, while retained Core planning/UX references
still need routine refresh before a complete decision packet is called current:

| Retained source | Reference awaiting refresh |
|---|---|
| FEATURE-001@0.6, SPEC-001@0.8 and TECH-001@0.5 | Current DOC-04/05/06 and VVP pins are recorded in each brief. Full review and boss decisions remain `NOT-RUN`. |
| DOC-07@0.4 and DOC-08@0.3 | Retain earlier decision-status/VVP references. Their roadmap and interaction contents are unchanged; refresh references before the next complete decision packet. |
| Existing Word/Human copies | Retain the submitted/editorial versions; this Markdown scenario addition has not been exported to Word. |

## Core instance catalogue

| Class | Stable Document ID | Instance | Current state |
|---|---|---|---|
| `DOC-01` | `IE-PROD-VISION-001` | [Product Vision and Scope](DOC-01-product-vision-and-scope.md) | `Draft 0.3` |
| `DOC-02` | `IE-PROD-FEAS-001` | [Feasibility and Options Assessment](DOC-02-feasibility-and-options-assessment.md) | `Draft 0.2` |
| `DOC-03` | `IE-PROD-BREQ-001` | [Business Requirements](DOC-03-business-requirements.md) | `Draft 0.3` |
| `DOC-04` | `IE-PROD-SREQ-001` | [Software Requirements Specification](DOC-04-software-requirements-specification.md) | `Draft 0.4`; CAD Representation paths and Release-policy behavior clarified |
| `DOC-05` | `IE-PROD-ARCH-001` | [Architecture Description](DOC-05-architecture-description.md) | `Draft 0.4`; per-format Adapter/worker boundary clarified |
| `DOC-06` | `IE-PROD-DATA-001` | [Data, Integration and Migration Specification](DOC-06-data-integration-and-migration-specification.md) | `Draft 0.4`; Representation provenance and freshness clarified |
| `DOC-07` | `IE-PROD-ROADMAP-001` | [MVP Roadmap and Delivery Plan](DOC-07-mvp-roadmap-and-delivery-plan.md) | `Draft 0.4`; conditional December schedule, 56-task appendix and Gantt |
| `DOC-08` | `IE-PROD-UX-001` | [UI/UX and Interaction Specification](DOC-08-ui-ux-and-interaction-specification.md) | `Draft 0.3` |

## Supporting instance catalogue

| Class | Stable Record ID | Instance | Current state |
|---|---|---|---|
| `GOV` | `IE-GOV-COVERAGE-001` | [Material and Behavioral Coverage Register](registers/GOV-material-and-behavioral-coverage.md) | `Draft 0.3`; 16/16 public-baseline areas have explicit dispositions, not implementation coverage; target-runtime evidence remains `BLOCKED` |
| `VVP` | `IE-VVP-CORE-001` | [Core v0 Verification and Validation Plan](registers/VVP-core-v0-verification-validation-plan.md) | `Draft 0.5`; 15 objectives, including SR-01…06 and CR-01…05; execution `NOT-RUN` |
| `CHG` | `IE-CHG-TECH-001` | [Tech Context and Proposal Change Record](registers/CHG-2026-09-03-tech-context-and-proposal.md) | `Draft 0.1`; context source, material impact, retained versions and pending review |
| `CHG` | `IE-CHG-VERSION-001` | [Version Model Clarification Change Record](registers/CHG-2026-09-04-version-model-clarification.md) | `Draft 0.1`; closes SPEC-OPEN-01 for internal drafting; boss decision remains `NOT-RUN` |
| `CHG` | `IE-CHG-ROADMAP-001` | [Roadmap and Task Integration](registers/CHG-2026-09-05-roadmap-task-integration.md) | `Draft 0.1`; DOC-07@0.4 and schedule@0.1; planning only |
| `CHG` | `IE-CHG-STAGED-RELEASE-001` | [Staged Release Scenario](registers/CHG-2026-09-07-staged-release-scenario.md) | `Draft 0.1`; Spec@0.7 / VVP@0.4; acceptance clarification, no runtime results |
| `CHG` | `IE-CHG-CAD-REP-001` | [CAD Neutral Representation](registers/CHG-2026-09-07-cad-neutral-representation.md) | `Draft 0.1`; Feature@0.6 / Spec@0.8 / Tech@0.5 and Core/VVP alignment; no runtime results |

The [technology research note](../../../research/2026-09-03-idea-tech-stack-primary-sources.md)
supports the proposal with official sources and their limitations. Source research is not a
compatibility test, license approval or an IDEA product decision.

## Authoring and decision sequence

1. Review the successor Feature/Spec additions and Tech proposal; keep unresolved inputs explicit.
2. Record Feature → Spec → Tech decisions against the exact versions presented to the boss.
3. Obtain the required company deployment, security, operational and specialist dispositions;
   qualify the proposed stack, account boundary, file/format behavior and recovery design.
4. Update DOC-07 and the required GOV, CLR, RSK, VVP, VEV, CMP and CHG records for `PG4` readiness.
5. Start production implementation only after the approved requirements, architecture and increment
   readiness satisfy the applicable gates.

No item in this directory currently records a boss approval or a product-gate `PASS`.
