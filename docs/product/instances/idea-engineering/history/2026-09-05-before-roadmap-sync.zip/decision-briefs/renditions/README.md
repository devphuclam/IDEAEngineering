# Bản Word trình quyết định

Thư mục này chứa các bản Word để sếp đọc và quyết định theo ba trục **Feature**, **Spec** và
**Tech**. Các file Markdown tương ứng vẫn là nguồn nội dung có thẩm quyền. Các bản xuất ban đầu
và các bản được trình bày lại từ file Word hiện có được phân biệt bên dưới.

## Bản đồng bộ quyết định về Version — 04/09/2026

Ba bản dưới đây là **bản sao mới** từ các file Word mà người dùng đã chỉnh. Không file Word đầu
vào nào bị ghi đè. Phần được đồng bộ chỉ là quyết định đã chốt ngày 04/09/2026: mỗi Revision dùng
một Version bắt đầu từ 1; Check-in có thay đổi tăng Version đúng một lần và tạo một Generation;
No Change không tăng số; Revision mới bắt đầu lại từ Version 1. Generation tiếp tục là mã kỹ thuật
để lấy đúng snapshot. Toàn bộ Feature, Spec và Tech chưa được coi là đã được sếp phê duyệt.

| Trục | Bản Word mới | Số trang | Rendition ID |
|---|---|---:|---|
| Feature | [FEATURE-001-v0.5-bia-muc-luc.docx](FEATURE-001-v0.5-bia-muc-luc.docx) | 9 | REN-FEATURE-001-0.5-DOCX-20260904-03 |
| Spec | [SPEC-001-v0.6-bia-muc-luc.docx](SPEC-001-v0.6-bia-muc-luc.docx) | 20 | REN-SPEC-001-0.6-DOCX-20260904-03 |
| Tech | [TECH-001-v0.4-bia-muc-luc.docx](TECH-001-v0.4-bia-muc-luc.docx) | 12 | REN-TECH-001-0.4-DOCX-20260904-03 |

| Trục | SHA-256 nguồn Markdown | SHA-256 file Word đầu vào | SHA-256 bản Word mới |
|---|---|---|---|
| Feature | `a9dde0ee7732ab8dc600780095cde97c599b69f6db3974025e17a2b2d15d346c` | `f7ec986537224cafa8f4b7c54182b1c411a87f19f227aea69eefaac93855aef9` | `ace9203922e254b73f8ddcd95ad60917259e2d413282b3572c96b9d8e3766717` |
| Spec | `09190e4079c19df1cd70fc6237431d1180ccb029f21dae84a48e72d0d1d2543b` | `af596c4a2cc82b1bdde74e64d4d1da6f144e436a319f12739bd76eda256d4bb6` | `b75f7281f3e5b391999f34635af94276f4fb3a5abdc720f8ab634e112bfa681a` |
| Tech | `c07a2c4324558f749ead9c217709e033413739b71161cbcb810f782ef18ea72d` | `6b7f4f808ffddea3f6f06f12a518f4cec82de3b9c4961827cc0260cb84344888` | `e8cd61bcff4d8d1da3bb5e0784a0ec258932d59f4451ec18b07ca4961fa903e3` |

Phạm vi chỉnh sửa được ghi ngay trong trang “Kiểm soát bản Word” của từng file:

- **Feature 0.5:** cập nhật FTR-002, phần giải thích Version/Generation, nguồn tham chiếu, lịch sử
  và mục lục; giữ nguyên 14 mã tính năng và phần người dùng đã chỉnh.
- **Spec 0.6:** cập nhật khái niệm, REQ-ID-002, VVP-001, ví dụ, trạng thái SPEC-OPEN-01, nguồn,
  lịch sử và mục lục. SPEC-OPEN-02…08 vẫn còn mở.
- **Tech 0.4:** cập nhật phiên bản và các nguồn được ghim; không đổi đề xuất công nghệ, phương án
  kiến trúc hoặc điều kiện kiểm chứng.

Kiểm tra bản đồng bộ:

- Ba gói DOCX mở được và không có thành phần ZIP hỏng; không có lỗi field hoặc trường dữ liệu
  `Version Sequence`; mục lục và số trang đã được cập nhật.
- Microsoft Word 16.0 đã xuất bản kiểm tra và toàn bộ **41/41 trang** đã được xem: Feature 9,
  Spec 20 và Tech 12 trang; không thấy chữ bị cắt, chồng lấn hoặc trang trắng thừa.
- Kiểm tra hỗ trợ tiếp cận tự động không có lỗi mức cao. Ba cảnh báo mức trung bình còn lại là
  bảng bố cục trạng thái/sơ đồ kiến trúc, không phải bảng dữ liệu cần hàng tiêu đề.
- Máy hiện tại không có LibreOffice; kiểm tra trực quan bằng Word là đường kiểm tra thay thế,
  không được ghi thành kết quả của bộ render LibreOffice.
- PDF, ảnh và script kiểm tra chỉ nằm trong thư mục tạm. Kiểm thử sản phẩm và quyết định của sếp
  vẫn `NOT-RUN`.

## Bản có trang bìa và mục lục trước lần đồng bộ — 04/09/2026

Ba bản dưới đây bổ sung trang bìa theo mẫu người dùng cung cấp, mục lục có liên kết và số trang,
cùng thông tin bản xuất. Nội dung chính và các liên kết được giữ nguyên từ **file Word hiện có**;
không tạo lại từ Markdown để tránh mất chỉnh sửa của người dùng. Ba file đầu vào được giữ nguyên.

| Trục | Bản Word có bìa và mục lục | Số trang | Rendition ID |
|---|---|---|---|
| Feature | [FEATURE-001-v0.4-bia-muc-luc.docx](FEATURE-001-v0.4-bia-muc-luc.docx) | 10 | REN-FEATURE-001-0.4-DOCX-20260904-02 |
| Spec | [SPEC-001-v0.5-bia-muc-luc.docx](SPEC-001-v0.5-bia-muc-luc.docx) | 20 | REN-SPEC-001-0.5-DOCX-20260904-02 |
| Tech | [TECH-001-v0.3-bia-muc-luc.docx](TECH-001-v0.3-bia-muc-luc.docx) | 12 | REN-TECH-001-0.3-DOCX-20260904-02 |

| Trục | SHA-256 file Word đầu vào hiện có | SHA-256 bản có bìa và mục lục |
|---|---|---|
| Feature | `96abc3b09e8fb240b4ea398c8a2ed5fead77f2a3ee82f1797f7056c631c28ddd` | `e7dfb4c8e87d316b065224171923080c25e8131f60e6f787ef5ff2117131d158` |
| Spec | `eb0f45cc027560b67cd1912abbd8d79585e9551227359f183d1617b6bd64c9bd` | `af596c4a2cc82b1bdde74e64d4d1da6f144e436a319f12739bd76eda256d4bb6` |
| Tech | `9b5ddc9b424981175666bf109b55ee9b8e8f5bb978cdc41bc1e0ae47d44d0a5a` | `6b7f4f808ffddea3f6f06f12a518f4cec82de3b9c4961827cc0260cb84344888` |

Các SHA-256 trong bảng trên là dấu tại thời điểm tạo bản đó. Sau đó người dùng tiếp tục chỉnh
`FEATURE-001-v0.4-bia-muc-luc.docx`; SHA-256 hiện tại của file này là
`f7ec986537224cafa8f4b7c54182b1c411a87f19f227aea69eefaac93855aef9`. File đã chỉnh này được giữ
nguyên và dùng làm đầu vào cho Feature 0.5 ở mục trên. Không gán trạng thái `Current` so với
Markdown cho bản lịch sử và không ghi nhận một quyết định phê duyệt mới.

Kiểm tra lần trình bày này:

- Đã đối chiếu nội dung chính và liên kết trước/sau; SHA-256 của ba file đầu vào không đổi.
- Đã cập nhật mục lục bằng Microsoft Word 16.0, kiểm tra đủ 15/34/16 mục tương ứng
  Feature/Spec/Tech và đối chiếu số trang với vị trí thật của từng tiêu đề.
- Đã kiểm tra trực quan toàn bộ 42 trang xuất từ Word; không thấy chữ bị cắt, chồng lấn hoặc trang
  trắng thừa. Mỗi bản có trang bìa, một trang mục lục và nội dung bắt đầu từ trang 3.
- Bộ render mặc định vẫn không chạy được do thiếu LibreOffice; đây là kiểm tra thay thế bằng
  Microsoft Word, không phải kết quả của bộ render LibreOffice.
- Kiểm tra hỗ trợ tiếp cận tự động: không có lỗi mức cao; vẫn có bốn cảnh báo mức trung bình về
  các bảng bố cục trạng thái/sơ đồ kế thừa từ file đầu vào. Không coi đây là chứng nhận tuân thủ.
- PDF, ảnh và script kiểm tra chỉ nằm trong thư mục tạm; không phải bản phát hành.

## Các bản xuất ban đầu — lưu lịch sử ngày 03/09/2026

`Current` ở đây chỉ có nghĩa bản Word đang khớp với nguồn và SHA-256 đã ghi. Nó không có nghĩa
tài liệu đã được review, được sếp duyệt, đã kiểm thử hoặc được phép viết production code. Nếu nội
dung hay SHA-256 của nguồn thay đổi, bản Word tương ứng phải được coi là `Stale` và xuất lại.

### Danh mục rendition lúc xuất

| Trục quyết định | Bản Word | Nguồn có thẩm quyền | Rendition ID | SHA-256 nguồn | SHA-256 bản Word lúc xuất | Trạng thái |
|---|---|---|---|---|---|---|
| Feature | [FEATURE-001-v0.4-draft.docx](FEATURE-001-v0.4-draft.docx) | [FEATURE-001@0.4](../FEATURE-001-feature-definition-and-scope.md) | REN-FEATURE-001-0.4-DOCX-20260903-01 | `986f419ad9a5ad48e75c916d3a0020f926f4c59d7996ff28322dc49dedfaa5ee` | `355e17bdd6c9a6e5f0577276a8ebc8713d25fbca986e389bdb6f8e56e746bb4f` | Đã được người dùng chỉnh sau xuất; không còn khớp SHA-256 bản Word ở hàng này; xem mục ngày 04/09/2026 |
| Spec | [SPEC-001-v0.5-draft.docx](SPEC-001-v0.5-draft.docx) | [SPEC-001@0.5](../SPEC-001-product-specification.md) | REN-SPEC-001-0.5-DOCX-20260903-01 | `b6ecc11bb58ff4b0efc6519eb81c2fac98f8b197f7523f21a88d7cf0241cdcfd` | `eb0f45cc027560b67cd1912abbd8d79585e9551227359f183d1617b6bd64c9bd` | Current; nguồn Draft; review/quyết định NOT-RUN |
| Tech | [TECH-001-v0.3-draft.docx](TECH-001-v0.3-draft.docx) | [TECH-001@0.3](../TECH-001-technology-and-architecture-proposal.md) | REN-TECH-001-0.3-DOCX-20260903-01 | `4aadc2701c7320dd0a327da4664a8d5286cd97bdc0535f64b40cb071dc6a99b0` | `9b5ddc9b424981175666bf109b55ee9b8e8f5bb978cdc41bc1e0ae47d44d0a5a` | Current; nguồn Draft; review/quyết định NOT-RUN |

Ngày xuất: 03-09-2026 16:26 ICT. Phân loại: `INTERNAL`. Bộ tài liệu:
`IDEA-C1-ANALYSIS-DESIGN-001`. Thời hạn lưu giữ chính thức chưa được người có thẩm quyền quyết
định; trước mắt giữ bản Word cùng hồ sơ review của đúng phiên bản nguồn.

### Kiểm tra lần xuất ngày 03/09/2026

- Ba file mở và đọc được bằng `python-docx 1.2.0`; cấu trúc trang, bảng, liên kết và metadata được
  kiểm tra từ gói DOCX.
- Đã xuất qua Microsoft Word 16.0 để kiểm tra trực quan toàn bộ 36 trang: Feature 8 trang, Spec 18
  trang và Tech 10 trang. Không thấy nội dung bị cắt, chồng chữ, mất ký tự, đánh số sai hoặc hàng
  bảng bị tách làm mất ngữ cảnh.
- Bộ render chuẩn dùng LibreOffice không chạy được vì máy hiện tại không có `soffice`. Vì vậy bằng
  chứng trực quan nêu trên là kiểm tra thay thế bằng Word, không được ghi thành kết quả của bộ
  render LibreOffice.
- Kiểm tra hỗ trợ tiếp cận tự động không có lỗi mức cao. Công cụ báo bốn điểm mức trung bình vì
  khung trạng thái và sơ đồ chữ được trình bày bằng bảng bố cục không có hàng tiêu đề; đây không
  phải các bảng dữ liệu. Cần đánh giá lại cách trình bày nếu bản Word sau này phải đáp ứng một mức
  hỗ trợ tiếp cận đã được phê duyệt.
- PDF dùng cho kiểm tra trực quan chỉ là file QA tạm, không phải rendition được phát hành và không
  được lưu trong thư mục này.

Xem [sổ phiên bản](../VERSION-HISTORY.md) để biết lịch sử review, nguồn của tám DOC nội bộ và các
điểm chưa được chốt.
