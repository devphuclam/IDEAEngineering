# Phiên bản và nguồn của Feature / Spec / Tech

Ngày cập nhật: 04-09-2026. Bộ tài liệu: IDEA-C1-ANALYSIS-DESIGN-001.

Đây là sổ tra cứu phiên bản, nguồn và xác nhận review nội bộ. Không phải báo cáo kiểm thử,
quyết định Feature/Spec/Tech của sếp hoặc một nguồn yêu cầu mới.

## 1. Bản làm việc hiện tại

| Tài liệu | Phiên bản hiện tại | Trạng thái |
|---|---|---|
| [Feature](FEATURE-001-feature-definition-and-scope.md) | FEATURE-001@0.5 | Draft; 14 mã FTR; cách dùng Version/Generation được xác nhận riêng; toàn bộ bản mới chỉ `PARTIAL`, quyết định của sếp `NOT-RUN` |
| [Spec](SPEC-001-product-specification.md) | SPEC-001@0.6 | Draft; 68 yêu cầu; SPEC-OPEN-01 đã giải quyết, SPEC-OPEN-02…08 còn mở; toàn bộ bản mới chỉ `PARTIAL`, quyết định của sếp `NOT-RUN` |
| [Tech](TECH-001-technology-and-architecture-proposal.md) | TECH-001@0.4 | Draft; lựa chọn công nghệ không đổi, chỉ cập nhật nguồn; review nội bộ và quyết định Tech `NOT-RUN` |

Feature 0.5 giữ nguyên 14 mã FTR. Spec 0.6 giữ 68 yêu cầu và chốt một Version trong mỗi Revision;
Generation là mã snapshot bất biến, không có trường Version Sequence riêng. DOC-01 và DOC-03…08,
GOV, VVP hiện ở Draft 0.3; DOC-02 vẫn ở Draft 0.2. Lời duyệt hai bản cũ tại mục 5 không tự chuyển
sang toàn bộ nội dung mới.

## 2. Bản được giữ lại

| Bản lịch sử | Tình trạng tại lúc giữ lại | Cách sử dụng |
|---|---|---|
| [FEATURE-001@0.2](FEATURE-001-feature-definition-and-scope.v0.2.md) | Proposed; đã được anh review; sếp chưa quyết định Feature | Dùng để xem lại nội dung được review trước đây. Không chuyển kết quả đó sang Feature 0.3. |
| [SPEC-001@0.3](SPEC-001-product-specification.v0.3.md) | Draft; anh đã rút đồng ý và yêu cầu viết lại cấu trúc Spec | Không sử dụng như Spec đã được duyệt. Bản lưu giữ cả thông tin rút đồng ý. |

Hai bản lịch sử được sao chép nguyên nội dung trước khi biên tập. Các liên kết tương đối bên trong
vẫn được giữ; khi một liên kết trỏ đến tên file hiện hành, phải đọc kèm phiên bản được nêu trong
bản lịch sử và bảng này, không mặc nhiên coi bản mới là nội dung đã được review lúc trước.

### Bản trình trước khi ghi nhận lời duyệt

| Bản đã được xem xét | Mục đích giữ lại |
|---|---|
| [FEATURE-001@0.3 — bản trình](FEATURE-001-feature-definition-and-scope.v0.3-review-input.md) | Giữ đúng nội dung anh đã duyệt; trạng thái “chờ review” trong bản chụp là trạng thái lúc trình, trước xác nhận tại mục 5. |
| [SPEC-001@0.4 — bản trình](SPEC-001-product-specification.v0.4-review-input.md) | Giữ đúng 61 yêu cầu và tám điểm còn mở tại thời điểm anh duyệt; không biến điểm còn mở thành đã giải quyết. |

Tại lần ghi nhận review Feature 0.3 / Spec 0.4, chỉ phần thông tin review được cập nhật; không đổi
nội dung tính năng, yêu cầu, điều kiện kiểm tra hoặc điểm còn mở. Các dấu kiểm tra dưới đây thuộc
lần ghi nhận lịch sử đó. Bản sau review được giữ nguyên trong archive ở mục 6; file hiện hành đã có
nội dung mới và dấu kiểm tra riêng tại mục 7.

### Dấu kiểm tra nội dung

| Bản tài liệu | SHA-256 tại lần ghi này |
|---|---|
| FEATURE-001@0.2 — bản lưu | ec7c4fc1764123c9bcaadc612e9154f874326e8ead6482d2ebf2b11606b92612 |
| SPEC-001@0.3 — bản lưu | 1bd4a1c5798127d35fe4169aeeeffd6cade061643ff92681653a59d5a403533a |
| FEATURE-001@0.3 — bản trình được duyệt | 30f144b3071abd106709a0073276c330d2e72f194dcac24204815b6525cf5e6a |
| FEATURE-001@0.3 — sau ghi nhận review | 4d222a4df8cf2b0fbdca5c3bbfa9bcab9a3089fac71d83b7839c8fb9cb470772 |
| SPEC-001@0.4 — bản trình được duyệt | 368460c04131cbe5660dc58c0e8d150073a6813b6a47f6472f2887b3fdd9db6a |
| SPEC-001@0.4 — sau ghi nhận review | b8859ff45c2b76da751d981ac42a7d9d03b84bac86b75250c3e5ea19ce2a3ccd |

Dấu kiểm tra của các bản lưu khớp với nội dung trước lần biên tập hoặc ghi nhận review tương ứng.
SHA-256 chỉ giúp xác định
đúng nội dung và phát hiện thay đổi, không chứng minh tài liệu đã được review hay phần mềm đã đạt.

## 3. Nguồn lịch sử của Feature 0.3 và Spec 0.4

Các nguồn bên dưới là nội dung Draft 0.1 đã dùng khi viết Feature 0.3 / Spec 0.4. Chúng được giữ
nguyên tại lần review ở mục 5. Đường dẫn trong bảng chỉ để tra cứu tên tài liệu: hiện nay đường dẫn
đó mở bản mới. Muốn xem đúng nội dung lịch sử, lấy file cùng đường dẫn trong archive ở mục 6 và
đối chiếu SHA-256; không coi bản mới là nguồn đã được review lúc trước.

| Nguồn | Mã / phiên bản | Được dùng cho | SHA-256 |
|---|---|---|---|
| [DOC-01](../DOC-01-product-vision-and-scope.md) | IE-PROD-VISION-001@0.1 — Draft | Feature | b9e67ad05b9f37dfdb560a1fc684ff84b53065b98fd945e553721146de2a0786 |
| [DOC-02](../DOC-02-feasibility-and-options-assessment.md) | IE-PROD-FEAS-001@0.1 — Draft | Feature | 70bd0176660a0b81ee0374435b6fc2e8a9a9a8a1087d5322e3335325576f01b1 |
| [DOC-03](../DOC-03-business-requirements.md) | IE-PROD-BREQ-001@0.1 — Draft | Feature; Spec | 9f7329b3d10e25308b4cd68f13d0fd7c40d8bf175355328af6984ec4ef592bcf |
| [DOC-04](../DOC-04-software-requirements-specification.md) | IE-PROD-SREQ-001@0.1 — Draft | Spec — nguồn 61 mã REQ; liên kết FTR → REQ của Feature | 5c722590d08e6dbdf841aef1c4cf5d99042093e221d8890630c610bea8b8e3a3 |
| [DOC-06](../DOC-06-data-integration-and-migration-specification.md) | IE-PROD-DATA-001@0.1 — Draft | Spec — dữ liệu và giao tiếp | 35f8c9ac3b97981e8260c36f51b4a8553914c6cd68bd8457d46c1f91faa6ea38 |
| [DOC-07](../DOC-07-mvp-roadmap-and-delivery-plan.md) | IE-PROD-ROADMAP-001@0.1 — Draft | Feature | 7672b4e71a112ec05e7f9d56fc1a7a61f2121edf9acb3fae044482d48483de75 |
| [DOC-08](../DOC-08-ui-ux-and-interaction-specification.md) | IE-PROD-UX-001@0.1 — Draft | Spec — giao diện và ngôn ngữ | cad6bcfdf2917cd5b65c0ee15b05e18c4eb880190b3d80015616cb0c0f6b0916 |
| [GOV](../registers/GOV-material-and-behavioral-coverage.md) | IE-GOV-COVERAGE-001@0.1 — Draft | Feature | 0e8c0ddba8eb5058af718ceab34fd8896cf72f1b07ef28a9d6d38bf3084a7f68 |
| [VVP](../registers/VVP-core-v0-verification-validation-plan.md) | IE-VVP-CORE-001@0.1 — Draft | Spec — kế hoạch kiểm tra | e1c7c30d457504d21bc7eee6547962165ed33fe98771a79afdbecb20ad0a037e |
| [CONTEXT.md](../../../../../CONTEXT.md) | Bản làm việc ngày 03-09-2026; không tự gán Document Version | Thuật ngữ, ranh giới sản phẩm và làm việc offline trong Spec | d1edce5278ee732bbc4a2b88719be4c270f50e2f34b8d9f6be3a5135025b4bcd |

Feature 0.3 kế thừa mã FTR từ Feature 0.2 (bản lưu có dấu kiểm tra tại mục 2), đối chiếu nhu cầu/quy
tắc nghiệp vụ ở DOC-03 và trace ở DOC-04. Spec 0.4 còn phụ thuộc phạm vi FEATURE-001@0.3; dấu kiểm
tra của Feature cũng nằm tại mục 2.
Không có nguồn trong bảng này được đổi trạng thái sang Approved.

## 4. Các tham chiếu cũ tại thời điểm review Feature 0.3 / Spec 0.4

Tại thời điểm review, DOC-03 và DOC-07 bản 0.1 vẫn có dòng nói FEATURE-001@0.2 đã qua self-review;
một số nguồn khác còn tham chiếu SPEC-001@0.3. Những dòng đó chỉ áp dụng cho phiên bản lịch sử,
không xác nhận mức sẵn sàng của Feature 0.3 hoặc Spec 0.4. Các nguồn hiện hành đã được đồng bộ ở
mục 6–7.

Tại lần ghi nhận review ở mục 5, DOC-01…08, GOV, VVP, Tech, prototype, CONTEXT.md và các file
Spec Kit không bị sửa. Khi đó chỉ cập nhật trạng thái review, dấu kiểm tra và điều hướng của các
bản trình. Lần bổ sung bối cảnh Tech sau đó đã cập nhật các nguồn được liệt kê ở mục 6–7; những
mô tả trạng thái cũ nói trên không còn là chỉ dẫn cho bản hiện hành.

Trước khi trình một bộ tài liệu để quyết định:

1. Review nội bộ hai bản đã được ghi nhận tại mục 5. Tiếp tục giải quyết hoặc ghi quyết định có
   điều kiện cho các mục còn mở đúng phạm vi và thẩm quyền; không tự ghi điểm chưa giải quyết là đạt.
2. Nếu nội dung thay đổi yêu cầu hoặc phạm vi, cập nhật tài liệu nguồn, phiên bản và liên kết theo
   quy trình kiểm soát; không chỉ sửa riêng bản trình sếp.
3. Đồng bộ các dòng chỉ trạng thái/phụ thuộc cũ trong DOC-03/04/05/07 và các nguồn liên quan.
4. Ghim lại đúng phiên bản/nội dung, ghi người review và quyết định Feature → Spec → Tech.
5. Khi nguồn đổi, đánh dấu bản trình cần đối chiếu lại; không giữ nguyên kết quả duyệt của nội dung cũ.

Việc có đủ bản nháp không cho phép bắt đầu production code hoặc sử dụng hệ thống thật.

## 5. Ghi nhận review nội bộ ngày 03-09-2026

| Trường | Nội dung ghi nhận |
|---|---|
| Mã ghi nhận | RVW-FEATURE-SPEC-20260903-001 |
| Người review | Người dùng dự án — reviewer nội bộ đã được phân công; không ghi nhận như người duyệt độc lập hoặc Product Decision Authority |
| Ngày ghi nhận | 03-09-2026 |
| Xác nhận trực tiếp | “ok con dê duyệt nha” |
| Tài liệu được duyệt | FEATURE-001@0.3 và SPEC-001@0.4, đúng hai bản trình đã lưu tại mục 2 |
| Phạm vi / kết quả | PASS — chấp thuận hai bản thảo trong review nội bộ; không phải kết quả kiểm thử sản phẩm hoặc kết luận mọi yêu cầu đã đủ điều kiện triển khai |
| Điểm còn mở | SPEC-OPEN-01…08 giữ nguyên; không tự đóng, không tự bổ sung giá trị hoặc bỏ điều kiện |
| Quyết định của sếp | Feature và Spec vẫn NOT-RUN; lời duyệt này không được ghi thay quyết định của sếp |
| Phần không nằm trong xác nhận | Tech, review độc lập/chuyên môn, kiểm thử, các gate và cho phép viết production code hoặc sử dụng thật |
| Thay đổi khi ghi nhận | Chỉ cập nhật thông tin review và điều hướng/hashes; giữ nguyên phiên bản nội dung, danh mục tính năng, yêu cầu và điều kiện kiểm tra |
| Lịch sử trước đó | Không kế thừa review FEATURE-001@0.2; không phục hồi lời đồng ý đã rút đối với SPEC-001@0.3 |

Dấu kiểm tra của bản trình được duyệt và của file sau khi cập nhật review được ghi tách biệt tại
mục 2. Mọi thay đổi nội dung sau xác nhận này cần được đối chiếu và review cho đúng phiên bản mới;
không dùng lời duyệt hiện tại cho một nội dung được sửa sau đó.

## 6. Bổ sung bối cảnh và đề xuất Tech ngày 03-09-2026

| Nội dung | Ghi nhận |
|---|---|
| Bản ghi thay đổi | [IE-CHG-TECH-001@0.1](../registers/CHG-2026-09-03-tech-context-and-proposal.md) |
| Nguồn bối cảnh | Tám nhóm câu trả lời của anh, kết thúc bằng xác nhận “Duyệt”; chi tiết và giới hạn ghi tại TECH-CTX-001…008 |
| Phạm vi được xác nhận | Windows ở máy kỹ sư; khoảng 50–100 người dùng tại một địa điểm; tài khoản IDEA trước và anh quản trị tài khoản ban đầu; máy chủ có thể đề xuất; bối cảnh dữ liệu/vận hành và mục tiêu khôi phục sơ bộ |
| Chưa được xác nhận | Bộ công nghệ, hệ điều hành/cấu hình máy chủ, license/chi phí, khả năng khôi phục thực tế, quyết định của sếp và quyền bắt đầu code/cài đặt/triển khai |
| Phần yêu cầu mới | REQ-IAM-001…007 trong DOC-04 và Spec; vẫn thuộc FTR-011, không tạo thêm mã tính năng |
| Phần thiết kế mới | Lựa chọn server, Web, Desktop, tài khoản và kho file; phân tích phương án thay thế, ranh giới dữ liệu/quyền, backup, vòng đời và license |
| Phần được sửa cho nhất quán | Check-in thành công hoặc No Change đều bỏ giữ, không có tùy chọn tiếp tục giữ; tài khoản công ty không còn là điều kiện ban đầu; phân biệt giao dịch database với việc lưu file |
| Tài liệu mới | Feature 0.4, Spec 0.5, Tech 0.3; cả tám DOC, GOV và VVP 0.2; CHG 0.1 |
| Bối cảnh còn mở | SPEC-OPEN-05/06 được làm rõ một phần; tám SPEC-OPEN vẫn chưa tự đóng. RTO ≤4 giờ làm việc / RPO ≤1 giờ là mục tiêu đánh giá, chưa phải SLA. |
| Kết quả review bản mới | NOT-RUN; kết quả tại mục 5 vẫn chỉ áp dụng cho Feature 0.3 / Spec 0.4 |
| Phần không sửa | Prototype HTML, các ADR đã Accepted, constitution, Spec Kit và production code |
| Bản trình Word/PDF | Tạo ba rendition DOCX từ Feature 0.4, Spec 0.5 và Tech 0.3; Markdown vẫn là nguồn có thẩm quyền. PDF chưa tạo. Metadata và dấu kiểm tra nằm trong [danh mục rendition](renditions/README.md). |

Trước khi sửa đã giữ nguyên 16 file nguồn/chỉ mục trong
[archive trước bối cảnh Tech](../history/2026-09-03-before-tech-context.zip), với đường dẫn bên trong
tính từ gốc repository. Archive chứa cả Feature 0.3 / Spec 0.4 sau ghi nhận review, Tech 0.2 và nguồn
DOC-01…08/GOV/VVP/CONTEXT/README/sổ phiên bản cũ.

SHA-256 của archive:
`1333d9d578338f475852dd5d329c22046562da6df805ae403b1020c845461c1e`.

Đã đọc lại từng file trong archive và so với SHA-256 trước khi sửa. Các bản lịch sử và bản trình
review riêng tại mục 2 vẫn giữ nguyên. Đây là bảo toàn lịch sử tài liệu, không phải thử khôi phục
hệ thống sản phẩm.

## 7. Nguồn chính xác của bộ tài liệu hiện tại

Bảng dưới ghim nội dung mới. Tất cả tài liệu có số phiên bản vẫn ở trạng thái Draft; không có nguồn
nào được chuyển sang Approved. Hash chỉ nhận diện nội dung, không thay thế review hoặc kết quả test.

<!-- CURRENT-SOURCE-HASHES:BEGIN -->
| Nguồn | Phiên bản / phạm vi | Được dùng cho | SHA-256 |
|---|---|---|---|
| [DOC-01](../DOC-01-product-vision-and-scope.md) | IE-PROD-VISION-001@0.3 | Feature | b65059d8a810d746b18ff2eaa75360743aba52e9b5bca5966340e9fd94cd3607 |
| [DOC-02](../DOC-02-feasibility-and-options-assessment.md) | IE-PROD-FEAS-001@0.2 | Feature; Tech | 3887504f465593eadcbcca6c4f9c6fbba36150790fa7caa68c4ed1381de70ac7 |
| [DOC-03](../DOC-03-business-requirements.md) | IE-PROD-BREQ-001@0.3 | Feature; Spec | 46019399f52ba32dc00a2446910bf968bff1c81020eaf4a61ba78c75e6642040 |
| [DOC-04](../DOC-04-software-requirements-specification.md) | IE-PROD-SREQ-001@0.3 | 68 yêu cầu; Feature → Spec → Tech | 17a1b3791f8f925bee8cf7ed6ac7f3d5cfc6b57163f400ecca272360fe7f93f3 |
| [DOC-05](../DOC-05-architecture-description.md) | IE-PROD-ARCH-001@0.3 | Tech; trách nhiệm và ranh giới kiến trúc | b87fe1230ac7675a147f67dc633d62d0394f3436493cabcf941e7f5f19dcf2fe |
| [DOC-06](../DOC-06-data-integration-and-migration-specification.md) | IE-PROD-DATA-001@0.3 | Spec; Tech; danh tính, dữ liệu, giao tiếp | 67c900858564710cf5f631de5f2a59b604b58117580cc8127dcdb592d604f10b |
| [DOC-07](../DOC-07-mvp-roadmap-and-delivery-plan.md) | IE-PROD-ROADMAP-001@0.3 | Feature; trình tự quyết định và điều kiện thực hiện | a33d4a4334c5236d36a839a2cb5a5904755b13c2fea5f592ad7ba65dec71b028 |
| [DOC-08](../DOC-08-ui-ux-and-interaction-specification.md) | IE-PROD-UX-001@0.3 | Spec; Tech; UI và ngôn ngữ | 4e1d6b2fc12174ad48502608910bdb2c36633a862da43be0fe89ad44b930e7d8 |
| [GOV](../registers/GOV-material-and-behavioral-coverage.md) | IE-GOV-COVERAGE-001@0.3 | Feature; 16 phần đối chiếu có giới hạn bằng chứng | 4de0bcf9e28ee2185d48e6cdadb2209b52b081e0b8cbd1970e05f7fa8ee72016 |
| [VVP](../registers/VVP-core-v0-verification-validation-plan.md) | IE-VVP-CORE-001@0.3 | Spec; Tech; 15 mục kiểm chứng dự kiến | 10b4d498c82e379ea0a7dc661e7e28273b69c303a281652f6acebef4318ae2fe |
| [CHG Tech](../registers/CHG-2026-09-03-tech-context-and-proposal.md) | IE-CHG-TECH-001@0.1 | Bối cảnh Tech và lịch sử | a322f4f3f80aecca225dac87952b76796b92ba9c898fd61443f730ead77ca3a1 |
| [CHG Version](../registers/CHG-2026-09-04-version-model-clarification.md) | IE-CHG-VERSION-001@0.1 | Quyết định Version và phạm vi đồng bộ | d676263cabda5612b15fc7702f31b4f338d276a0cb75c2dcb0a679b7f1aafe4f |
| [Feature](FEATURE-001-feature-definition-and-scope.md) | FEATURE-001@0.5 | Bản trình; review toàn bản `PARTIAL` | a9dde0ee7732ab8dc600780095cde97c599b69f6db3974025e17a2b2d15d346c |
| [Spec](SPEC-001-product-specification.md) | SPEC-001@0.6 | Bản trình; SPEC-OPEN-01 đã giải quyết, bảy điểm còn mở | 09190e4079c19df1cd70fc6237431d1180ccb029f21dae84a48e72d0d1d2543b |
| [Tech](TECH-001-technology-and-architecture-proposal.md) | TECH-001@0.4 | Bản trình; lựa chọn công nghệ không đổi | c07a2c4324558f749ead9c217709e033413739b71161cbcb810f782ef18ea72d |
| [Chỉ mục tài liệu](../README.md) | Bản làm việc ngày 04-09-2026 | Điều hướng và trạng thái hiện hành | 2c91d53c5715cf3a01a0766e9bd97fd86349c9c448a2087ff54dabea2ba0cd40 |
| [CONTEXT.md](../../../../../CONTEXT.md) | Bản làm việc ngày 04-09-2026 | Thuật ngữ và quy tắc Revision/Version/Generation | b8f92de6e4fa35c23eea9fc1db6aec69f1c9d5f3a52ce350db21444fbfd20a22 |
| [Kiến trúc vòng đời](../../../../architecture/idea-product-lifecycle-architecture.md) | Bản làm việc ngày 04-09-2026 | Quy tắc chuyển trạng thái và bất biến | ca8790831da7fc79e22a8df258c0faf9003bfb20978205f5d659d475f94b93a3 |
| [Prototype](../../../../../prototypes/controlled-document-workspace.html) | Bản kiểm tra ngày 04-09-2026 | Mô phỏng Revision/Version/Generation và Check-in | 63c0ae7c432b10a200934a7806ecb2629d70273633d9c8438b51f45b29915b7b |
| [Hướng dẫn prototype](../../../../../prototypes/README.md) | Bản làm việc ngày 04-09-2026 | Kịch bản và giới hạn prototype | 8238165ff9f316958d9462c42f6bd153956161d162a800338ea7d38ec8ca1703 |
| [Nghiên cứu Tech](../../../../research/2026-09-03-idea-tech-stack-primary-sources.md) | Nguồn tra cứu ngày 03-09-2026 | Nguồn chính thức và giới hạn; không phải kết quả chạy thử | ba0f725ed68ed3aae15eb80267432b03594fde362fbfdaa22cd3350d2041fad7 |
<!-- CURRENT-SOURCE-HASHES:END -->

Sổ phiên bản này không tự ghim hash của chính nó. Các ADR Accepted được giữ nguyên tại repository
commit `45f1c43`; danh sách nằm ở [ADR index](../../../../adr/README.md). Các nguồn công nghệ chính
thức cùng ngày tra cứu và giới hạn được ghi trong research note ở bảng trên.

## 8. Kiểm tra của lần biên tập ngày 03-09-2026

| Kiểm tra | Phạm vi | Kết quả |
|---|---|---|
| Bộ kiểm tra tập trung cho nguồn hiện hành | 22 kiểm tra: tập mã/trace của 68 REQ; 61 yêu cầu cũ không đổi; 14 FTR; 15 VVP; 9 ô locale/surface; 8 SPEC-OPEN; 8 TECH-CTX; phiên bản 8 DOC; bảng/heading/fence; link và anchor cục bộ; ID tham chiếu; khoảng trắng/merge marker; hash bản lịch sử/archive và 17 nguồn hiện hành; không còn placeholder; phạm vi Git | `PASS` — 22/22, không có lỗi |
| Kiểm tra archive trước thay đổi | 16 file trong archive đối chiếu từng SHA-256 với nội dung đã chụp trước khi sửa | `PASS` — 16/16 |
| Cấu trúc ba bản Word | Mở gói DOCX; kiểm tra danh tính, metadata, khổ trang, bảng, đánh số, SHA-256 nguồn và SHA-256 rendition | `PASS` — 3/3; chi tiết tại [danh mục rendition](renditions/README.md) |
| Kiểm tra trực quan bản Word | Microsoft Word 16.0 xuất bản kiểm tra; xem toàn bộ Feature 8 trang, Spec 18 trang và Tech 10 trang | `PASS` theo đường kiểm tra thay thế — 36/36 trang không thấy cắt/chồng chữ, mất ký tự, sai đánh số hoặc tách hàng mất ngữ cảnh. Bộ render LibreOffice không chạy vì máy không có `soffice`; không ghi thay thành PASS của bộ render đó. |
| Kiểm tra hỗ trợ tiếp cận DOCX | Quét tự động ba bản Word | Không có lỗi mức cao; bốn cảnh báo mức trung bình thuộc khung trạng thái/sơ đồ chữ dùng bảng bố cục, đã ghi giới hạn trong danh mục rendition |
| `git diff --check` | Thay đổi file đã được Git theo dõi | `PASS`; Git chỉ cảnh báo quy tắc chuyển LF/CRLF của `CONTEXT.md`, không báo lỗi diff |
| Lệnh công khai `./scripts/verify-template` | Toàn bộ Core Workspace được Git theo dõi | `INCOMPLETE`: đã chạy đúng script bằng Git Bash, nhưng tiến trình bị ngắt trước khi có output/exit code sau hơn 25 phút quét dữ liệu repository; không được ghi là PASS. Chạy lại trước khi yêu cầu tích hợp/review repository. |
| Kiểm thử sản phẩm | Giao dịch, PostgreSQL, tài khoản/thu hồi phiên, WebView2, CAD/Office, hiệu năng, backup/restore | `NOT-RUN`; chưa có code, môi trường, dataset hoặc quyền triển khai |

Các kiểm tra nguồn không chứng minh tính đúng của giao dịch, bảo mật, khả năng xử lý CAD, hiệu năng
hoặc khôi phục. Toàn bộ thử nghiệm sản phẩm trong VVP vẫn NOT-RUN. Bước tiếp theo là anh review
phần bổ sung của Feature/Spec và đề xuất Tech, rồi trình đúng phiên bản cho sếp quyết định.

## 9. Đồng bộ mô hình Version và kiểm tra ngày 04-09-2026

| Nội dung | Ghi nhận |
|---|---|
| Bản ghi thay đổi | [IE-CHG-VERSION-001@0.1](../registers/CHG-2026-09-04-version-model-clarification.md) |
| Điều đã chốt | Một Version trong mỗi Revision; bắt đầu từ 1; Check-in có thay đổi tăng đúng một lần và tạo một Generation; No Change không tăng số; Revision mới trở lại Version 1; Generation là mã snapshot bất biến |
| Phạm vi xác nhận | Xác nhận nội bộ riêng cho cách dùng Version/Generation và SPEC-OPEN-01; không phải duyệt toàn bộ Feature 0.5, Spec 0.6 hoặc Tech 0.4 |
| Bản Word mới | [Feature 0.5](renditions/FEATURE-001-v0.5-bia-muc-luc.docx), [Spec 0.6](renditions/SPEC-001-v0.6-bia-muc-luc.docx), [Tech 0.4](renditions/TECH-001-v0.4-bia-muc-luc.docx); các file Word đầu vào được giữ nguyên |
| Quyết định của sếp | Feature, Spec và Tech vẫn `NOT-RUN` |

| Kiểm tra | Phạm vi | Kết quả |
|---|---|---|
| Prototype chuyển trạng thái | 10 kịch bản: bản đầu A/V1, Check-in có đổi, No Change, Submit/Approve/Release, Revision B/V1, Check-in tiếp theo, stale conflict và 10 item ở VI/EN/JA | `PASS` — 10/10 trong phạm vi prototype; không phải kiểm thử production |
| Nguồn Markdown hiện hành | Đếm mã kiểm soát; kiểm tra khoảng trắng, merge marker, code fence, 21 hash hiện hành và các liên kết file cục bộ trong bộ instance | `PASS` — 14 FTR, 68 REQ, 15 VVP, 8 SPEC-OPEN; hash và liên kết đều khớp |
| Cấu trúc và nội dung ba DOCX | Mở gói, kiểm tra lỗi thành phần, ID/phiên bản, field, mô hình Version, SPEC-OPEN-01 và không có trường `Version Sequence` | `PASS` — 3/3 |
| Mục lục và kiểm tra trực quan | Microsoft Word 16.0 cập nhật field và xuất bản QA; xem Feature 9, Spec 20, Tech 12 trang | `PASS` theo đường kiểm tra thay thế — 41/41 trang; không thấy cắt chữ, chồng lấn hoặc trang trắng thừa. Máy không có LibreOffice nên không ghi kết quả này thay cho bộ render LibreOffice. |
| Hỗ trợ tiếp cận DOCX | Quét tự động ba bản Word | Không có lỗi mức cao. Ba cảnh báo mức trung bình là bảng bố cục trạng thái/sơ đồ kiến trúc, không phải bảng dữ liệu. |
| `git diff --check` | Các thay đổi ở file đã được Git theo dõi | `PASS`; chỉ có cảnh báo chuyển LF/CRLF, không có lỗi diff. Các file instance chưa được Git theo dõi đã được kiểm tra riêng ở hàng nguồn Markdown. |
| Kiểm thử sản phẩm | Database, giao dịch, quyền, bảo mật, CAD/Office, hiệu năng, backup/restore | `NOT-RUN`; chưa có production code hoặc môi trường kiểm thử |

Các kết quả `PASS` ở mục này chỉ chứng minh tính nhất quán của tài liệu và hành vi mô phỏng. Chúng
không phải bằng chứng rằng sản phẩm đã được triển khai, đạt VVP hoặc được phép dùng thật.
