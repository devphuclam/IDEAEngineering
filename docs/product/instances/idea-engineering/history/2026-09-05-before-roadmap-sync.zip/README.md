# IDEA Engineering Product-Definition Instance Set

This directory contains the controlled working instances for the internal IDEA Engineering product.
The instruction-only class templates remain under [`docs/product/definition`](../../definition/README.md)
and are not edited as product content.

## Baseline

| Field | Value |
|---|---|
| Baseline ID | `IDEA-C1-ANALYSIS-DESIGN-001` |
| Purpose | Analysis and design through `PG4`; no production implementation authorization |
| Product boundary | Internal IDEA Engineering `C1` product |
| Principal author | `Principal Product Author` — assistant prepares the documents; accountable attribution must be recorded before `Proposed` |
| Internal document reviewer | Project user; this assignment does not establish required independent/specialist qualification |
| Product decision authority | The boss, acting as `Product Decision Authority`, decides Feature, Spec and Tech |
| Editable authority | English Markdown source under version control |
| Boss-facing language | Vietnamese decision briefs, with common technical terms retained |
| Current Core source versions | DOC-01 and DOC-03…08 at `Draft 0.3`; DOC-02 at `Draft 0.2`; GOV/VVP at `Draft 0.3`; CHG records at `Draft 0.1` |
| First approved version | `Approved 1.0` only after the applicable controlled decision |

## Two-layer reading model

The eight Core Product Documents are the detailed internal authority. The Product Decision
Authority is not expected to read all eight. Three briefs present the features, testable
requirements and justified technology choices, and pin the exact source versions they use.

| Boss-facing brief | Decision axis | Detailed source set | Current state |
|---|---|---|---|
| [`FEATURE-001`](decision-briefs/FEATURE-001-feature-definition-and-scope.md) | Feature scope and priority | DOC-01, DOC-02, DOC-03, DOC-07 and governed reference coverage | `Draft 0.5`; 14 feature IDs; Version semantics clarified; full new-version review and boss decision `NOT-RUN` |
| [`SPEC-001`](decision-briefs/SPEC-001-product-specification.md) | Required behavior and acceptance | DOC-04, requirement-bearing DOC-06/08 content, VVP | `Draft 0.6`; 68 requirements; SPEC-OPEN-01 resolved, seven points remain open; full review and boss decision `NOT-RUN` |
| [`TECH-001`](decision-briefs/TECH-001-technology-and-architecture-proposal.md) | Architecture and technology selection | DOC-02, DOC-04/05/06/08, accepted ADRs, confirmed context and official technology sources | `Draft 0.4`; technology choices unchanged and source pins refreshed; internal review and boss decision `NOT-RUN`; no selected production stack |

A brief is a controlled decision view, not a second requirement or architecture authority. It
becomes `Stale` when a pinned source changes. A boss decision must identify the exact brief and
source baseline; the author then records its consequences in the affected Core Product Documents.

## Current context, review and retained versions

The user's Tech-context confirmation “Duyệt” on 2026-09-03 accepts the planning inputs recorded in
[IE-CHG-TECH-001](registers/CHG-2026-09-03-tech-context-and-proposal.md), not a stack or implementation
decision. The proposal now reflects Windows engineering PCs, approximately 50–100 intended users
at one site, administrator-issued IDEA accounts first, initial account administration by the user,
and possible user-led operations without an assumed DevOps team. Company login is a future method,
not an initial prerequisite. File volumes are unmeasured. RTO ≤4 working hours and RPO ≤1 hour are
preliminary evaluation objectives, not a tested SLA or rollout acceptance.

The project user previously accepted Feature 0.3 and Spec 0.4 in internal review:
[RVW-FEATURE-SPEC-20260903-001](decision-briefs/VERSION-HISTORY.md#5-ghi-nhận-review-nội-bộ-ngày-03-09-2026).
That result remains attached to those exact versions. It does not automatically apply to Feature
0.5, Spec 0.6 or Tech 0.4. The Version-model point was separately confirmed on 04-09-2026, but the
complete successor briefs still require review.

The [version history](decision-briefs/VERSION-HISTORY.md) records current source hashes, prior
review inputs and a verified [pre-change source archive](history/2026-09-03-before-tech-context.zip).
No retained historical brief was overwritten. Earlier Spec 0.3 acceptance remains withdrawn.

`SPEC-OPEN-01` is recorded as resolved: Versions within each Revision are numbered `1, 2, 3…`,
while Generation is the exact immutable snapshot; there is no additional Version Sequence field.
The seven records `SPEC-OPEN-02…08` remain open. A complete draft does not imply that these gaps,
product tests or gates have passed.

## Core instance catalogue

| Class | Stable Document ID | Instance | Current state |
|---|---|---|---|
| `DOC-01` | `IE-PROD-VISION-001` | [Product Vision and Scope](DOC-01-product-vision-and-scope.md) | `Draft 0.3` |
| `DOC-02` | `IE-PROD-FEAS-001` | [Feasibility and Options Assessment](DOC-02-feasibility-and-options-assessment.md) | `Draft 0.2` |
| `DOC-03` | `IE-PROD-BREQ-001` | [Business Requirements](DOC-03-business-requirements.md) | `Draft 0.3` |
| `DOC-04` | `IE-PROD-SREQ-001` | [Software Requirements Specification](DOC-04-software-requirements-specification.md) | `Draft 0.3` |
| `DOC-05` | `IE-PROD-ARCH-001` | [Architecture Description](DOC-05-architecture-description.md) | `Draft 0.3` |
| `DOC-06` | `IE-PROD-DATA-001` | [Data, Integration and Migration Specification](DOC-06-data-integration-and-migration-specification.md) | `Draft 0.3` |
| `DOC-07` | `IE-PROD-ROADMAP-001` | [MVP Roadmap and Delivery Plan](DOC-07-mvp-roadmap-and-delivery-plan.md) | `Draft 0.3` |
| `DOC-08` | `IE-PROD-UX-001` | [UI/UX and Interaction Specification](DOC-08-ui-ux-and-interaction-specification.md) | `Draft 0.3` |

## Supporting instance catalogue

| Class | Stable Record ID | Instance | Current state |
|---|---|---|---|
| `GOV` | `IE-GOV-COVERAGE-001` | [Material and Behavioral Coverage Register](registers/GOV-material-and-behavioral-coverage.md) | `Draft 0.3`; 16/16 public-baseline areas have explicit dispositions, not implementation coverage; target-runtime evidence remains `BLOCKED` |
| `VVP` | `IE-VVP-CORE-001` | [Core v0 Verification and Validation Plan](registers/VVP-core-v0-verification-validation-plan.md) | `Draft 0.3`; 15 planned objectives; execution `NOT-RUN` |
| `CHG` | `IE-CHG-TECH-001` | [Tech Context and Proposal Change Record](registers/CHG-2026-09-03-tech-context-and-proposal.md) | `Draft 0.1`; context source, material impact, retained versions and pending review |
| `CHG` | `IE-CHG-VERSION-001` | [Version Model Clarification Change Record](registers/CHG-2026-09-04-version-model-clarification.md) | `Draft 0.1`; closes SPEC-OPEN-01 for internal drafting; boss decision remains `NOT-RUN` |

The [technology research note](../../../research/2026-09-03-idea-tech-stack-primary-sources.md)
supports the proposal with official sources and their limitations. Source research is not a
compatibility test, license approval or an IDEA product decision.

## Authoring and decision sequence

1. Review the successor Feature/Spec additions and Tech proposal; keep unresolved inputs explicit.
2. Record Feature → Spec → Tech decisions against the exact versions presented to the boss.
3. Obtain the required company deployment, security, operational and specialist dispositions;
   qualify the proposed stack, account boundary, file/format behavior and recovery design.
4. Update DOC-07 and the required GOV, CLR, RSK, VVP, VEV, CMP and CHG records for `PG4` readiness.
5. Start production implementation only after the approved requirements, architecture and increment
   readiness satisfy the applicable gates.

No item in this directory currently records a boss approval or a product-gate `PASS`.
