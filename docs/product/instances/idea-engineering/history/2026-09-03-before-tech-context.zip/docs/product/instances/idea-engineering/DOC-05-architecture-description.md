DOC-05

# IDEA Engineering Core v0 Architecture Description

> **Instance state**: controlled `Draft 0.1`. This document describes a candidate architecture for
> the recorded product direction and Draft requirements. It does not approve a technology stack,
> authorize production implementation, or record a successful architecture review.

## Control envelope

| Field | Recorded value |
|---|---|
| Stable Document ID | `IE-PROD-ARCH-001` |
| Document Class | `DOC-05` |
| Title | IDEA Engineering Core v0 Architecture Description |
| Owner | `Principal Product Author`; named person attribution required before `Proposed` |
| Document Status | `Draft` |
| Document Version | `0.1` |
| Applicable Baseline | `IDEA-C1-ANALYSIS-DESIGN-001` / candidate `IE-TECH-CORE-V0-001` |
| Requirements Input | `IE-PROD-SREQ-001@0.1`; Feature and Spec decisions remain `NOT-RUN` |
| Effective Date | `NOT APPLICABLE` until approval |
| Authors | `Principal Product Author`; named identity not yet recorded |
| Reviewers | `Author Self-Reviewer` only; architecture review `NOT-RUN`; independent reviewer unassigned |
| Approvers | Product Decision Authority for Tech; identity, decision and date are `UNKNOWN` |
| Source Links | [DOC-04](DOC-04-software-requirements-specification.md), [DOC-06](DOC-06-data-integration-and-migration-specification.md), [DOC-08](DOC-08-ui-ux-and-interaction-specification.md), [architecture input](../../../architecture/idea-product-lifecycle-architecture.md), [accepted ADR index](../../../adr/README.md) |
| Downstream Links | [DOC-07](DOC-07-mvp-roadmap-and-delivery-plan.md), [VVP](registers/VVP-core-v0-verification-validation-plan.md), [TECH-001](decision-briefs/TECH-001-technology-and-architecture-proposal.md), future implementation contracts and evidence |
| Evidence / Claim Status | Architecture and technology evaluation are `Draft`; tests, spikes and operational evidence are `NOT-RUN` |
| Change History | Initial controlled Draft; no prior version |
| Access Classification / Retention Rule | `INTERNAL`; retain with the controlled product baseline and successor/change records |

<!-- AUTHOR CONTENT START -->

## 1. System of interest and context

The system of interest is `C1 — IDEA Engineering`, an internal product that controls engineering
documents, immutable Generations, Product Structure, review decisions and exact Releases. It remains
useful and deployable without a future platform or another product capability.

```text
Engineering users / reviewers / administrators
              │ explicit commands, queries and decisions
              v
     IDEA Web and IDEA Desktop
              │ authenticated product interfaces
              v
       IDEA Server — product authority
        │             │              │
        │             │              └── isolated Format Processing Runtime
        │             └── private immutable Artifact storage
        └── relational metadata, policy, structure and Audit

IDEA Desktop ↔ per-user Workspace process ↔ ordinary persisted Office/CAD files
External applications are launched by the operating system; no IDEA code runs inside them.
```

| Context item | Description | Authority / evidence | Status |
|---|---|---|---|
| Internal actors | Engineer/Author, Reviewer, Independent Approver, PDM Administrator, Quality/Auditor, Security Administrator and Operator. | DOC-03 actors; DOC-08 user profiles | `Draft` |
| External applications | Configured Office/CAD applications read and write ordinary files in a Managed Workspace. Unsaved in-memory state is outside IDEA. | `REQ-FMT-001/004`; accepted product decision | `Draft` |
| Company identity | A company identity provider authenticates users; the concrete provider is not yet selected. | `REQ-GOV-001/002`, `REQ-SEC-003` | `UNKNOWN` provider; interface required |
| Data stores | Relational authoritative metadata plus private content-addressed Artifact storage. | `REQ-ID-*`, `REQ-STR-*`, `REQ-OPS-001/003/004`; DOC-06 | Architecture `Draft`; providers undecided |
| Future integrations | Read-only controlled export is in Core v0. General external integration and write-back are deferred. | Feature exclusions; `REQ-LC-009` | `DEFER` |
| Product boundary | One internal product and one Organization boundary in the first deployment; Organization isolation remains enforced by design. | `REQ-GOV-001`; internal-company decision | `Draft` |

## 2. Concerns, quality attributes and scenarios

| Scenario / concern | Stimulus and operating condition | Required architecture response | Verification link | Current result |
|---|---|---|---|---|
| `QRS-001` Correct identity/version | Register, change, Check-in and revise one Logical Document. | One stable identity; immutable committed Generation; atomic first baseline and revision transition. | `REQ-ID-001…006`; `VVP-001/002` | `NOT-RUN` |
| `QRS-002` Atomic multi-document Check-in | Failure occurs at any upload, validation, materialization or transaction point. | Candidate content remains private; every selected change commits together or none commits; retry is idempotent. | `REQ-WS-007/008/012`, `REQ-OPS-001`; `VVP-003` | `NOT-RUN` |
| `QRS-003` Stale/non-owner protection | A stale, wrong-owner, wrong-Workspace or unauthorized publish is submitted. | Authoritative state is unchanged, local work remains safe, and an actionable conflict is returned. | `REQ-WS-010/011/013`; `VVP-004` | `NOT-RUN` |
| `QRS-004` Exact release | Release is requested with missing, unresolved or unapproved content. | Lifecycle Governance fails closed; successful Release pins exact Generation, structure, policy and evidence. | `REQ-STR-003`, `REQ-LC-006…009`; `VVP-007` | `NOT-RUN` |
| `QRS-005` Organization isolation | An identity attempts to resolve or command another Organization's resource. | Resource owner refuses the action and appends permitted Audit Evidence without cross-scope disclosure. | `REQ-GOV-001/002`; `VVP-008` | `NOT-RUN` |
| `QRS-006` Exact restore | Metadata/content/configuration is restored from one approved recovery point. | Every retained Generation resolves and digest-checks; gaps are reported and cannot be called PASS. | `REQ-OPS-003/004`; `VVP-013` | `NOT-RUN` |
| `QRS-007` Localized interaction | The same controlled task runs in each supported locale and surface. | Command/state/authority outcomes remain equal; user Unicode round-trips; missing resources use the declared fallback. | `REQ-UX-*`, `REQ-LOC-*`; `VVP-009/010` | `NOT-RUN` |
| `QRS-008` Untrusted format input | A malformed, oversized or slow file is processed. | Bounded worker failure cannot change source Artifact or product state; results retain tool/profile provenance. | `REQ-FMT-002…005`, `REQ-SEC-004`; `VVP-008/011` | `NOT-RUN` |
| Dense workspace usability | User performs a controlled task at the canonical 1440×900 demo viewport. | Context remains visible; same-type detail scrolls internally or opens in a drawer/modal; keyboard, focus and status semantics remain usable. | `REQ-UX-*`; `VVP-009` | `NOT-RUN` |

Performance, availability, capacity, Reservation lease, transfer-token duration, worker resource
limits, RPO and RTO thresholds remain `UNKNOWN`. The Principal Product Author owns clarification;
the trigger is Spec/Tech preparation with a representative internal workload and deployment context.

## 3. Viewpoints and views

| Viewpoint | Intended concern / audience | View maintained here | Correspondence rule | Review status |
|---|---|---|---|---|
| Context | Product Decision Authority and all stakeholders | System boundary and external actors in section 1 | No external actor/store becomes product authority. | `Draft` |
| Responsibility | Maintainers and reviewers | Hosts and deep Modules in sections 4–5 | Every authoritative state has exactly one owner Module. | `Draft` |
| Information | Product, data and quality owners | Identity/lifecycle implications in section 8 and DOC-06 | Persisted references use stable identities and exact version pins. | `Draft` |
| Interaction | Engineer, reviewer and HCD owner | Checkout/Check-in and review/release sequences in section 7 | UI state is a view of server/workspace truth, not a second authority. | `Draft` |
| Deployment | Operator and security owner | Host/trust-zone view in sections 4 and 9 | Client/worker packages cannot hold infrastructure credentials. | `Draft` |
| Reliability | Operator, data and quality owners | Atomicity, idempotency, outbox, reconciliation and restore in section 9 | Public state appears only after a complete authoritative commit. | `Draft` |
| Security | Security and policy owners | Trust seams and owner-enforced authorization in section 10 | Every access path reaches the authoritative owner policy. | `Draft` |
| Evolution | Product and architecture owners | seams, candidate stack and deferred boundaries | A later Adapter may replace an Implementation without changing Module authority or accepted interface semantics. | `Draft` |

## 4. Deployable hosts and responsibilities

| Host | Responsibility | Must not do | Primary requirements |
|---|---|---|---|
| IDEA Server | Authenticate product requests; coordinate Modules; enforce authorization; persist authoritative state; perform atomic Check-in, workflow and Release; append Audit/outbox. | Expose internal schema; let clients/workers decide authoritative state; require a future platform for local behavior. | `REQ-ID-*`, `REQ-WS-007…013`, `REQ-LC-*`, `REQ-GOV-*` |
| IDEA Web | Search/browse/view; review/approval; governed administration; policy-appropriate preview/download. | Write stores directly or duplicate identity, Check-in, approval or Release rules. | `REQ-LC-*`, `REQ-UX-*`, `REQ-LOC-*` |
| IDEA Desktop | Capture explicit Checkout/Open/Check-in/Cancel/Recover intent; confirm scope; show conflict/recovery; launch files by OS association. | Run in an external application; publish on Save; keep permanent store credentials. | `REQ-WS-*`, `REQ-FMT-001/004`, `REQ-UX-*` |
| Workspace process | Per-user materialization, full scan/hash, cache, Workspace Manifest, resumable transfer and durable local recovery state. | Become product authority, approve/release, infer user intent or auto-merge binary changes. | `REQ-WS-001/003/004/006/009…013`, `REQ-SEC-003` |
| Format Processing Runtime | Execute one bounded immutable-input analysis/preview/conversion job through a versioned Adapter. | Mutate source content or product state; reuse broad credentials; claim undeclared capability. | `REQ-FMT-002…005`, `REQ-SEC-004` |
| Relational store | Persist identity, metadata, heads, policies, structure, workflow, release, Audit and operation state transactionally. | Store user-editable working files or become an interface consumed by clients. | DOC-06; `REQ-OPS-003/004` |
| Private Artifact store | Retain immutable content by digest and serve only through scoped authorized transfer. | Expose permanent credentials/public access or decide which content is authoritative. | `REQ-ID-003`, `REQ-SEC-001/002`, `REQ-OPS-001/003/004` |

The Workspace process initially means a protected per-user background process, not a privileged
machine-wide Windows service. Process count and packaging remain a Tech decision.

## 5. Deep Modules, Interfaces and ownership

In this document, a **Module** owns a coherent responsibility and state; its **Interface** is the
small contract callers need; its **Implementation** hides internal complexity; a **Seam** is a place
where policy, technology or deployment can vary; and an **Adapter** translates across a Seam. These
terms do not imply one network service per Module.

| Module | Small Interface intent | Complexity hidden by Implementation | Authoritative state |
|---|---|---|---|
| Controlled Product Data | Register, resolve, Checkout, prepare/commit Check-in, revise and retrieve exact content. | Stable identity, Generation immutability, optimistic concurrency, staging, deduplication and atomic Change Sets. | Logical Document, Artifact reference, Generation, Business Revision, Reservation, Working Head, Check-in Operation/Change Set. |
| Product Structure | Resolve, validate and publish exact structure. | Node/occurrence/dependency rules, cycles, unresolved members, semantic digest and exact pins. | Structure Snapshot and controlled relation identities. |
| Lifecycle Governance | Start/transition workflow, record decision, Release and resolve exact baseline. | Definition/instance versioning, eligibility/quorum, invalidation, exceptions and release completeness. | Workflow Definition/Instance, Approval Policy/Decision, Release Record. |
| Information Model | Validate metadata, classify and allocate governed numbers. | Schema versioning, numbering scope/idempotency and policy migration. | Metadata/Classification/Numbering Policy Definitions and allocations. |
| Format Intelligence | Declare capability and request analysis/representation. | Adapter/tool versions, isolation, resource limits, provenance, stale derivative handling. | Format Capability Profile, job/result identity and Representation metadata; never source authority. |
| Access Policy | Evaluate a versioned decision at the owning resource. | Role/group/state policy, bootstrap and explainable denial without hard-coded business roles. | Access Policy Definition/Version and decision evidence. |
| Discovery | Find/browse through rebuildable projections. | Indexing, query projection, lag and replay. | Search projection only; never product authority. |
| Audit Evidence | Append and export attributable product events. | Correlation, completeness, ordering, retention reference and controlled export. | Append-only Audit records. |

Module rules:

1. A Module writes only its own authoritative state.
2. Cross-Module work uses an Interface and explicit stable identities, not shared table mutation.
3. The server transaction may coordinate multiple owner Implementations only through declared
   contracts and one atomic business operation.
4. Projections, caches, derivatives and UI view models are rebuildable and never become authority.
5. Splitting a Module across a process Seam requires measured scale, isolation, ownership or failure
   evidence and a new approved Tech decision.

## 6. Semantic interface catalogue

The interfaces below define product meaning. Protocol, serialization and library choices are
candidate Tech details; a later implementation must preserve the behavior and errors.

| Interface ID | Owner / caller | Inputs and outputs | Contract and error behavior | Security / trace |
|---|---|---|---|---|
| `IF-PRODUCT-QUERY` | Owner Module / Web, Desktop | Organization, actor, stable identity, requested view → authorized exact state/projection. | No floating resolution where an exact pin is required; stale projection is identified; missing/unauthorized fails without data leakage. | Authenticated; owner-authorized; correlation/Audit where material. |
| `IF-PRODUCT-COMMAND` | Owner Module / Web, Desktop | Actor, policy context, target, expected state, OperationId and payload → one accepted/refused outcome. | Optimistic preconditions and idempotency are explicit; no partial authoritative outcome. | Owner enforces final authorization; decision evidence pins policy version. |
| `IF-ARTIFACT-TRANSFER` | Controlled Product Data / Workspace or authorized viewer | Exact Artifact/digest and operation scope → resumable bytes plus verification result. | Short-lived scoped grant; wrong object, expiry, replay or digest mismatch fails closed. | No permanent store credential in client; transfer correlated and auditable. |
| `IF-WORKSPACE-IPC` | Workspace process / Desktop | Per-user authenticated commands, progress, manifest and local-state evidence. | Another user/session cannot command/read; reconnect does not invent server success. | Protected local transport; no secrets in diagnostic output. |
| `IF-FORMAT-JOB` | Format Intelligence / isolated Adapter | Immutable input pin, Capability Profile and limits → typed result/Representation or typed failure. | Idempotent; source advance makes derivative stale; failure preserves source and state. | One-job least privilege; adapter/tool provenance and digest retained. |
| `IF-COMMITTED-EVENT` | Owner Module / projections and notifications | Committed event with identity, version, actor, correlation and source pins. | Published from transactional outbox only; replay repairs consumers; consumer failure cannot reverse/fabricate owner state. | Classification propagated; consumer access scoped. |
| `IF-COMPANY-IDENTITY` | Company identity Adapter / Server | Authenticated subject and claims → internal Actor/Organization context. | Provider outage/refusal denies new protected action; retained product history remains resolvable by stable Actor identity. | OpenID Connect is candidate protocol; concrete provider/configuration `UNKNOWN`. |

A supported public integration interface is outside Core v0. Internal versioned interfaces do not
create a promise of ERP/MRP write-back, bidirectional synchronization or direct database access.

## 7. Key interaction and state sequences

### 7.1 Checkout and materialization

1. Desktop resolves the selected root and known Related Documents.
2. User confirms each item as Checkout, Reference or excluded; no hidden assembly-wide cascade.
3. Server authorizes the complete request and creates one Reservation per Checkout document against
   its expected Generation. One conflict refuses the proposed set and returns affected entries.
4. Controlled Product Data grants scoped Artifact transfer for the confirmed snapshot.
5. Workspace process materializes every exact file, verifies the digest and records its Workspace
   Manifest before Desktop reports completion and opens the root through the operating system.

### 7.2 Check-in and stale recovery

1. Workspace process scans/hashes the complete candidate scope and classifies unchanged, changed,
   missing, Out of date and modified-without-Checkout entries using the approved UI terms.
2. Desktop shows the evidence and requires the user to confirm exact scope and Reservation outcome.
3. Content is staged privately. Server validates identity, digest, metadata, relations, policy,
   owner, Workspace, Reservation and expected Generation.
4. Any invalid entry refuses the entire confirmed Change Set. Local work is preserved; the response
   shows expected/current Generation and valid refresh/reapply, Save As, retry or governed recovery.
5. On success, verified Artifacts, required Structure Snapshot, Generations, Working Heads, Change
   Set, Audit and outbox commit atomically. Semantic no-op creates no Generation.
6. Successful Check-in ends the Checkout/Reservation for the selected scope unless an explicit
   governed retain option was confirmed. Retry with the same OperationId returns the same result.

### 7.3 Review, approval and Release

1. Submit pins the exact Generation and review scope under one Workflow/Approval Policy Version.
2. Later content change invalidates the pending review; it never inherits an earlier approval.
3. The seeded path requires one eligible independent approver and refuses self-approval/release.
4. Release revalidates exact Artifacts, Product Structure, decisions, exceptions, policy and Audit.
5. Success creates an immutable Release Record and reproducible Controlled Release Package;
   failure changes no release state and reports blocking entries.

## 8. Data, lifecycle and integration implications

| Topic | Architectural implication | Detailed authority | Status |
|---|---|---|---|
| Identity/version | Stable Logical Document and Business Revision identities point to immutable Generations; Version Sequence is distinct from business-facing Revision. | DOC-06 sections 2–3; `REQ-ID-*` | `Draft` |
| Binary content | Artifact bytes are immutable and content-addressed; a Generation Manifest pins exact digests. | DOC-06; `REQ-ID-003/004` | `Draft` |
| Structure | Structure Snapshot is immutable and members pin exact Generations; unresolved required dependencies remain visible. | DOC-06 `DATA-REL-005/006`; `REQ-STR-*` | `Draft` |
| Workflow/release | Definitions and policies are versioned; instances and decisions pin the exact versions; Release never follows floating latest. | DOC-06 `DATA-REL-008…010`; `REQ-LC-*` | `Draft` |
| Policy/configuration | Product defaults, organization-owned governed policies and low-impact operational settings follow distinct change paths. | `REQ-GOV-*`; proposed configuration ADR | `Draft`; approval pending |
| Store Existing | Bounded onboarding maps ordinary files into the same identity/content model; duplicates are shown, never silently merged. | DOC-06 section 5; `REQ-ID-002` | `Draft` |
| Export | Controlled Release Package is read-only and exact; external write-back remains deferred. | DOC-06 section 6; `REQ-LC-009` | `Draft` |
| Audit/recovery | Evidence is append-only in the logical product model; backup/restore covers one consistent metadata/content/configuration point. | DOC-06 sections 7–8; `REQ-AUD-*`, `REQ-OPS-*` | `Draft`; procedures `NOT-RUN` |

## 9. Reliability, deployment and operations

```text
Prepared → Uploading → Validating → ReadyToPublish → Published
    └──────────────────────────────────────────────→ Failed
    └──────────────────────────────────────────────→ Cancelled
Published | Failed | Cancelled = terminal Check-in Operation states
```

- Candidate uploads and materialized objects remain private until one authoritative transaction
  makes them reachable from a committed Generation.
- Working Heads, Check-in Change Set, Audit and outbox commit together. Notifications/search consume
  committed events afterward and cannot decide whether the command succeeded.
- Reconciliation identifies expired staging, unreferenced private candidates, missing/corrupt
  objects and projection drift; each result is attributable and repeatable.
- Backups include relational state, Artifacts, active configuration/policies and required keys at
  one consistent point. Only a successful restore and complete digest reconciliation may PASS.
- The first deployment topology, operating system, storage provider, capacity, monitoring, support,
  RPO and RTO remain `UNKNOWN` pending company constraints and Tech decision.
- Core v0 starts as one server deployment unit with internal deep Modules. It does not start as
  microservices; a later split requires measured evidence and an approved change.

## 10. Security and privacy design

Trust zones are browser, user desktop/session, Managed Workspace, IDEA Server, relational store,
private Artifact store, isolated Format Processing Runtime and external applications.

| Control | Architectural response | Evidence required |
|---|---|---|
| Authentication/organization | Resolve company identity to stable Actor and one Organization context before protected access. | Cross-Organization and provider-failure tests |
| Authorization | Resource owner evaluates versioned policy at every Web, Desktop, transfer, preview, export and worker path. | One cross-path authorization matrix and explainable denials |
| Credentials | Web/Desktop/Workspace packages contain no database or permanent Artifact-store credentials. | Package/configuration scan and direct-store denial tests |
| Transfer | Use short-lived, exact-object/operation grants through `IF-ARTIFACT-TRANSFER`. | Expiry, wrong-object and replay tests |
| Local process | Protect `IF-WORKSPACE-IPC` per user/session and retain only necessary local recovery data. | Cross-user/session denial and recovery inspection |
| Untrusted formats | Bound input/output, CPU, memory and time; run through least-privilege Adapter isolation. | Malformed/oversized fixtures and source-digest comparison |
| Audit/privacy | Record attributable decisions without secrets or unnecessary personal content; ordinary administration cannot edit/delete Audit. | Evidence completeness, mutation-denial and log-content review |
| Delivery integrity | Pin source, dependencies, tools, build evidence and released artifacts; packaging/signing approach remains open. | Future SBOM/provenance/signing evidence |

## 11. Candidate technology profiles and trade-offs

No profile in this section is approved. `Profile A` is the current recommendation because it keeps
the server and Windows-side code in one runtime family while retaining a conventional Web stack and
a database suited to transactional relational ownership. Selection still requires the Tech decision.

| Area | Profile A — recommended candidate | Profile B — Microsoft data platform | Profile C — Java server alternative |
|---|---|---|---|
| Server | `.NET 10 LTS` / `ASP.NET Core` modular monolith | Same as A | Java/Spring modular monolith |
| Web | `React + TypeScript`; Vite-based client build unless a framework need is demonstrated | Same as A | Same as A |
| Database | `PostgreSQL 18` | SQL Server; exact supported edition/version `UNKNOWN` | `PostgreSQL 18` |
| Desktop / Workspace | Windows shell and per-user process on `.NET`; toolkit `UNKNOWN` | Same as A | `.NET` Windows client/process, creating two primary runtime families |
| Artifact storage | Private object-storage Interface with provider Adapter selected later | Same as A | Same as A |
| Identity | OpenID Connect provider Adapter; concrete company provider `UNKNOWN` | Same as A | Same semantic Seam; library differs |
| Main benefit | One runtime family for Server/Desktop/Workspace; open relational database; good fit for Windows integration and typed product interfaces. | May align with an existing Microsoft operations/licensing environment. | Mature independent server ecosystem and preserves PostgreSQL option. |
| Main cost/risk | Company PostgreSQL operations/support capability must be confirmed; React build approach needs a bounded routing/data decision. | Licensing, edition and company availability are unknown; choosing it only for familiarity would not prove product fit. | Two server/client runtime families increase tooling, skills and contract-integration burden for a one-person project. |
| Current disposition | `RECOMMEND FOR TECH DECISION`, not approved | `RETAIN AS ALTERNATIVE` pending company infrastructure facts | `DO NOT PREFER` unless company standards or measured constraints justify it |

Profile A lifecycle facts were rechecked against official sources on 2026-09-03: `.NET 10` is an
active LTS release with support through 2028-11-14, and PostgreSQL major version 18 is current and
supported under its published versioning policy. React's official guidance permits a from-scratch
client with a build tool such as Vite when a full framework is not a fit, but warns that routing,
data loading and code splitting then remain application responsibilities. These facts support
evaluation only; company licensing, hosting, patching and skills evidence remain `UNKNOWN`.

Candidate semantic technology mapping:

| Concern | Candidate Implementation / Adapter | Required preservation |
|---|---|---|
| Product interfaces | Versioned HTTP/JSON commands and queries with generated OpenAPI description | Stable identities, expected-state preconditions, typed errors and idempotency |
| Relational persistence | PostgreSQL 18 Adapter behind Module repositories/unit of work | Owner boundaries, transaction, constraints, migrations and restore consistency |
| Artifact persistence | Provider-neutral private object-store Adapter | Immutable digest identity, private staging, scoped transfer and reconciliation |
| Company identity | OpenID Connect Adapter | Stable internal Actor/Organization mapping and owner authorization |
| Web interaction | React/TypeScript view models and semantic UI components | DOC-08 journeys, keyboard/focus, locale parity and no second authority |
| Windows interaction | .NET Desktop/Workspace Implementations | Per-user isolation, OS association, durable manifest and local-work safety |
| Format processing | Out-of-process Adapter runner | Exact profile/tool provenance, resource bounds and failure isolation |

## 12. Decisions, risks and constraints

| Record | ID | Decision/risk/constraint | Owner / treatment | Status |
|---|---|---|---|---|
| Accepted ADR | `IE-ADR-C1-001` | C1 remains independently useful and evolves from PDM to PLM before any platform dependency. | Architecture owner; preserve stable contracts without premature distributed design. | `Accepted` |
| Accepted ADR | `IE-ADR-C1-002` | No IDEA code runs inside design applications. | Desktop/Workspace/Format designs keep all execution external. | `Accepted` |
| Accepted ADR | `IE-ADR-C1-003` | Start the Server as a modular monolith with deep Modules. | Enforce Interface/schema ownership; split only on evidence. | `Accepted` |
| Accepted ADR | `IE-ADR-C1-004` | Immutable Generations and atomic Check-in Change Sets. | Transaction, staging, digest and idempotency design. | `Accepted` |
| Accepted ADR | `IE-ADR-C1-005` | Reservation binds document, actor, Workspace, lease and expected Generation. | Optimistic concurrency and explicit recovery; no binary auto-merge. | `Accepted` |
| Accepted ADR | `IE-ADR-C1-006` | Generic file control plus external Format Intelligence. | Versioned Capability Profiles and isolated Adapters. | `Accepted` |
| Proposed decision | `IE-ADR-C1-008` | Separate operational settings, governed policies and solution changes. | Product Decision Authority must approve the boundary/defaults before reliance. | `Proposed`; Tech input only |
| Tech choice | `TECH-STACK-001` | Choose Profile A, B, C or require another bounded comparison. | Product Decision Authority at Tech decision. | `NOT-RUN` |
| Risk | `ARCH-RSK-001` | Company deployment, identity, storage, licensing and support constraints are absent. | Obtain infrastructure facts before final Tech decision/PG3. | `BLOCKED` |
| Risk | `ARCH-RSK-002` | One author is also reviewer; architecture/security/operations specialist review is unavailable. | Record the limitation; assign review before any gate requiring independence. | `BLOCKED` |
| Risk | `ARCH-RSK-003` | Exact IRONCAD profile/tool version and isolated-processing entitlement are unknown. | Run a bounded non-production spike after exact environment/version is identified. | `BLOCKED` |
| Risk | `ARCH-RSK-004` | One Proposed source decision describes broader workflow-design scope than the current Core v0 Feature boundary. | The current instance follows the user-reviewed Feature Draft: seeded configurable workflow is required and a full graphical designer is deferred; Product Decision Authority resolves the source difference in the Feature decision. | `OPEN`; does not authorize the deferred feature |
| Constraint | `ARCH-CON-001` | Full graphical workflow design, bulk migration, general external integration and multisite behavior are outside Core v0. | Preserve configuration/interfaces without implementing deferred capability. | `Draft boundary` |

## 13. Verification and gate readiness

| Gate / verification item | Required evidence | Result |
|---|---|---|
| Feature prerequisite | Product Decision Authority decision on `FEATURE-001@0.2` | `NOT-RUN` |
| Spec prerequisite | Approved exact Spec baseline and resolved/owned requirement gaps | `NOT-RUN`; `SPEC-001@0.3` is Draft |
| Requirement consistency | Architecture traces every response to DOC-04 and does not weaken negative paths | Trace authored; review `NOT-RUN` |
| PG3 architecture review | Context, views, Hosts, Modules, Interfaces, quality responses, data, deployment, security, risks and ADR status | Draft authored; review `NOT-RUN` |
| Technology comparison | At least one realistic alternative plus lifecycle, licensing, skills, deployment and operations facts | Three profiles compared; company facts `BLOCKED` |
| Technical spikes | Transaction/fault injection, Workspace transfer/recovery, exact format profile and restore feasibility | Planned through VVP; execution `NOT-RUN` |
| Increment readiness | DOC-07 pins bounded scope, tests, migration/recovery and rollback after approved Feature/Spec/Tech | `BLOCKED` until decisions pass |
| Change impact | CHG/Work Item covers requirement, data, interface, UX, security, test, operation and release impact | CHG identity `UNKNOWN`; required before material change/PG4 |

## 14. Typed trace, supporting records and rendition controls

| Link type | Target and purpose | Result |
|---|---|---|
| `SOURCE-NEED` / `SOURCE-DECISION` | DOC-04 requirements; accepted ADRs; approved Feature/Spec decisions | Requirements/ADRs linked; Feature/Spec decisions `NOT-RUN` |
| `SOURCE-EVIDENCE` | DOC-02 options, DOC-06 data contracts, DOC-08 interaction design and official technology lifecycle sources | Draft sources linked; operational/company evidence `BLOCKED` |
| `DOWNSTREAM` | DOC-06 realization constraints, DOC-07 increments, DOC-08 surfaces and future implementation contracts | Architecture response authored; downstream reconciliation required on change |
| `CHANGE` | CHG/Work Item with architecture, data, interface, UX, risk, tests, operations and release impact | Initial Draft; no CHG yet |
| `VERIFICATION` | VVP/VEV requirement, quality, security, recovery, format and interaction evidence | VVP Draft exists; execution `NOT-RUN` |
| `RELEASE` | REL exact source/technology/build baseline and authorized scope | `NOT APPLICABLE` at analysis/design stage |
| `RENDITION` | Source-pinned DOCX/PDF with current/stale/superseded/withdrawn state | No rendition created |

An architecture statement cannot override DOC-04. A technology selection cannot silently add a
Feature or weaken acceptance/failure behavior. Any changed source baseline makes an earlier Tech
brief/rendition stale until its manifest and impact are reviewed.

<!-- AUTHOR CONTENT END -->

## Contract references

- [Core document catalogue](../../../../specs/003-controlled-documentation/contracts/document-catalogue.md)
- [Evidence and trace](../../../../specs/003-controlled-documentation/contracts/evidence-and-trace.md)
- [Gate package](../../../../specs/003-controlled-documentation/contracts/gate-package.md)
- [Project domain language](../../../../CONTEXT.md)
