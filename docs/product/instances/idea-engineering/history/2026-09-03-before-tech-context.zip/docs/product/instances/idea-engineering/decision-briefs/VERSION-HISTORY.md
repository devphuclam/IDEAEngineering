# Phiên bản và nguồn của Feature / Spec

Ngày ghi: 03-09-2026. Bộ tài liệu: IDEA-C1-ANALYSIS-DESIGN-001.

Đây là sổ tra cứu phiên bản, nguồn và xác nhận review nội bộ. Không phải báo cáo kiểm thử,
quyết định Feature/Spec/Tech của sếp hoặc một nguồn yêu cầu mới.

## 1. Bản làm việc hiện tại

| Tài liệu | Phiên bản hiện tại | Trạng thái |
|---|---|---|
| [Feature](FEATURE-001-feature-definition-and-scope.md) | FEATURE-001@0.3 | Draft; review nội bộ PASS ngày 03-09-2026; quyết định của sếp NOT-RUN |
| [Spec](SPEC-001-product-specification.md) | SPEC-001@0.4 | Draft; review nội bộ PASS ngày 03-09-2026; tám điểm còn mở chưa được giải quyết; quyết định của sếp NOT-RUN |
| [Tech](TECH-001-technology-and-architecture-proposal.md) | TECH-001@0.2 | Giữ nguyên; chưa có quyết định Spec làm điều kiện; không được coi là đã duyệt |

Feature 0.3 giữ 14 mã FTR. Spec 0.4 giữ 61 mã REQ và mức ưu tiên hiện có, đưa yêu cầu và điều kiện
kiểm tra về cạnh nhau. Phần giải thích không tự tạo thêm thẩm quyền hoặc thay quy tắc của nguồn.

## 2. Bản được giữ lại

| Bản lịch sử | Tình trạng tại lúc giữ lại | Cách sử dụng |
|---|---|---|
| [FEATURE-001@0.2](FEATURE-001-feature-definition-and-scope.v0.2.md) | Proposed; đã được anh review; sếp chưa quyết định Feature | Dùng để xem lại nội dung được review trước đây. Không chuyển kết quả đó sang Feature 0.3. |
| [SPEC-001@0.3](SPEC-001-product-specification.v0.3.md) | Draft; anh đã rút đồng ý và yêu cầu viết lại cấu trúc Spec | Không sử dụng như Spec đã được duyệt. Bản lưu giữ cả thông tin rút đồng ý. |

Hai bản lịch sử được sao chép nguyên nội dung trước khi biên tập. Các liên kết tương đối bên trong
vẫn được giữ; khi một liên kết trỏ đến tên file hiện hành, phải đọc kèm phiên bản được nêu trong
bản lịch sử và bảng này, không mặc nhiên coi bản mới là nội dung đã được review lúc trước.

### Bản trình trước khi ghi nhận lời duyệt

| Bản đã được xem xét | Mục đích giữ lại |
|---|---|
| [FEATURE-001@0.3 — bản trình](FEATURE-001-feature-definition-and-scope.v0.3-review-input.md) | Giữ đúng nội dung anh đã duyệt; trạng thái “chờ review” trong bản chụp là trạng thái lúc trình, trước xác nhận tại mục 5. |
| [SPEC-001@0.4 — bản trình](SPEC-001-product-specification.v0.4-review-input.md) | Giữ đúng 61 yêu cầu và tám điểm còn mở tại thời điểm anh duyệt; không biến điểm còn mở thành đã giải quyết. |

Các bản hiển thị hiện hành chỉ được cập nhật thông tin review. Không thay nội dung tính năng,
yêu cầu, điều kiện kiểm tra hoặc danh sách điểm còn mở. Số phiên bản nội dung giữ nguyên; dấu kiểm
tra file hiện hành thay đổi do phần ghi nhận review và được ghi riêng dưới đây.

### Dấu kiểm tra nội dung

| Bản tài liệu | SHA-256 tại lần ghi này |
|---|---|
| FEATURE-001@0.2 — bản lưu | ec7c4fc1764123c9bcaadc612e9154f874326e8ead6482d2ebf2b11606b92612 |
| SPEC-001@0.3 — bản lưu | 1bd4a1c5798127d35fe4169aeeeffd6cade061643ff92681653a59d5a403533a |
| FEATURE-001@0.3 — bản trình được duyệt | 30f144b3071abd106709a0073276c330d2e72f194dcac24204815b6525cf5e6a |
| FEATURE-001@0.3 — sau ghi nhận review | 4d222a4df8cf2b0fbdca5c3bbfa9bcab9a3089fac71d83b7839c8fb9cb470772 |
| SPEC-001@0.4 — bản trình được duyệt | 368460c04131cbe5660dc58c0e8d150073a6813b6a47f6472f2887b3fdd9db6a |
| SPEC-001@0.4 — sau ghi nhận review | b8859ff45c2b76da751d981ac42a7d9d03b84bac86b75250c3e5ea19ce2a3ccd |

Dấu kiểm tra của các bản lưu khớp với nội dung trước lần biên tập hoặc ghi nhận review tương ứng.
SHA-256 chỉ giúp xác định
đúng nội dung và phát hiện thay đổi, không chứng minh tài liệu đã được review hay phần mềm đã đạt.

## 3. Nguồn được dùng trong hai bản mới

Các DOC và supporting record bên dưới đều được giữ nguyên ở nội dung Draft 0.1 trong lần viết lại.
Danh sách này ghim cả phiên bản và nội dung để nhận biết nguồn bị thay đổi mà chưa đổi số phiên bản.

| Nguồn | Mã / phiên bản | Được dùng cho | SHA-256 |
|---|---|---|---|
| [DOC-01](../DOC-01-product-vision-and-scope.md) | IE-PROD-VISION-001@0.1 — Draft | Feature | b9e67ad05b9f37dfdb560a1fc684ff84b53065b98fd945e553721146de2a0786 |
| [DOC-02](../DOC-02-feasibility-and-options-assessment.md) | IE-PROD-FEAS-001@0.1 — Draft | Feature | 70bd0176660a0b81ee0374435b6fc2e8a9a9a8a1087d5322e3335325576f01b1 |
| [DOC-03](../DOC-03-business-requirements.md) | IE-PROD-BREQ-001@0.1 — Draft | Feature; Spec | 9f7329b3d10e25308b4cd68f13d0fd7c40d8bf175355328af6984ec4ef592bcf |
| [DOC-04](../DOC-04-software-requirements-specification.md) | IE-PROD-SREQ-001@0.1 — Draft | Spec — nguồn 61 mã REQ; liên kết FTR → REQ của Feature | 5c722590d08e6dbdf841aef1c4cf5d99042093e221d8890630c610bea8b8e3a3 |
| [DOC-06](../DOC-06-data-integration-and-migration-specification.md) | IE-PROD-DATA-001@0.1 — Draft | Spec — dữ liệu và giao tiếp | 35f8c9ac3b97981e8260c36f51b4a8553914c6cd68bd8457d46c1f91faa6ea38 |
| [DOC-07](../DOC-07-mvp-roadmap-and-delivery-plan.md) | IE-PROD-ROADMAP-001@0.1 — Draft | Feature | 7672b4e71a112ec05e7f9d56fc1a7a61f2121edf9acb3fae044482d48483de75 |
| [DOC-08](../DOC-08-ui-ux-and-interaction-specification.md) | IE-PROD-UX-001@0.1 — Draft | Spec — giao diện và ngôn ngữ | cad6bcfdf2917cd5b65c0ee15b05e18c4eb880190b3d80015616cb0c0f6b0916 |
| [GOV](../registers/GOV-material-and-behavioral-coverage.md) | IE-GOV-COVERAGE-001@0.1 — Draft | Feature | 0e8c0ddba8eb5058af718ceab34fd8896cf72f1b07ef28a9d6d38bf3084a7f68 |
| [VVP](../registers/VVP-core-v0-verification-validation-plan.md) | IE-VVP-CORE-001@0.1 — Draft | Spec — kế hoạch kiểm tra | e1c7c30d457504d21bc7eee6547962165ed33fe98771a79afdbecb20ad0a037e |
| [CONTEXT.md](../../../../../CONTEXT.md) | Bản làm việc ngày 03-09-2026; không tự gán Document Version | Thuật ngữ, ranh giới sản phẩm và làm việc offline trong Spec | d1edce5278ee732bbc4a2b88719be4c270f50e2f34b8d9f6be3a5135025b4bcd |

Feature 0.3 kế thừa mã FTR từ Feature 0.2 (bản lưu có dấu kiểm tra tại mục 2), đối chiếu nhu cầu/quy
tắc nghiệp vụ ở DOC-03 và trace ở DOC-04. Spec 0.4 còn phụ thuộc phạm vi FEATURE-001@0.3; dấu kiểm
tra của Feature cũng nằm tại mục 2.
Không có nguồn trong bảng này được đổi trạng thái sang Approved.

## 4. Các tham chiếu cũ và việc cần cập nhật sau review

DOC-03 và DOC-07 bản 0.1 vẫn có dòng nói FEATURE-001@0.2 đã qua self-review; một số nguồn khác còn
tham chiếu SPEC-001@0.3. Những dòng đó áp dụng cho phiên bản lịch sử, không xác nhận mức sẵn sàng
của Feature 0.3 hoặc Spec 0.4.

Lần này không sửa DOC-01…08, GOV, VVP, Tech, prototype, CONTEXT.md hoặc các file Spec Kit.
Tệp README của bộ tài liệu được cập nhật để chỉ rõ bản đang dùng và trạng thái review hiện tại.

Trước khi trình một bộ tài liệu để quyết định:

1. Review nội bộ hai bản đã được ghi nhận tại mục 5. Tiếp tục giải quyết hoặc ghi quyết định có
   điều kiện cho các mục còn mở đúng phạm vi và thẩm quyền; không tự ghi điểm chưa giải quyết là đạt.
2. Nếu nội dung thay đổi yêu cầu hoặc phạm vi, cập nhật tài liệu nguồn, phiên bản và liên kết theo
   quy trình kiểm soát; không chỉ sửa riêng bản trình sếp.
3. Đồng bộ các dòng chỉ trạng thái/phụ thuộc cũ trong DOC-03/04/05/07 và các nguồn liên quan.
4. Ghim lại đúng phiên bản/nội dung, ghi người review và quyết định Feature → Spec → Tech.
5. Khi nguồn đổi, đánh dấu bản trình cần đối chiếu lại; không giữ nguyên kết quả duyệt của nội dung cũ.

Việc có đủ bản nháp không cho phép bắt đầu production code hoặc sử dụng hệ thống thật.

## 5. Ghi nhận review nội bộ ngày 03-09-2026

| Trường | Nội dung ghi nhận |
|---|---|
| Mã ghi nhận | RVW-FEATURE-SPEC-20260903-001 |
| Người review | Người dùng dự án — reviewer nội bộ đã được phân công; không ghi nhận như người duyệt độc lập hoặc Product Decision Authority |
| Ngày ghi nhận | 03-09-2026 |
| Xác nhận trực tiếp | “ok con dê duyệt nha” |
| Tài liệu được duyệt | FEATURE-001@0.3 và SPEC-001@0.4, đúng hai bản trình đã lưu tại mục 2 |
| Phạm vi / kết quả | PASS — chấp thuận hai bản thảo trong review nội bộ; không phải kết quả kiểm thử sản phẩm hoặc kết luận mọi yêu cầu đã đủ điều kiện triển khai |
| Điểm còn mở | SPEC-OPEN-01…08 giữ nguyên; không tự đóng, không tự bổ sung giá trị hoặc bỏ điều kiện |
| Quyết định của sếp | Feature và Spec vẫn NOT-RUN; lời duyệt này không được ghi thay quyết định của sếp |
| Phần không nằm trong xác nhận | Tech, review độc lập/chuyên môn, kiểm thử, các gate và cho phép viết production code hoặc sử dụng thật |
| Thay đổi khi ghi nhận | Chỉ cập nhật thông tin review và điều hướng/hashes; giữ nguyên phiên bản nội dung, danh mục tính năng, yêu cầu và điều kiện kiểm tra |
| Lịch sử trước đó | Không kế thừa review FEATURE-001@0.2; không phục hồi lời đồng ý đã rút đối với SPEC-001@0.3 |

Dấu kiểm tra của bản trình được duyệt và của file sau khi cập nhật review được ghi tách biệt tại
mục 2. Mọi thay đổi nội dung sau xác nhận này cần được đối chiếu và review cho đúng phiên bản mới;
không dùng lời duyệt hiện tại cho một nội dung được sửa sau đó.
