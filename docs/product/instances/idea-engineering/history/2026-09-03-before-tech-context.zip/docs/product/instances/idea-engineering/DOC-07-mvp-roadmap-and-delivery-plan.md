DOC-07

# IDEA Engineering Analysis, Design and Core v0 Delivery Roadmap

> **Instance state**: controlled `Draft 0.1`. This roadmap plans work and decision presentations. It
> does not create or approve Feature, Spec or Tech content by schedule assertion, and it does not
> authorize production implementation or release.

## Control envelope

| Field | Recorded value |
|---|---|
| Stable Document ID | `IE-PROD-ROADMAP-001` |
| Document Class | `DOC-07` |
| Title | IDEA Engineering Analysis, Design and Core v0 Delivery Roadmap |
| Owner | `Principal Product Author`; named person attribution `BLOCKED` before `Proposed` |
| Document Status | `Draft` |
| Document Version | `0.1` |
| Applicable Baseline | `IDEA-C1-ANALYSIS-DESIGN-001` |
| Effective Date | `NOT APPLICABLE` until approval |
| Authors | `Principal Product Author`; named identity to be recorded before `Proposed` |
| Reviewers | `Author Self-Reviewer` only; this is not independent review |
| Approvers | `Product Decision Authority` decides Feature, Spec and Tech; named identity and decision dates are not yet recorded |
| Source Links | [Product templates](../../definition/README.md), [domain language](../../../../CONTEXT.md), [architecture baseline](../../../architecture/idea-product-lifecycle-architecture.md), [design lessons](../../knowledge/idea-design-lessons.md) |
| Downstream Links | Planned DOC-01…DOC-08 instances, three decision briefs, supporting records, later implementation increments |
| Evidence / Claim Status | `IDEA DECISION` for accepted planning rules; execution and gate evidence remains `NOT-RUN` |
| Change History | Initial controlled draft for `IDEA-C1-ANALYSIS-DESIGN-001`; no prior version |
| Access Classification | `INTERNAL` |
| Retention Rule | Retain with the product-definition baseline; exact organizational retention period is `UNKNOWN`, owner `Product Decision Authority`, review trigger before `Approved` |
| Content State | `COMPLETE CONTROLLED DRAFT` with explicit unresolved actions |

## Indexed increment identity

The rows in this version are roadmap candidates. Before an increment becomes `Proposed`, it receives
an independent controlled increment record with its source baseline, owner, version, gate, trace and
exit evidence. The roadmap index is navigation only.

| Increment Record ID | Source Roadmap Baseline | Status | Version | Owner | First / later gate | Requirement and design trace | Exit evidence |
|---|---|---|---|---|---|---|---|
| `IE-INC-FEATURE-001` | `IE-PROD-ROADMAP-001@0.1` | `Draft` | `0.1` | Principal Product Author | `PG1` / `PG2` on material scope change | DOC-01/02/03, coverage records, `FEATURE-001` | Feature decision, source pins and open-action disposition |
| `IE-INC-SPEC-001` | `IE-PROD-ROADMAP-001@0.1` | `Draft` | `0.1` | Principal Product Author | `PG2` / `PG3` on requirement change | DOC-03/04/06/08, `SPEC-001` | Spec decision, trace and V&V readiness |
| `IE-INC-TECH-001` | `IE-PROD-ROADMAP-001@0.1` | `Draft` | `0.1` | Principal Product Author | `PG3` / `PG4` on technology change | DOC-02/04/05/06/08, ADRs, `TECH-001` | Tech decision, architecture review and risk disposition |
| `IE-INC-READY-001` | `IE-PROD-ROADMAP-001@0.1` | `Draft` | `0.1` | Principal Product Author | `PG4` | Approved Feature/Spec/Tech baselines and supporting records | Bounded implementation plan, tests, migration/recovery and gate result |

<!-- AUTHOR CONTENT START -->

## 1. Roadmap intent and constraints

| Field | Recorded value |
|---|---|
| Roadmap objective | Produce decision-ready Feature, Spec and Tech baselines for the first production implementation of the existing Core v0 MVP Release Spine, then establish `PG4` readiness without writing production code early. |
| Source product baseline | `IDEA-C1-ANALYSIS-DESIGN-001`; fixed reference-product public baseline dated 2026-08-26; target-runtime semantics remain explicitly unverified. |
| Planning assumptions | One Principal Product Author performs preparation and self-review. The boss acts as Product Decision Authority for Feature, Spec and Tech. Independent and specialist evidence is unavailable unless separately assigned. |
| Constraints | Internal-company product; clean-room behavioral design; eight Core Product Documents remain detailed authority; three Vietnamese decision briefs are the boss-facing views; English Markdown remains editable authority; no production implementation before applicable gates. |
| Planning horizon | Analysis and design through `PG4`, followed by candidate vertical slices that remain unauthorized until `PG4` passes. |

## 2. Decision presentation plan

The Product Decision Authority reads three concise briefs, not the complete eight-document source
set. Each brief pins its exact source versions and presents one decision axis only.

| Presentation | Purpose | Required preparation | Demonstration / evidence | Requested boss decision | Readiness |
|---|---|---|---|---|---|
| `FEATURE-001` | Confirm Core v0 capability scope, priority and exclusions | DOC-01/02/03 drafts, closed material inventory, coverage dispositions, updated DOC-07 | Accepted interactive prototype as design evidence; feature map and deferred-scope list | Approve, require changes, defer or reject the Feature baseline | `READY FOR FEATURE DECISION`: `FEATURE-001@0.2` passed author self-review; Product Decision Authority decision remains `NOT-RUN` |
| `SPEC-001` | Confirm observable behavior, rules, failure handling and acceptance | Approved Feature baseline; DOC-04 plus requirement-bearing DOC-06/08 content; VVP trace | Release Spine scenarios including stale, unauthorized, wrong-workspace and recovery paths | Approve, require changes, defer or reject the Spec baseline | `BLOCKED`: sources are authored at Draft; Feature decision and SPEC self-review remain prerequisites |
| `TECH-001` | Confirm architecture and technology choices | Approved Spec baseline; DOC-02/04/05/06/08 design; technology ADRs and risk analysis | Architecture views, deployable hosts, data flow, candidate comparison and bounded technical spikes | Approve, require changes, defer or reject the Tech baseline | `BLOCKED`: sources are authored at Draft; Spec decision, TECH self-review and company infrastructure facts remain prerequisites |

The briefs may be rendered as DOCX or PDF for the meeting. A rendition never replaces its pinned
Markdown source. A changed source makes the earlier rendition `Stale`.

## 3. Bounded analysis and design increments

| Increment ID | Objective and scope | Required baseline | Dependencies | Owner | Gate | Status |
|---|---|---|---|---|---|---|
| `IE-INC-FEATURE-001` | Author vision, feasibility, business needs, coverage and the Feature brief | DOC-01/02/03, DOC-07, GOV coverage | Named source identities; fixed public baseline; Product Decision Authority availability | Principal Product Author | `PG1` | `Draft` |
| `IE-INC-SPEC-001` | Translate approved scope into verifiable functional, information, quality, security, operational, localization and interaction requirements | Approved Feature decision; DOC-03/04/06/08; VVP/RSK | Feature stability; explicit thresholds or owned `UNKNOWN` values | Principal Product Author | `PG2` | `Draft` |
| `IE-INC-TECH-001` | Select architecture and technology against approved requirements | Approved Spec decision; DOC-02/04/05/06/08; ADR/RSK | Spec stability; official lifecycle/support evidence; deployment constraints | Principal Product Author; boss decides Tech | `PG3` | `Draft` |
| `IE-INC-READY-001` | Establish a bounded, testable and recoverable implementation increment | Approved Feature, Spec and Tech; DOC-07; VVP/RSK/CMP/CHG | Named implementation scope; test, migration, rollback and review readiness | Principal Product Author | `PG4` | `Draft` |

### 3.1 Candidate implementation vertical slices after PG4

These slices are planning candidates only. They do not authorize code.

1. **Controlled identity** — Logical Document, metadata, numbering, Artifact, immutable Generation
   and Audit Evidence foundations.
2. **Safe workspace publish** — Store Existing first, then New on the same model; Checkout,
   Reference, Check-in, stale conflict, recovery and local-work preservation.
3. **Engineering release** — Structure Snapshot, review, independent Approval, Release Record,
   Controlled Release Package and exact reproduction.
4. **Format depth** — Generic controlled-file baseline plus the first deep IRONCAD capability profile,
   without executing IDEA code inside the design tool.
5. **Internal pilot and UX hardening** — Canonical demo first; representative internal evidence only
   when a pilot project and eligible participants are assigned.

## 4. MVP Release Spine

| Step | Required proof | Planned baseline / identity | Negative path and recovery | Evidence / result |
|---|---|---|---|---|
| New or Store Existing Product Definition | Stable Logical Document registration; Store Existing delivered first | Future approved Spec baseline | Duplicate candidates are shown; no silent identity merge | `NOT-RUN` |
| Obtain Checkout or Reference workspace scope | User confirms exact per-document access mode | Future Workspace Manifest and expected Generation | Conflict rejects the confirmed scope; excluded scope requires reconfirmation | `NOT-RUN` |
| Edit through external application boundary | Ordinary files open through OS association; no code inside design tools | Future Managed Workspace baseline | Offline/local changes remain visible and recoverable | `NOT-RUN` |
| Publish exact Generation and Structure Snapshot | Atomic Check-in Change Set; immutable Generation; exact structure pins | Future Check-in operation and Generation identities | Stale, wrong-owner, wrong-workspace or unresolved changes fail closed and preserve local work | `NOT-RUN` |
| Complete successful Check-in | Changed or semantic `NoChange` result is explicit | Confirmed Check-in scope | Successful Check-in releases Reservations in scope; failed Check-in retains valid entitlement and local files | `NOT-RUN` |
| Create Business Revision evidence | New Revision follows approved policy and retains predecessor trace | Future Revision and lightweight change record | Invalid or unauthorized revision creation fails closed | `NOT-RUN` |
| Independent review and Approval | Approval pins one exact Generation and policy version | Future Workflow Instance and Approval Decision | Missing eligible actor blocks; self-review is not independent approval | `NOT-RUN` |
| Release Record and Controlled Release Package | Exact scope passes gates and produces immutable evidence | Future Release Record | Stale, unauthorized or incomplete scope rejects the complete release | `NOT-RUN` |
| Reproduce and restore exact released baseline | Package, manifest, digests and structure recreate the pinned baseline | Future release/restore evidence | Failed restore remains visible and cannot become PASS | `NOT-RUN` |

## 5. Gate prerequisites and exit evidence

| Gate | Required inputs | Exit evidence | Conditional action / owner / trigger | Outcome |
|---|---|---|---|---|
| `PG1` | DOC-01/02/03, coverage inventory/dispositions, DOC-07, `FEATURE-001` | Feature decision pinned to exact source baseline; open scope actions recorded | Present `FEATURE-001@0.2` and record Product Decision Authority identity/decision; Principal Product Author; at Feature presentation | `NOT-RUN` |
| `PG2` | Approved Feature baseline; DOC-04/06/08 requirements; VVP and RSK trace; `SPEC-001` | Spec decision, acceptance/verification trace and owned requirement gaps | Establish measurable pilot targets where evidence permits; Principal Product Author/Product Decision Authority; before Spec presentation | `NOT-RUN` |
| `PG3` | Approved Spec baseline; DOC-02/05/06/08 design; architecture review; `TECH-001` | Tech decision, selected Stack Profile, ADRs and residual-risk disposition | Confirm deployment/identity/storage constraints and eligible review; Principal Product Author/Product Decision Authority; before Tech presentation | `NOT-RUN` |
| `PG4` | Approved three-axis baseline; bounded increment; test, migration, rollback, security and change readiness | Implementation-ready package with no hidden blocker and exact source pins | Assign any required independent/specialist review or keep gate `BLOCKED`; Principal Product Author; before production coding | `NOT-RUN` |
| `PG5`–`PG7` | Implemented, verified and operational baselines | Verification, release, restore and pilot evidence | Outside current analysis/design authorization | `NOT-RUN` |

## 6. Acceptance, migration and rollback

| Concern | Required evidence | Baseline pin | Owner | Status |
|---|---|---|---|---|
| Decision acceptance | Separate boss disposition for Feature, Spec and Tech | Exact decision brief plus source manifest | Product Decision Authority | `NOT-RUN` |
| Requirement acceptance | Scenario, acceptance criterion and verification method for every approved obligation | `IE-PROD-SREQ-001@0.1` and `IE-VVP-CORE-001@0.1` | Principal Product Author | Draft authored; review/approval `NOT-RUN` |
| Migration / reconciliation | Store Existing duplicate handling, staging cleanup, digest validation and reconciliation | `IE-PROD-DATA-001@0.1` / future approved Spec baseline | Principal Product Author | Draft authored; execution `NOT-RUN` |
| Rollback / recovery | Stale conflict, preserved local work, Reservation Recovery, failed publish and restore procedures | DOC-04/05/06 and VVP Draft baselines | Principal Product Author | Draft authored; procedures not executed |
| Operational handoff | Deployment, support, backup/restore, monitoring and named operational authority | Future Tech/OPS baseline | `UNKNOWN` owner; review at `PG3`/`PG4` | `BLOCKED` |

## 7. MVP Success Metric Set

| Metric ID | Required outcome | Exact scope / baseline | Evidence method | Result |
|---|---|---|---|---|
| `MSM-001` | Exact released baseline reproduces with matching identities, structure and digests | Canonical Demo Dataset and exact Release Record | Automated manifest/digest comparison plus controlled walkthrough | `NOT-RUN` |
| `MSM-002` | Zero stale, unauthorized, wrong-workspace or wrong-scope publishes/releases are accepted in the approved negative-path set | Approved Spec and VVP scenario set | Repeatable negative-path tests | `NOT-RUN` |
| `MSM-003` | Rejected local work remains recoverable after every tested conflict and interruption | Approved workspace/recovery scenarios | File/digest evidence before and after rejection/recovery | `NOT-RUN` |
| `MSM-004` | Every accepted publish, approval and release has complete actor, policy, source-pin and Audit Evidence | Approved audit completeness rules | Evidence-ledger reconciliation | `NOT-RUN` |
| `MSM-005` | Tested metadata and Artifact baseline restores consistently | Approved backup/restore scenario | Controlled restore drill and digest verification | `NOT-RUN` |

Capacity, latency, availability, RPO and RTO values remain `UNKNOWN` until a representative internal
pilot context exists. The owner is the Principal Product Author with Product Decision Authority
review; the trigger is Spec preparation before a claim requires a measurable threshold.

## 8. Deferred scope and change control

| Deferred item | Disposition | Rationale / risk | Review trigger | Trace |
|---|---|---|---|---|
| Advanced search and saved-query administration | `DEFER` | Not required to prove the first Release Spine; basic find/browse remains required | After identity and safe publish vertical slices | Coverage record and future requirement |
| Workflow designer implementation | `DEFER` | Configurable workflow semantics belong in Spec; full designer is not needed before core release proof | After seeded release workflow is verified | Future DOC-04/05/08 and coverage record |
| ERP/MRP exchange and supported external API | `DEFER` | No approved integration consumer or contract exists | Concrete internal integration requirement | Future DOC-06/change record |
| Multisite replication and offline command replay | `DEFER` | Consistency, recovery and operational requirements are not established | Approved multisite need and topology | Future DOC-04/05/06 |
| Automated purge and broad operations tooling | `DEFER` | Retention and recovery policy are incomplete | Approved retention/operations requirements | Future RSK/OPS/REL |
| Full ECR/ECO capability | `DEFER` | Core v0 uses a lightweight change record and exact release evidence | Approved PLM change-management increment | Future DOC-01/03/04/07 |
| Additional deep CAD profiles | `DEFER` | First profile proves the adapter seam; breadth follows evidence | Successful IRONCAD profile and prioritized tool request | DOC-02 capability assessment |

Every evidenced reference capability omitted from Core v0 must still receive a controlled coverage
disposition. Deferral does not erase the long-term target.

## 9. Internal-company value and claim boundary

| Value/claim area | Required treatment | Status |
|---|---|---|
| Internal engineering outcome | Measure control, integrity, release-risk, quality, maintainability or evidenced efficiency | Reference-backed hypothesis; internal validation `BLOCKED` |
| Technical evidence | Pin dataset, environment, identities, scope, result and limitation | `NOT-RUN` |
| Representative adoption | Requires named pilot group, project, users and Internal Adoption Authority | `BLOCKED` |
| Commercial objective | Pricing, revenue, acquisition, market share, market fit and external buyers | `NOT APPLICABLE` |

## 10. Pilot and rollout claim boundary

| Claim status | Required evidence and authority | Current result |
|---|---|---|
| Canonical Demo Dataset | Approved synthetic data and exact technical evidence | `NOT-RUN` |
| Technical Pilot Verification | Bounded non-production execution with exact identities and environment | `NOT-RUN` |
| Single-Actor Functional Acceptance | One person may operate separate test identities; evidence remains limited | `NOT-RUN` |
| Internal Operational Need Validation | Representative internal roles and attributable need evidence | `BLOCKED`: group/project not assigned |
| Internal Pilot Acceptance | Representative evidence and named Internal Adoption Authority | `BLOCKED` |
| Operational rollout authorization | Exact released scope, accepted residual risk and recovery readiness | `BLOCKED`; outside current stage |

## 11. Typed trace, supporting records and rendition controls

| Link type | Target and purpose | Result |
|---|---|---|
| `SOURCE-DECISION` | Accepted constitution, product ADRs and stakeholder decisions establishing internal scope, Release Spine and three boss decision axes | Linked at repository baseline; exact decision ledger to be instantiated before `Proposed` |
| `SOURCE-EVIDENCE` | Product knowledge, reference-coverage records and prototype evidence | Knowledge sources and `IE-GOV-COVERAGE-001@0.1` exist; exact target-runtime evidence remains `BLOCKED` |
| `DOWNSTREAM` | DOC-01…DOC-08, three decision briefs and later increments | Eight Core Drafts, three brief Drafts and initial GOV/VVP records instantiated |
| `CHANGE` | CHG/Work Item and successor baseline | Initial draft; CHG instance `UNKNOWN`, owner Principal Product Author, trigger before `Proposed` |
| `VERIFICATION` | VVP/VEV gate and Release Spine evidence | `NOT-RUN` |
| `RELEASE` | REL manifest for a future implementation/release | `NOT APPLICABLE` to this draft |
| `RENDITION` | DOCX/PDF source pin, rendition date/status/classification | No rendition generated |

<!-- AUTHOR CONTENT END -->

## Contract references

- [DOC-07 class template](../../definition/DOC-07-mvp-roadmap-and-delivery-plan.md)
- [Core document catalogue](../../definition/README.md)
- [Gate package contract](../../../../specs/003-controlled-documentation/contracts/gate-package.md)
- [Control fields and status](../../../../specs/003-controlled-documentation/contracts/control-fields-and-status.md)
- [Project domain language](../../../../CONTEXT.md)
