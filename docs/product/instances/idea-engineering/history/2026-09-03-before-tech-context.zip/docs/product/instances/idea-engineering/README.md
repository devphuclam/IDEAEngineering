# IDEA Engineering Product-Definition Instance Set

This directory contains the controlled working instances for the internal IDEA Engineering product.
The instruction-only class templates remain under [`docs/product/definition`](../../definition/README.md)
and are not edited as product content.

## Baseline

| Field | Value |
|---|---|
| Baseline ID | `IDEA-C1-ANALYSIS-DESIGN-001` |
| Purpose | Analysis and design through `PG4`; no production implementation authorization |
| Product boundary | Internal IDEA Engineering `C1` product |
| Principal author | `Principal Product Author`; named person attribution must be recorded before `Proposed` |
| Self-review | `Author Self-Reviewer`; not independent review |
| Product decision authority | `Product Decision Authority` for Feature, Spec and Tech decisions |
| Editable authority | English Markdown source under version control |
| Boss-facing language | Vietnamese decision briefs, with common technical terms retained |
| Initial document status/version | `Draft 0.1` |
| First approved version | `Approved 1.0` after the applicable controlled decision |

## Two-layer reading model

The eight Core Product Documents are the detailed internal authority used by the Principal Product
Author. The Product Decision Authority is not expected to read all eight documents. Three
decision briefs present the scope, requirements and technology choices and pin their source versions.
The Spec brief includes individually identified requirements and verification conditions, not only
an executive summary:

| Boss-facing brief | Decision axis | Detailed source set | Current state |
|---|---|---|---|
| [`FEATURE-001`](decision-briefs/FEATURE-001-feature-definition-and-scope.md) | Feature scope and priority | DOC-01, DOC-02, DOC-03, DOC-07 and the governed reference-coverage records | `Draft 0.3`; rewritten feature catalogue and boundaries; current-version internal draft review `PASS` on 2026-09-03; boss decision `NOT-RUN` |
| [`SPEC-001`](decision-briefs/SPEC-001-product-specification.md) | Required product behavior and acceptance | DOC-04, requirement-bearing DOC-06 and DOC-08 content, VVP | `Draft 0.4`; 61 identified requirements with verification conditions; current-version internal draft review `PASS` on 2026-09-03; prior 0.3 acceptance withdrawn; boss decision `NOT-RUN`; Feature decision and unresolved specification gaps remain prerequisites |
| [`TECH-001`](decision-briefs/TECH-001-technology-and-architecture-proposal.md) | Architecture and technology selection | DOC-02, DOC-04/05/06/08, accepted ADRs and official technology lifecycle sources | `Draft 0.2`; sources authored; blocked by Spec decision, TECH self-review and company infrastructure facts |

A decision brief is a controlled decision view, not a second requirement or architecture authority.
It becomes `Stale` when any pinned source version changes. A boss decision identifies the exact brief
and source baseline, and the Principal Product Author then applies that decision to the affected Core
Product Documents.

## Current review and retained versions

FEATURE-001@0.3 and SPEC-001@0.4 were rewritten on 2026-09-03 at the user's request. The user then
explicitly accepted both presented drafts: “ok con dê duyệt nha”. Internal draft review is now
`PASS`, recorded as [RVW-FEATURE-SPEC-20260903-001](decision-briefs/VERSION-HISTORY.md#5-ghi-nhận-review-nội-bộ-ngày-03-09-2026).
This is a new user review, not an inherited result from FEATURE-001@0.2 or the withdrawn SPEC-001@0.3
acceptance. It is not a Product Decision Authority decision, independent/specialist review, test
result or gate PASS; all eight SPEC-OPEN items remain unresolved.

See the [version history and exact source hashes](decision-briefs/VERSION-HISTORY.md) for the active
paths, exact pre-review input snapshots and retained versions. Review metadata was updated without
changing the feature catalogue, requirements or open items. DOC-01…08, GOV and VVP remain at their
existing Draft 0.1 content, and
TECH-001@0.2 was not edited. Older source statements referring to FEATURE-001@0.2 or SPEC-001@0.3
are historical; they do not indicate readiness or acceptance of the current briefs. Refresh those
cross-document dispositions through the controlled workflow before a new decision baseline.

Current Spec gaps include Version versus Version Sequence, basic discovery requirements, initial
business configuration, supported formats, operational targets, environment and qualified reviewers.
Do not infer an approved definition, an implemented capability or permission to start production
code from the presence of a complete draft. Recheck Tech's prerequisites against the eventual Spec
decision before presenting Tech.

## Core instance catalogue

| Class | Stable Document ID | Planned instance | Current state |
|---|---|---|---|
| `DOC-01` | `IE-PROD-VISION-001` | [Product Vision and Scope](DOC-01-product-vision-and-scope.md) | `Draft 0.1` |
| `DOC-02` | `IE-PROD-FEAS-001` | [Feasibility and Options Assessment](DOC-02-feasibility-and-options-assessment.md) | `Draft 0.1` |
| `DOC-03` | `IE-PROD-BREQ-001` | [Business Requirements](DOC-03-business-requirements.md) | `Draft 0.1` |
| `DOC-04` | `IE-PROD-SREQ-001` | [Software Requirements Specification](DOC-04-software-requirements-specification.md) | `Draft 0.1` |
| `DOC-05` | `IE-PROD-ARCH-001` | [Architecture Description](DOC-05-architecture-description.md) | `Draft 0.1` |
| `DOC-06` | `IE-PROD-DATA-001` | [Data, Integration and Migration Specification](DOC-06-data-integration-and-migration-specification.md) | `Draft 0.1` |
| `DOC-07` | `IE-PROD-ROADMAP-001` | [MVP Roadmap and Delivery Plan](DOC-07-mvp-roadmap-and-delivery-plan.md) | `Draft 0.1` |
| `DOC-08` | `IE-PROD-UX-001` | [UI/UX and Interaction Specification](DOC-08-ui-ux-and-interaction-specification.md) | `Draft 0.1` |

## Supporting instance catalogue

| Class | Stable Record ID | Instance | Current state |
|---|---|---|---|
| `GOV` | `IE-GOV-COVERAGE-001` | [Material and Behavioral Coverage Register](registers/GOV-material-and-behavioral-coverage.md) | `Draft 0.1`; 16/16 public-baseline areas have explicit dispositions, target-runtime evidence remains `BLOCKED` |
| `VVP` | `IE-VVP-CORE-001` | [Core v0 Verification and Validation Plan](registers/VVP-core-v0-verification-validation-plan.md) | `Draft 0.1`; 14 planned objectives, execution `NOT-RUN` |

## Authoring and decision sequence

1. Author DOC-01, DOC-02, DOC-03, the governed reference-coverage records, and DOC-07.
2. Complete `FEATURE-001`; present only its exact pinned baseline for the Feature decision.
3. Author DOC-04 plus the requirement-bearing parts of DOC-06 and DOC-08.
4. Complete `SPEC-001`; present only its exact pinned baseline for the Spec decision.
5. Author DOC-05 plus the design-bearing parts of DOC-06 and DOC-08.
6. Complete `TECH-001`; present only its exact pinned baseline for the Tech decision.
7. Update DOC-07 and supporting GOV, CLR, RSK, VVP, VEV, CMP and CHG records for `PG4` readiness.
8. Do not create a production source tree until approved requirements, architecture and increment
   readiness satisfy the applicable gates.

No item in this directory currently records a boss approval or a gate `PASS`.
