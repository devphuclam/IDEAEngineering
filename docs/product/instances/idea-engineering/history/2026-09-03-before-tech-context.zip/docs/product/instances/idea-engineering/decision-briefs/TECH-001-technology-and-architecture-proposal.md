# TECH-001 — Đề xuất công nghệ và kiến trúc cho Core v0

Tài liệu này dùng để trình sếp duyệt **cách chúng ta sẽ xây Core v0 và bộ công nghệ dự kiến sử
dụng**. Bản này chưa cho phép bắt đầu viết production code. Trước khi trình duyệt chính thức, Feature
và Spec phải được duyệt đúng thứ tự, đồng thời các thông tin về hạ tầng công ty phải được bổ sung.

## 1. Nội dung đề nghị sếp duyệt

| Nội dung | Đề xuất |
|---|---|
| Cách tổ chức hệ thống | Bắt đầu bằng `modular monolith`: một IDEA Server nhưng chia thành các Module có trách nhiệm và dữ liệu riêng. Chỉ tách thành nhiều service khi có nhu cầu thực tế. |
| Server | `.NET 10 LTS` và `ASP.NET Core`. |
| Web UI | `React + TypeScript`; dùng Vite cho bản client ban đầu nếu không xuất hiện nhu cầu bắt buộc phải dùng một full-stack framework. |
| Database | `PostgreSQL 18` lưu metadata, identity, Product Structure, workflow, policy và Audit. |
| Lưu file | Private object storage lưu Artifact bất biến; ứng dụng chỉ truy cập qua Interface được cấp quyền, không truy cập thẳng storage. |
| Desktop và Workspace | Ứng dụng Windows cùng một tiến trình nền theo từng người dùng, viết bằng `.NET`, phụ trách Checkout, mở file, scan/hash, Check-in và recovery. |
| Đăng nhập | Kết nối hệ thống identity của công ty qua `OpenID Connect`; nhà cung cấp cụ thể sẽ chọn sau khi biết hạ tầng thật. |
| Xử lý CAD/Office | Chạy ngoài phần mềm thiết kế, trong tiến trình riêng có giới hạn tài nguyên; lỗi xử lý không được làm thay đổi file gốc. |

Đây là phương án được khuyến nghị để sếp xem xét, chưa phải kết luận đã phê duyệt.

## 2. Hệ thống sẽ được chia như thế nào?

```text
Người dùng
   │
   ├── IDEA Web ─────────────────────────┐
   │                                     │
   └── IDEA Desktop ↔ Workspace          │
              │                          │
              └──────────────► IDEA Server
                                      │
                       ┌──────────────┼──────────────┐
                       │              │              │
                  PostgreSQL    Object storage   Format worker
                   metadata       file gốc      xử lý cô lập
```

- **IDEA Server** là nơi quyết định trạng thái chính thức của tài liệu, Generation, Product
  Structure, workflow, Approval và Release.
- **IDEA Web** dùng để tìm, xem, review, approve và quản trị theo quyền.
- **IDEA Desktop** thể hiện ý định của người dùng: Checkout, mở, Check-in, hủy hoặc recovery.
- **Workspace** quản lý file làm việc trên máy, kiểm tra digest và giữ công việc tại máy nếu xảy ra
  xung đột. Workspace không được tự quyết định Check-in hay Release.
- **Format worker** đọc file đóng để phân tích hoặc tạo preview. Nó không được sửa file gốc hoặc cập
  nhật trạng thái sản phẩm.

Cách chia này giữ phần khó và quan trọng ở Server, nhưng vẫn cho người dùng tiếp tục làm việc với file
bình thường trong Office/CAD.

## 3. Các Module chính của IDEA Server

| Module | Chịu trách nhiệm chính |
|---|---|
| Controlled Product Data | Logical Document, Artifact, Generation, Business Revision, Checkout và Check-in Change Set. |
| Product Structure | Cấu trúc sản phẩm, quan hệ giữa các tài liệu và Structure Snapshot chính xác. |
| Lifecycle Governance | Workflow, Approval, Release và các policy liên quan. |
| Information Model | Metadata, classification, numbering và quy tắc kiểm tra dữ liệu. |
| Format Intelligence | Khả năng đọc/phân tích từng loại file, preview và Representation. |
| Access Policy | Kiểm tra quyền theo policy có thể cấu hình, không hard-code vai trò vào code nghiệp vụ. |
| Discovery | Tìm kiếm và các màn hình danh sách được dựng lại từ dữ liệu chính thức. |
| Audit Evidence | Lưu lại sự kiện quan trọng theo cách không thể sửa bằng thao tác quản trị thông thường. |

Mỗi Module chỉ được sửa dữ liệu mà nó sở hữu. Module khác muốn sử dụng phải gọi qua Interface đã
định nghĩa. Nhờ vậy, sau này có thể thay công nghệ bên trong hoặc tách Module khi thật sự cần mà không
làm rối quy tắc nghiệp vụ.

## 4. Vì sao khuyến nghị bộ công nghệ này?

| Công nghệ | Lý do phù hợp với dự án | Điều vẫn cần xác nhận |
|---|---|---|
| `.NET 10 LTS` / `ASP.NET Core` | Có thể dùng cùng một hệ sinh thái cho Server, Desktop và Workspace; phù hợp ứng dụng Windows và hỗ trợ xây Interface rõ bằng OpenAPI. | Quy định công nghệ, cách cập nhật patch và năng lực vận hành của công ty. |
| `React + TypeScript` | Phù hợp giao diện có nhiều trạng thái, bảng, cây dữ liệu, drawer/modal và luồng thao tác tương tác cao. | Có cần một React framework đầy đủ cho routing, data loading hoặc server rendering hay không. |
| `PostgreSQL 18` | Phù hợp dữ liệu quan hệ, constraint, transaction và truy vết; không buộc file lớn nằm trong database. | Công ty có sẵn quy trình backup, restore, monitoring và người vận hành PostgreSQL hay không. |
| Private object storage | Tách file bất biến khỏi metadata; dễ kiểm tra digest và có thể đổi nhà cung cấp qua Adapter. | Nhà cung cấp, dung lượng, backup/restore, encryption và chi phí nội bộ. |
| `OpenID Connect` | Không khóa sản phẩm vào một hệ thống đăng nhập trước khi biết hạ tầng thật. | Identity provider, group mapping, MFA và quy trình cấp/thu hồi quyền của công ty. |
| Tiến trình xử lý format riêng | Cô lập file không tin cậy và lỗi từ tool CAD/Office khỏi IDEA Server. | Phiên bản IRONCAD, license, khả năng chạy độc lập và giới hạn CPU/RAM/time. |

Nguồn chính thức được kiểm tra ngày 03/09/2026 cho thấy `.NET 10` là bản LTS đang được hỗ trợ đến
14/11/2028. PostgreSQL 18 là major version hiện hành và vẫn nằm trong vòng đời hỗ trợ. Tài liệu React
cũng cho phép bắt đầu bằng Vite khi full-stack framework chưa cần thiết, nhưng lưu ý rằng routing,
data loading và code splitting lúc đó là trách nhiệm của dự án. Những thông tin này chỉ chứng minh
candidate còn hợp lệ để đánh giá; chúng không thay cho quyết định của công ty.

## 5. So sánh với các phương án khác

| Tiêu chí | A — Phương án khuyến nghị | B — Dùng SQL Server | C — Dùng Java/Spring cho Server |
|---|---|---|---|
| Server | `.NET 10` / `ASP.NET Core` | Giống A | Java/Spring |
| Web | React + TypeScript | Giống A | Giống A |
| Database | PostgreSQL 18 | SQL Server | PostgreSQL 18 |
| Desktop / Workspace | `.NET` trên Windows | Giống A | Vẫn cần `.NET` hoặc một công nghệ Windows khác |
| Điểm mạnh | Một hệ sinh thái chính cho Server và phần mềm Windows; database mở, mạnh về transaction. | Có thể thuận lợi nếu công ty đã chuẩn hóa vận hành và license Microsoft. | Hệ sinh thái Server trưởng thành, phù hợp nếu công ty đã có đội Java. |
| Điểm phải đổi lại | Cần xác nhận năng lực vận hành PostgreSQL; React vẫn là một hệ sinh thái riêng. | Chưa biết license, edition và hạ tầng hiện có; không nên chọn chỉ vì quen tên. | Một người phải duy trì ít nhất hai hệ sinh thái runtime cho Server và Windows; tăng việc tích hợp và vận hành. |
| Đề xuất hiện tại | **Đưa ra để sếp duyệt**, kèm các điều kiện ở mục 7. | Giữ làm phương án thay thế nếu hạ tầng công ty phù hợp hơn. | Chỉ chọn khi tiêu chuẩn công ty hoặc kết quả thử nghiệm cho thấy lợi ích rõ ràng. |

Lý do chính để ưu tiên A là quy mô dự án hiện tại chỉ có một người thực hiện. Việc giữ Server,
Desktop và Workspace trong cùng hệ sinh thái `.NET` giảm số loại công cụ và kiến thức phải duy trì,
trong khi vẫn tách Web UI bằng React để phục vụ giao diện nhiều tương tác.

## 6. Các nguyên tắc không được làm yếu khi triển khai

1. Một Logical Document giữ Stable ID; Generation đã Check-in là bất biến.
2. Check-in nhiều tài liệu phải thành công toàn bộ hoặc không tài liệu nào được công bố.
3. Sai người, sai Workspace, Out of date hoặc thiếu quyền phải bị từ chối và giữ lại công việc trên
   máy.
4. Check-in thành công kết thúc Checkout của phạm vi đã chọn, trừ khi người dùng đã xác nhận một lựa
   chọn giữ lại được policy cho phép.
5. Release phải pin đúng Generation, Product Structure, Approval, policy và Audit; không dùng
   `latest` động.
6. Web, Desktop, Workspace và format worker không được giữ database credential hoặc permanent
   storage credential.
7. File CAD/Office được xử lý ngoài phần mềm thiết kế; không cài IDEA code vào bên trong tool.
8. Notification, search index, preview và cache chỉ là dữ liệu phụ; chúng không quyết định một lệnh
   đã thành công hay chưa.
9. Backup chỉ được tính là đạt khi restore được một mốc nhất quán và kiểm tra đủ digest.
10. Chưa có số đo thì latency, capacity, availability, RPO, RTO và giới hạn worker phải để
    `UNKNOWN`, không tự đặt thành cam kết.

## 7. Những thông tin còn thiếu trước khi duyệt Tech

| Việc cần làm rõ | Vì sao cần | Người/điểm chốt | Trạng thái |
|---|---|---|---|
| Server chạy ở đâu và theo mô hình nào | Quyết định cách deploy, backup, monitoring, network và availability. | Product Decision Authority cùng đầu mối hạ tầng công ty | `BLOCKED` |
| Công ty dùng identity provider nào | Cần để xác định đăng nhập, group mapping, MFA và thu hồi quyền. | Đầu mối identity/security; hiện chưa được chỉ định | `BLOCKED` |
| Chọn PostgreSQL hay SQL Server | Cần thông tin về chuẩn nội bộ, license, vận hành, backup/restore và kỹ năng hỗ trợ. | Product Decision Authority sau khi có thông tin hạ tầng | `BLOCKED` |
| Chọn object storage nào | Ảnh hưởng dung lượng, encryption, backup/restore và quyền truy cập. | Hạ tầng/security; hiện chưa được chỉ định | `BLOCKED` |
| Phiên bản và license IRONCAD thử nghiệm | Cần để kiểm tra deep format profile và cách chạy tool bên ngoài. | Principal Product Author / đầu mối license | `BLOCKED` |
| Desktop UI toolkit và cách đóng gói | Ảnh hưởng trải nghiệm Windows, update và code signing. | Technical evaluation trước PG3 | `UNKNOWN` |
| Có cần full React framework không | Vite đơn thuần không tự giải quyết toàn bộ routing/data loading/code splitting. | Bounded technical spike dựa trên UI thật | `UNKNOWN` |
| Reviewer chuyên môn | Người chuẩn bị cũng là người review hiện tại, nên chưa có review độc lập về architecture, security và operations. | Cần phân công nếu gate yêu cầu độc lập | `BLOCKED` |

Các điểm trên không làm mất giá trị của phương án đề xuất, nhưng không được giấu đi hoặc coi là đã
được xác nhận.

## 8. Cách chứng minh phương án khả thi trước khi viết Core đầy đủ

| Thử nghiệm nhỏ | Cần chứng minh | Không được hiểu là |
|---|---|---|
| Transaction và fault injection | Check-in nhiều tài liệu không tạo trạng thái nửa chừng; retry không tạo Generation trùng. | Production implementation đã hoàn thành. |
| Workspace transfer/recovery | Tải đúng Generation, kiểm tra digest, tiếp tục transfer và giữ local work khi lỗi. | Đã giải quyết mọi trường hợp offline. |
| IRONCAD format profile | Một phiên bản/tool cụ thể có thể phân tích hoặc tạo Representation ngoài ứng dụng với giới hạn rõ. | Hỗ trợ mọi phiên bản IRONCAD hoặc mọi CAD. |
| Authorization matrix | Mọi đường Web/Desktop/transfer/worker đều gọi đúng owner policy và từ chối truy cập chéo. | Security review độc lập đã PASS. |
| Backup/restore drill | Khôi phục cùng một mốc metadata + Artifact và kiểm tra đủ Generation/digest. | Chỉ chạy backup thành công là đủ. |
| UI journey | Luồng Checkout → edit → Check-in → review → Release và các trường hợp lỗi khớp Spec. | Prototype hiện tại là production UI. |

Mỗi thử nghiệm phải ghi rõ dataset, môi trường, phiên bản tool, đầu vào, kết quả và giới hạn. Kết quả
chưa chạy vẫn là `NOT-RUN`.

## 9. Thứ tự quyết định

1. Sếp duyệt `FEATURE-001`: Core v0 làm những tính năng nào.
2. Sếp duyệt `SPEC-001`: các tính năng đó phải hoạt động và được kiểm tra như thế nào.
3. Hoàn tất thông tin hạ tầng/công nghệ còn thiếu và review nội bộ TECH.
4. Trình `TECH-001`: sếp chọn phương án A, chọn phương án khác, yêu cầu chỉnh sửa, hoãn hoặc từ chối.
5. Sau khi cả ba trục được duyệt, mới đánh giá `PG4` để quyết định có bắt đầu production code hay chưa.

Việc sếp duyệt Tech không tự động làm cho `PG4` đạt. Kế hoạch triển khai, test, migration/recovery,
security và các blocker vẫn phải được kiểm tra riêng.

## 10. Quyết định của Product Decision Authority

| Trường | Giá trị hiện tại |
|---|---|
| Bản được xem xét | Chưa trình; candidate là `TECH-001@0.2` |
| Quyết định | `NOT-RUN` |
| Phương án được chọn | Chưa ghi nhận |
| Điều kiện / yêu cầu chỉnh sửa | Chưa ghi nhận |
| Product Decision Authority | Chưa ghi nhận |
| Ngày quyết định | Chưa ghi nhận |
| Nội dung cần cập nhật sau quyết định | Chưa ghi nhận |

Nếu sếp chọn một phương án khác với A, bản quyết định phải ghi rõ phần nào thay đổi, lý do, ảnh hưởng
đến Spec và thử nghiệm nào cần chạy lại.

## Phụ lục A — Thông tin kiểm soát

| Trường | Giá trị |
|---|---|
| ID | `TECH-001` |
| Trục quyết định | `Tech` |
| Trạng thái | `Draft` |
| Phiên bản | `0.2` |
| Baseline | `IDEA-C1-ANALYSIS-DESIGN-001` / candidate `IE-TECH-CORE-V0-001` |
| Người chuẩn bị | `Principal Product Author`; chưa ghi nhận danh tính cá nhân |
| Người review | `Author Self-Reviewer`; review bản 0.2 chưa thực hiện |
| Người quyết định | `Product Decision Authority`; chưa ghi nhận danh tính và ngày quyết định |
| Mức sẵn sàng | `BLOCKED`: chờ Feature, Spec được duyệt; chờ review nội bộ và thông tin hạ tầng nêu tại mục 7 |
| Phân loại | `INTERNAL` |
| Bản DOCX/PDF | Chưa tạo |

## Phụ lục B — Danh mục tài liệu nguồn

| Tài liệu nguồn | Phiên bản / Baseline | Nội dung được sử dụng |
|---|---|---|
| [`IE-PROD-FEAS-001`](../DOC-02-feasibility-and-options-assessment.md) | `0.1` / `IDEA-C1-ANALYSIS-DESIGN-001` | Khả thi, lựa chọn format và giới hạn bằng chứng |
| [`IE-PROD-SREQ-001`](../DOC-04-software-requirements-specification.md) | `0.1` / `IE-SPEC-CORE-V0-001` | Requirements và quality scenarios mà kiến trúc phải đáp ứng |
| [`IE-PROD-ARCH-001`](../DOC-05-architecture-description.md) | `0.1` / candidate `IE-TECH-CORE-V0-001` | Context, Host, Module, Interface, trust, reliability và trade-off |
| [`IE-PROD-DATA-001`](../DOC-06-data-integration-and-migration-specification.md) | `0.1` / `IE-SPEC-CORE-V0-001` | Data ownership, lifecycle, exchange, reconciliation và recovery |
| [`IE-PROD-UX-001`](../DOC-08-ui-ux-and-interaction-specification.md) | `0.1` / `IE-SPEC-CORE-V0-001` | Các surface và interaction mà công nghệ phải hỗ trợ |
| [ADR index](../../../../adr/README.md) | Accepted product decisions tại repository baseline | Các quyết định đã chốt và các đề xuất còn chờ duyệt |
| [.NET support policy](https://dotnet.microsoft.com/en-us/platform/support/policy) | Kiểm tra 03/09/2026 | Trạng thái LTS và thời hạn hỗ trợ của `.NET 10` |
| [PostgreSQL versioning policy](https://www.postgresql.org/support/versioning/) | Kiểm tra 03/09/2026 | Vòng đời hỗ trợ của PostgreSQL major version |
| [React: Build a React app from scratch](https://react.dev/learn/build-a-react-app-from-scratch) | Kiểm tra 03/09/2026 | Lựa chọn build tool và phần trách nhiệm dự án phải tự đảm nhận |
| [ASP.NET Core OpenAPI](https://learn.microsoft.com/en-us/aspnet/core/fundamentals/openapi/overview?view=aspnetcore-10.0) | Kiểm tra 03/09/2026 | Khả năng tạo OpenAPI document cho product Interface |

Nếu một tài liệu nguồn, candidate version hoặc thông tin hạ tầng thay đổi, `TECH-001@0.2` phải được
đối chiếu và cập nhật trước khi review hoặc ra quyết định.

