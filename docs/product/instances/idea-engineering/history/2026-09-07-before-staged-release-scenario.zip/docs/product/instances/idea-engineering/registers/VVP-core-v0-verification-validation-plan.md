# IDEA Engineering Core v0 Verification and Validation Plan

> **Supporting-record state**: controlled `Draft 0.3`. This plan defines how the proposed Core v0
> requirements will be checked. Every result remains `NOT-RUN`; this document is not test evidence.

## Common control envelope

| Field | Recorded value |
|---|---|
| Stable Record ID | `IE-VVP-CORE-001` |
| Record Class | `VVP` |
| Title | IDEA Engineering Core v0 Verification and Validation Plan |
| Owner | Principal Product Author; named Verification Authority `BLOCKED` before PG2/PG5 as applicable |
| Record Status | `Draft` |
| Record Version | `0.3` |
| Applicable Baseline / Effective Date | `IE-SPEC-CORE-V0-001@0.3` / `NOT APPLICABLE` until approval |
| Authors / Reviewers / Approvers | Principal Product Author (assistant prepares) / project user (internal document review); required independent/specialist reviewers and Verification Authority not assigned |
| Source Links | [DOC-04](../DOC-04-software-requirements-specification.md), [DOC-06](../DOC-06-data-integration-and-migration-specification.md), [DOC-08](../DOC-08-ui-ux-and-interaction-specification.md), [DOC-07](../DOC-07-mvp-roadmap-and-delivery-plan.md) |
| Downstream Links | Future VEV result records, PG2–PG6 gate packages and REL manifest |
| Evidence / Claim Status | Plan Draft; all procedures and claims `NOT-RUN` |
| Change History | 0.3: VVP-001 explicitly verifies the single Version-within-Revision rule and absence of Version Sequence; [IE-CHG-VERSION-001](CHG-2026-09-04-version-model-clarification.md). 0.2 added account and recovery cases. |
| Access Classification | `INTERNAL`; only synthetic test data may be committed to the repository |
| Retention Rule | Retain with exact requirements/build/evidence baseline; organizational period `UNKNOWN`, owner Product Decision Authority/Quality authority |
| Content State | `COMPLETE CONTROLLED DRAFT` with explicit environment, population and reviewer gaps |

<!-- AUTHOR CONTENT START -->

## 1. Verification objectives and methods

`IE-DATA-CANONICAL-001` is the planned synthetic Canonical Demo Dataset identity. Its content,
manifest and version will be created only after Spec approval. A later Representative Pilot Project
is a different data/evidence class and shall not be committed to Git automatically.

| Objective / requirement or claim | Method / procedure | Exact configuration and environment | Expected evidence | Owner | Status |
|---|---|---|---|---|---|
| `VVP-001` — `REQ-ID-*` | State/model and persisted identity tests covering registration, first Check-in, changed Check-in, No Change and Create Revision. | Future approved build + `IE-DATA-CANONICAL-001`; storage/runtime pins `UNKNOWN`. | Identity/state ledger, manifests and assertions proving Version starts at 1, increments once per changed Check-in, does not increment for No Change, resets for a new Revision, and has no duplicate Version Sequence field. | Verification Authority `BLOCKED` | `NOT-RUN` |
| `VVP-002` — `REQ-WS-001`…`REQ-WS-006` | Task/contract tests for scope preview, Checkout, Reference, materialization, scan states and reconfirmation. | Two actors, two Workspaces, root plus related Office/CAD fixtures. | Workspace Manifests, digests, screenshots/interaction logs and command results. | Verification + HCD roles `BLOCKED` | `NOT-RUN` |
| `VVP-003` — `REQ-WS-007`…`REQ-WS-012`, `QRS-001`, `QRS-002` | Fault injection at upload, validation, object materialization and transaction steps; OperationId replay. | Exact future adapters/stores with controllable faults. | Zero partial public Change Sets/Generations and one idempotent terminal result per OperationId. | Verification Authority `BLOCKED` | `NOT-RUN` |
| `VVP-004` — `REQ-WS-010/011/013`, `QRS-003` | Concurrency matrix: stale head, wrong owner, wrong Workspace, lease/recovery, Reference modification and dependency advanced. | Two actors, two Workspaces, exact binary fixtures and expected/current Generation pins. | Zero invalid publish; before/after local digests; response-contract checklist and Audit. | Verification Authority `BLOCKED` | `NOT-RUN` |
| `VVP-005` — `REQ-STR-*` | Graph fixtures for exact pins, occurrences, child advance, unresolved/missing relation, cycle and reproduction. | Canonical multi-level Product Structure. | Snapshot manifests/digests and resolution comparison. | Structure reviewer `BLOCKED` | `NOT-RUN` |
| `VVP-006` — `REQ-LC-*`, `QRS-004` | Workflow/approval/release state-machine tests, policy-version change, actor separation, missing role and release fault injection. | At least author/editor and independent-approver identities; exact policy versions. | Decision records, state history, release manifests and zero invalid Release. | Lifecycle/Quality reviewer `BLOCKED` | `NOT-RUN` |
| `VVP-007` — `REQ-GOV-*`, `REQ-AUD-*`, `QRS-005` | Policy replacement, numbering concurrency/idempotency, cross-path/cross-Organization authorization and evidence reconciliation. | Two Organizations; Web/Desktop/transfer/preview/export/worker paths. | Authorization decision matrix, allocation ledger, Audit completeness/tamper results. | Security/Quality reviewers `BLOCKED` | `NOT-RUN` |
| `VVP-008` — `REQ-FMT-*`, `QRS-008` | Generic conformance per enabled format plus exact IRONCAD profile tests and malformed/oversized/timeout fixtures. | Exact extension, application, adapter and tool versions `BLOCKED`; isolated worker limits `UNKNOWN`. | Capability report, producer provenance, source/derivative digests and bounded failure results. | Format/Security reviewers `BLOCKED` | `NOT-RUN` |
| `VVP-009` — `REQ-UX-*` | Canonical 1440×900 task walkthrough, page/panel scroll observation, keyboard/focus/modal/drawer/icon/error-state checks. | Exact future Web/Desktop builds and browser/toolkit versions `UNKNOWN`. | Task log, captures, focus/semantic inspection and deviations. | HCD/accessibility reviewers `BLOCKED` | `NOT-RUN` |
| `VVP-010` — `REQ-LOC-*`, `QRS-007` | Same task/resource/fallback/Unicode suite over all nine locale/surface cells. | Versioned resource catalogue plus `en`/`vi`/`ja`; Japanese IME/font environment `UNKNOWN`. | Resource-key diff, persisted preference, round-trip fixtures, clipping/parity and linguistic review. | Locale reviewers `BLOCKED` | `NOT-RUN` |
| `VVP-011` — `REQ-SEC-*`, `REQ-IAM-004/005` | Secret scan/direct-store denial; transfer expiry/replay/revocation; native-session isolation; WebView2 origin/frame/message/path boundary; worker sandbox. | Exact candidate stack/build plus two Windows user sessions, malicious/unapproved content, old cookie/token and transfer grants. | Denied unauthorized operations, no native credential exposure to JavaScript, local candidates preserved, source digests unchanged. | Security reviewer `BLOCKED` | `NOT-RUN` |
| `VVP-012` — `REQ-OPS-001/002` | Crash/restart, staging expiry, outbox replay and projection-rebuild scenarios. | Future approved stores/adapters and fault controls. | Reconciliation ledger; no private candidate exposed; committed authority unchanged. | Operations reviewer `BLOCKED` | `NOT-RUN` |
| `VVP-013` — `REQ-OPS-003/004/005`, `QRS-006`; account recovery-state implications | Lose the server, restore database/Artifacts/configuration/keys to an isolated replacement, reconcile every retained Generation and exercise login/open/Check-in/reproduction. Invalidate restored sessions and reconcile post-recovery-point access changes before reopening. | Approved coordinated recovery set, representative corpus/topology, incident clock/business calendar and available operator/key custody. | Zero missing/mismatched in-scope identities/Artifacts; healthy-service acceptance; raw wall/working time and recovered-point gap versus preliminary four-working-hour/one-hour goals. | Operations/Quality authority `BLOCKED` | `NOT-RUN` |
| `VVP-014` — `REQ-OPS-005` | Measure versioned concurrent workload, transfer/processing failures, latency percentiles, throughput/resources, availability and restore metrics. | 50–100 total intended users is context, not concurrent load. Actual file sizes/corpus/growth, topology/thresholds and support hours need approval; RTO/RPO goals from TECH-CTX-008 remain unqualified. | Raw metrics and environment manifest; threshold comparison with honest fail/blocked disposition. | Initial operator may be the user; long-term Operations authority `UNKNOWN` | `NOT-RUN`; prerequisites `BLOCKED` |
| `VVP-015` — `REQ-IAM-001…007`, `QRS-009` | Native sign-in/out without company provider; admin-only issue/reset/suspend; one-use proof; old-session and concurrent command revocation; account/product privilege separation; Actor rename/history and first/last-admin safeguards. | At least account-only admin, ordinary engineer and independently eligible approver; approved security policy, Web/native/rendered sessions and two Organizations for negative isolation tests. | Attributable account/security events, denied signup/replay/escalation, stable history, preserved local digests and no revived revoked sessions. No independent-human review inferred from test personas. | Security/Verification roles `BLOCKED` | `NOT-RUN` |

### 1.1 Recovery and account acceptance detail

VVP-013 must establish a **usable coordinated** recovery point, not just PostgreSQL WAL replay.
Inject delayed/missing Artifact backup and absent/corrupt key/configuration cases; a database-only
success cannot PASS. Compare incident time to the latest complete recovery point (preliminary gap
≤ one hour), and service acceptance to the approved working-hour clock (preliminary ≤ four hours).
Record elapsed wall time as well. Scope/calendar/start clock, operator availability and representative
corpus must be agreed before execution. A target missed remains FAIL/undemonstrated, not a reduced
scope disguised as success.

VVP-015 must exercise affected old cookies/access tokens after password recovery, suspension and
revocation, including transfer/resume, group removal, Check-in and Release races. Recheck authority
before commit and at defined streaming checkpoints; do not demand impossible recall of downloaded
bytes. Include disabled-account restore/reenable, first-admin setup reuse, last-recovery-admin removal
and authorized-account-admin attempting product actions. No test should claim protection from all
privileged reset/OS-admin impersonation; those risks also need organizational controls and review.

VVP-009/010 adds UX-JRN-009/010 to applicable locale/surface cells. VVP-011 covers WebView2 update,
unapproved navigation/frame messages, token handling and protected per-user bridge behavior. No new
case was executed during documentation authoring.

## 2. Validation Pack strata

The controlled-document framework Validation Pack remains separate from the future product test
suite. The minimum strata below ensure evidence classes and product obligations are not represented by
one convenient happy-path sample.

| Stratum | Minimum | Selection rule | Result metadata owner |
|---|---:|---|---|
| Class structure | 17 | All eight Core and nine supporting classes | Principal Product Author |
| Placement | 20 | Every class plus shared/non-ownership cases | Principal Product Author |
| Requirements | 8 | At least one functional, interface, data, quality, security/privacy, operational, accessibility and localization obligation | Verification Authority `BLOCKED` |
| Reference coverage | 6 | Evidenced, ambiguous, unknown, stronger-benchmark, no-stronger-pattern and restricted-evidence cases | Principal Product Author |
| Gate outcomes | 4 | `PASS`, `PASS-WITH-ACTIONS`, `FAIL`, `BLOCKED` | Applicable gate authority |
| Surface profiles and locale cells | 3 profiles + 9 cells | Desktop, Web and Web-rendered Desktop in `en`, `vi`, `ja` | HCD/localization owners `BLOCKED` |
| Renditions | 4 | Current, Stale, Superseded and Withdrawn | Configuration Authority `UNKNOWN` |
| Pilot/claim statuses | 6 | Canonical dataset through rollout authorization | Product Decision/Adoption authorities |

Each selected product case records requirement IDs, procedure version, exact build/configuration,
environment, dataset, expected and observed result, date/time, operator, reviewer, deviations,
evidence location/digest and final disposition.

## 3. Human review and independence

| Review item | Required rule | Evidence / result |
|---|---|---|
| Internal document review | Project user reviews the assistant-authored plan for completeness, clarity and product fit; author consistency checks remain separate. | Previous Feature 0.3/Spec 0.4 draft review is retained; changed Spec 0.5 and this plan require new review, not automatic carry-over. |
| Independent requirements review | Reviewer does not author or own the material requirement decision. | `BLOCKED`: person/competence not assigned. |
| Specialist review | Security, data/format, HCD/accessibility, locale and operations reviewers cover applicable risk. | `BLOCKED`: assignments absent. |
| Product decision | Product Decision Authority decides Feature, then Spec, then Tech on exact source manifests. | Feature/Spec/Tech decisions `NOT-RUN`. |
| Representative validation | At least one intended document consumer plus appropriate roles/project context. | `BLOCKED`: pilot population/project absent. |
| Single-person execution | One person may operate separate Test Personas for bounded functional evidence. | Allowed only as `Single-Actor Functional Acceptance`; never independent or representative acceptance. |

## 4. Gate mapping and change

| Gate | Inputs / evidence | Outcome rule | Re-plan trigger |
|---|---|---|---|
| `PG1` | DOC-01/02/03/07, coverage and FEATURE-001 exact versions | Product Decision Authority records one outcome. | Feature change invalidates dependent Spec Draft. |
| `PG2` | Approved Feature; DOC-03/04/06/08; this VVP; risks/trace | Missing source, acceptance method or required reviewer is `BLOCKED/NOT-RUN`, never PASS. | Requirement, locale, data or acceptance change. |
| `PG3` | Approved Spec; DOC-05/06/08, ADRs and technology evidence | Architecture/design and specialist gaps remain explicit. | Tech/architecture/interface or threat change. |
| `PG4` | Approved Feature/Spec/Tech; bounded increment, test design, migration and rollback | No action may invalidate upstream baselines. | Increment/dependency/recovery scope change. |
| `PG5` | Exact build/config/environment/dataset plus executed VEV | Only observed result can be PASS/FAIL/BLOCKED/NOT-RUN. | Build/config/procedure/environment change. |
| `PG6` | Immutable REL manifest, VEV, known issues, residual risk and restore evidence | Missing approval/recovery keeps release blocked. | Release-manifest or residual-risk change. |

Material requirement or design change updates the affected VVP procedure and marks earlier dependent
evidence stale; it does not rewrite the old result.

## 5. Product acceptance and claim boundary

| Claim | Minimum evidence | Current status |
|---|---|---|
| Canonical Demo Dataset verification | `VVP-001`…`VVP-013` plus `VVP-015` applicable procedures on one exact synthetic dataset/build baseline | `NOT-RUN`; dataset/build absent |
| Technical Pilot Verification | Approved non-production environment and exact executed evidence | `NOT-RUN` |
| Single-Actor Functional Acceptance | Separate Test Personas and declared limitation | `NOT-RUN` |
| Internal Operational Need Validation | Representative internal roles/workflow and attributable evidence | `BLOCKED` |
| Internal Pilot Acceptance | Technical evidence, representative users and Internal Adoption Authority | `BLOCKED` |
| Operational rollout authorization | Exact release, residual-risk, support and recovery readiness | `BLOCKED` |

No successful prototype walkthrough, unit test or backup job may be relabeled as a higher claim.

## 6. Evidence sufficiency

Evidence is sufficient only when it records the requirement/claim, procedure version, source and
build baseline, configuration, environment, dataset, expected/observed result, time, operator,
reviewer and independence/competence, deviations, residual risk, retained evidence link and digest
where applicable. A screenshot alone may support a visual fact but not concurrency, authorization,
transaction, recovery or production-readiness claims.

<!-- AUTHOR CONTENT END -->

## Contract references

- [VVP class template](../../../definition/registers/VVP-verification-validation-plan.md)
- [Validation contract](../../../../../specs/003-controlled-documentation/contracts/validation.md)
- [Gate package](../../../../../specs/003-controlled-documentation/contracts/gate-package.md)
