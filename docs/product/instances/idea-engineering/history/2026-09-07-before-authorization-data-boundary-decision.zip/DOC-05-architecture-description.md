DOC-05

# IDEA Engineering Core v0 Architecture Description

> **Instance state**: controlled `Draft 0.5`. This document describes a candidate architecture for
> the recorded product direction and Draft requirements. It does not approve a technology stack,
> authorize production implementation, or record a successful architecture review.

## Control envelope

| Field | Recorded value |
|---|---|
| Stable Document ID | `IE-PROD-ARCH-001` |
| Document Class | `DOC-05` |
| Title | IDEA Engineering Core v0 Architecture Description |
| Owner | `Principal Product Author`; named person attribution required before `Proposed` |
| Document Status | `Draft` |
| Document Version | `0.5` |
| Applicable Baseline | `IDEA-C1-ANALYSIS-DESIGN-001` / candidate `IE-TECH-CORE-V0-001` |
| Requirements Input | `IE-PROD-SREQ-001@0.5`; Feature and Spec decisions remain `NOT-RUN` |
| Effective Date | `NOT APPLICABLE` until approval |
| Authors | `Principal Product Author`; named identity not yet recorded |
| Reviewers | Project user performs internal document review; architecture review `NOT-RUN`; required independent/specialist reviewer unassigned |
| Approvers | Product Decision Authority for Tech; identity, decision and date are `UNKNOWN` |
| Source Links | [DOC-04](DOC-04-software-requirements-specification.md), [DOC-06](DOC-06-data-integration-and-migration-specification.md), [DOC-08](DOC-08-ui-ux-and-interaction-specification.md), [architecture input](../../../architecture/idea-product-lifecycle-architecture.md), [accepted ADR index](../../../adr/README.md) |
| Downstream Links | [DOC-07](DOC-07-mvp-roadmap-and-delivery-plan.md), [VVP](registers/VVP-core-v0-verification-validation-plan.md), [TECH-001](decision-briefs/TECH-001-technology-and-architecture-proposal.md), future implementation contracts and evidence |
| Evidence / Claim Status | Architecture and technology evaluation are `Draft`; tests, spikes and operational evidence are `NOT-RUN` |
| Change History | 0.5: define configurable, versioned workflow selection and runtime pinning through [IE-CHG-WORKFLOW-001](registers/CHG-2026-09-07-workflow-configuration.md). 0.4 defined CAD Representation paths. 0.3 aligned Version/Generation. 0.2 introduced the technology proposal and account context. |
| Access Classification / Retention Rule | `INTERNAL`; retain with the controlled product baseline and successor/change records |

<!-- AUTHOR CONTENT START -->

## 1. System of interest and context

The system of interest is `C1 — IDEA Engineering`, an internal product that controls engineering
documents, immutable Generations, Product Structure, review decisions and exact Releases. It remains
useful and deployable without a future platform or another product capability.

```text
Engineering users / reviewers / administrators
              │ explicit commands, queries and decisions
              v
     IDEA Web and IDEA Desktop
              │ authenticated product interfaces
              v
       IDEA Server — product authority
        │             │              │
        │             │              └── isolated Format Processing Runtime
        │             └── private immutable Artifact storage
        └── relational metadata, policy, structure and Audit

IDEA Desktop ↔ per-user Workspace process ↔ ordinary persisted Office/CAD files
External applications are launched by the operating system; no IDEA code runs inside them.
```

| Context item | Description | Authority / evidence | Status |
|---|---|---|---|
| Internal actors | Engineer/Author, Reviewer, Independent Approver, PDM Administrator, Quality/Auditor, Security Administrator and Operator. | DOC-03 actors; DOC-08 user profiles | `Draft` |
| External applications | Configured Office/CAD applications read and write ordinary files in a Managed Workspace. Unsaved in-memory state is outside IDEA. | `REQ-FMT-001/004`; accepted product decision | `Draft` |
| Accounts and login | Native IDEA accounts initially; the project user administers accounts. Other/company login is future scope, not an external prerequisite. | `REQ-IAM-001…007`; `TECH-CTX-003/004` | Context confirmed; secure implementation and policy unqualified |
| Data stores | Relational authoritative metadata plus private content-addressed Artifact storage. | `REQ-ID-*`, `REQ-STR-*`, `REQ-OPS-001/003/004`; DOC-06 | Architecture `Draft`; providers undecided |
| Future integrations | Read-only Controlled Release Package export is in Core v0. General external integration, company login and write-back are deferred. | Feature exclusions; `REQ-LC-008` | `DEFER` for integrations; export required |
| Product boundary | One internal product and one Organization boundary in the first deployment; Organization isolation remains enforced by design. | `REQ-GOV-001`; internal-company decision | `Draft` |

Confirmed constraints are recorded once in [TECH-CTX-001…008](registers/CHG-2026-09-03-tech-context-and-proposal.md): Windows engineering PCs, 50–100 total intended users at one site, company-controlled server to be proposed, native accounts first, user-led account administration and possibly initial operations, no assumed DevOps function, uncertain MB-to-GB related document sets, and preliminary recovery objectives. None is measured capacity or a stack decision.

## 2. Concerns, quality attributes and scenarios

| Scenario / concern | Stimulus and operating condition | Required architecture response | Verification link | Current result |
|---|---|---|---|---|
| `QRS-001` Correct identity/version | Register, change, Check-in and revise one Logical Document. | One stable identity; immutable committed Generation; atomic first baseline and revision transition. | `REQ-ID-001…006`; `VVP-001/002` | `NOT-RUN` |
| `QRS-002` Atomic multi-document Check-in | Failure occurs at any upload, validation, materialization or transaction point. | Candidate content remains private; every selected change commits together or none commits; retry is idempotent. | `REQ-WS-007/008/012`, `REQ-OPS-001`; `VVP-003` | `NOT-RUN` |
| `QRS-003` Stale/non-owner protection | A stale, wrong-owner, wrong-Workspace or unauthorized publish is submitted. | Authoritative state is unchanged, local work remains safe, and an actionable conflict is returned. | `REQ-WS-010/011/013`; `VVP-004` | `NOT-RUN` |
| `QRS-004` Exact release | Release is requested with missing, unresolved or unapproved content. | Lifecycle Governance fails closed; successful Release pins exact Generation, structure, policy and evidence. | `REQ-STR-003`, `REQ-LC-006…009`; `VVP-006` | `NOT-RUN` |
| `QRS-005` Organization isolation | An identity attempts to resolve or command another Organization's resource. | Resource owner refuses the action and appends permitted Audit Evidence without cross-scope disclosure. | `REQ-GOV-001/002`; `VVP-007` | `NOT-RUN` |
| `QRS-006` Exact restore | Metadata/content/configuration is restored from one approved recovery point. | Every retained Generation resolves and digest-checks; gaps are reported and cannot be called PASS. | `REQ-OPS-003/004`; `VVP-013` | `NOT-RUN` |
| `QRS-007` Localized interaction | The same controlled task runs in each supported locale and surface. | Command/state/authority outcomes remain equal; user Unicode round-trips; missing resources use the declared fallback. | `REQ-UX-*`, `REQ-LOC-*`; `VVP-009/010` | `NOT-RUN` |
| `QRS-008` Untrusted format input | A malformed, oversized or slow file is processed. | Bounded worker failure cannot change source Artifact or product state; results retain tool/profile provenance. | `REQ-FMT-002…005`, `REQ-SEC-004`; `VVP-008/011` | `NOT-RUN` |
| Dense workspace usability | User performs a controlled task at the canonical 1440×900 demo viewport. | Context remains visible; same-type detail scrolls internally or opens in a drawer/modal; keyboard, focus and status semantics remain usable. | `REQ-UX-*`; `VVP-009` | `NOT-RUN` |
| `QRS-009` Account eligibility and recovery | An account is provisioned, recovered, suspended or its sessions revoked. | Stable Actor history survives; old sessions cannot authorize subsequent protected requests, and account administration does not confer product privileges. | `REQ-IAM-*`; `VVP-015` | `NOT-RUN` |

RTO of four working hours and RPO of at most one hour are user-confirmed **planning objectives** for severe server failure, not achieved SLAs. Working-hour clock/coverage, workload, capacity, latency, availability, Reservation lease, transfer expiry and worker limits require approved measurement profiles. The project user may operate initially; a long-term operator and specialist review remain unassigned.

## 3. Viewpoints and views

| Viewpoint | Intended concern / audience | View maintained here | Correspondence rule | Review status |
|---|---|---|---|---|
| Context | Product Decision Authority and all stakeholders | System boundary and external actors in section 1 | No external actor/store becomes product authority. | `Draft` |
| Responsibility | Maintainers and reviewers | Hosts and deep Modules in sections 4–5 | Every authoritative state has exactly one owner Module. | `Draft` |
| Information | Product, data and quality owners | Identity/lifecycle implications in section 8 and DOC-06 | Persisted references use stable identities and exact version pins. | `Draft` |
| Interaction | Engineer, reviewer and HCD owner | Checkout/Check-in and review/release sequences in section 7 | UI state is a view of server/workspace truth, not a second authority. | `Draft` |
| Deployment | Operator and security owner | Host/trust-zone view in sections 4 and 9 | Client/worker packages cannot hold infrastructure credentials. | `Draft` |
| Reliability | Operator, data and quality owners | Atomicity, idempotency, outbox, reconciliation and restore in section 9 | Public state appears only after a complete authoritative commit. | `Draft` |
| Security | Security and policy owners | Trust seams and owner-enforced authorization in section 10 | Every access path reaches the authoritative owner policy. | `Draft` |
| Evolution | Product and architecture owners | seams, candidate stack and deferred boundaries | A later Adapter may replace an Implementation without changing Module authority or accepted interface semantics. | `Draft` |

## 4. Deployable hosts and responsibilities

| Host | Responsibility | Must not do | Primary requirements |
|---|---|---|---|
| IDEA Server | Authenticate product requests; coordinate Modules; enforce authorization; persist authoritative state; perform atomic Check-in, workflow and Release; append Audit/outbox. | Expose internal schema; let clients/workers decide authoritative state; require a future platform for local behavior. | `REQ-ID-*`, `REQ-WS-007…013`, `REQ-LC-*`, `REQ-GOV-*` |
| IDEA Web | Search/browse/view; review/approval; governed administration; policy-appropriate preview/download. | Write stores directly or duplicate identity, Check-in, approval or Release rules. | `REQ-LC-*`, `REQ-UX-*`, `REQ-LOC-*` |
| IDEA Desktop | Capture explicit Checkout/Open/Check-in/Cancel/Recover intent; confirm scope; show conflict/recovery; launch files by OS association. | Run in an external application; publish on Save; keep permanent store credentials. | `REQ-WS-*`, `REQ-FMT-001/004`, `REQ-UX-*` |
| Workspace process | Per-user materialization, full scan/hash, cache, Workspace Manifest, resumable transfer and durable local recovery state. | Become product authority, approve/release, infer user intent or auto-merge binary changes. | `REQ-WS-001/003/004/006/009…013`, `REQ-SEC-003` |
| Format Processing Runtime | Execute one bounded immutable-input analysis/preview/conversion job through a versioned Adapter. The Adapter may invoke a qualified export interface of an installed CAD application or an approved standalone converter; manual uploads enter through the same Representation acceptance boundary. | Mutate source content or product state; reuse broad credentials; claim undeclared capability; assume a universal CAD renderer; attach output to a floating/latest source. | `REQ-FMT-002…005`, `REQ-SEC-004` |
| Relational store | Persist identity, metadata, heads, policies, structure, workflow, release, Audit and operation state transactionally. | Store user-editable working files or become an interface consumed by clients. | DOC-06; `REQ-OPS-003/004` |
| Private Artifact store | Retain immutable content by digest and serve only through scoped authorized transfer. | Expose permanent credentials/public access or decide which content is authoritative. | `REQ-ID-003`, `REQ-SEC-001/002`, `REQ-OPS-001/003/004` |

The Workspace process initially means a protected per-user background process, not a privileged
machine-wide Windows service. Process count and packaging remain a Tech decision.

## 5. Deep Modules, Interfaces and ownership

In this document, a **Module** owns a coherent responsibility and state; its **Interface** is the
small contract callers need; its **Implementation** hides internal complexity; a **Seam** is a place
where policy, technology or deployment can vary; and an **Adapter** translates across a Seam. These
terms do not imply one network service per Module.

| Module | Small Interface intent | Complexity hidden by Implementation | Authoritative state |
|---|---|---|---|
| Controlled Product Data | Register, resolve, Checkout, prepare/commit Check-in, revise and retrieve exact content. | Stable identity, Generation immutability, optimistic concurrency, staging, deduplication and atomic Change Sets. | Logical Document, Artifact reference, Generation, Business Revision, Reservation, Working Head, Check-in Operation/Change Set. |
| Product Structure | Resolve, validate and publish exact structure. | Node/occurrence/dependency rules, cycles, unresolved members, semantic digest and exact pins. | Structure Snapshot and controlled relation identities. |
| Lifecycle Governance | Validate/activate Workflow Definitions, assign a default version by Document Class, start/transition an instance, record decisions, Release and resolve an exact baseline. | State/transition validation, definition/instance versioning, role/group assignment, decision count/rule, required reason/evidence, eligibility, invalidation, notifications, exceptions and release completeness. | Workflow Definition/Version, Document-Class Workflow Assignment, Workflow Instance, Approval Policy/Decision and Release Record. |
| Information Model | Validate metadata, classify and allocate governed numbers. | Schema versioning, numbering scope/idempotency and policy migration. | Metadata/Classification/Numbering Policy Definitions and allocations. |
| Format Intelligence | Declare capability and request analysis/representation. | Execution mode (`None`, `Manual`, `Application-assisted`, `Parser`, `Standalone converter`), application/Adapter/tool versions, prerequisites, isolation, resource limits, provenance, stale derivative handling and Release-policy response. | Format Capability Profile, job/result identity and Representation metadata; never source authority. |
| Access Policy | Evaluate a versioned decision at the owning resource. | Role/group/state policy, bootstrap and explainable denial without hard-coded business roles. | Access Policy Definition/Version and decision evidence. |
| Discovery | Find/browse through rebuildable projections. | Indexing, query projection, lag and replay. | Search projection only; never product authority. |
| Audit Evidence | Append and export attributable product events. | Correlation, completeness, ordering, retention reference and controlled export. | Append-only Audit records. |
| Identity and Accounts | Provision/activate, authenticate, change/reset password, suspend and revoke sessions; resolve stable Actor context. | Maintained credential mechanisms, recovery tokens, account status, session invalidation and future login linking. | Organization-scoped Actor/IDEA Account, login identities, credential/session/recovery records; no document ACL or approval authority. |

Module rules:

1. A Module writes only its own authoritative state.
2. Cross-Module work uses an Interface and explicit stable identities, not shared table mutation.
3. The server transaction may coordinate multiple owner Implementations only through declared
   contracts and one atomic business operation.
4. Projections, caches, derivatives and UI view models are rebuildable and never become authority.
5. Splitting a Module across a process Seam requires measured scale, isolation, ownership or failure
   evidence and a new approved Tech decision.
6. Identity and Accounts adds an internal technical responsibility, not a separate identity service. Access Policy still owns role/group membership and authorization policy. The account-management role is an explicit permission, not a document superuser.
7. One application transaction coordinates owner modules through a unit-of-work boundary; no owner exposes its database tables as the cross-module Interface. Transferring authority to a generic CRUD service is not the design.

## 6. Semantic interface catalogue

The interfaces below define product meaning. Protocol, serialization and library choices are
candidate Tech details; a later implementation must preserve the behavior and errors.

| Interface ID | Owner / caller | Inputs and outputs | Contract and error behavior | Security / trace |
|---|---|---|---|---|
| `IF-PRODUCT-QUERY` | Owner Module / Web, Desktop | Organization, actor, stable identity, requested view → authorized exact state/projection. | No floating resolution where an exact pin is required; stale projection is identified; missing/unauthorized fails without data leakage. | Authenticated; owner-authorized; correlation/Audit where material. |
| `IF-PRODUCT-COMMAND` | Owner Module / Web, Desktop | Actor, policy context, target, expected state, OperationId and payload → one accepted/refused outcome. | Optimistic preconditions and idempotency are explicit; no partial authoritative outcome. | Owner enforces final authorization; decision evidence pins policy version. |
| `IF-ARTIFACT-TRANSFER` | Controlled Product Data / Workspace or authorized viewer | Exact Artifact/digest and operation scope → resumable bytes plus verification result. | Short-lived scoped grant; wrong object, expiry, replay or digest mismatch fails closed. | No permanent store credential in client; transfer correlated and auditable. |
| `IF-WORKSPACE-IPC` | Workspace process / Desktop | Per-user authenticated commands, progress, manifest and local-state evidence. | Another user/session cannot command/read; reconnect does not invent server success. | Protected local transport; no secrets in diagnostic output. |
| `IF-FORMAT-JOB` | Format Intelligence / isolated Adapter | Immutable source Generation/Artifact digest, Capability Profile and limits → typed result/Representation or typed failure. An application-assisted Adapter may invoke only the declared export interface/version. | Idempotent; returned source pin/digest must match the request; source advance changes the derivative to `Needs update`; failure preserves source and state. Manual upload uses the same validation boundary. | One-job least privilege; application/Adapter/tool provenance and output digest retained; Release blocks or warns only under its versioned policy. |
| `IF-COMMITTED-EVENT` | Owner Module / projections and notifications | Committed event with identity, version, actor, correlation and source pins. | Published from transactional outbox only; replay repairs consumers; consumer failure cannot reverse/fabricate owner state. | Classification propagated; consumer access scoped. |
| `IF-ACCOUNT-SESSION` | Identity and Accounts / Web, Desktop and Server | Provision/recovery/credentials or session proof → stable Actor/Organization, eligibility or bounded denial. | Admin-only account issuance; one-use expiring recovery; explicit revocation; no credential in logs and no public signup endpoint. Existing account/session eligibility is checked on every protected request, then revalidated with the owner before authoritative commit. | `REQ-IAM-*`; `VVP-015`; framework-managed mechanisms, not a custom OAuth server. |
| `IF-DESKTOP-BRIDGE` | Desktop / approved Web-rendered region | Versioned, allowlisted intent plus selected item/Workspace scope → progress/result. | Validate sender origin/frame, schema, session and manifest scope; no arbitrary path, shell command or generic host-object proxy. Navigation invalidates bridge authority; unsupported version fails safely. | `REQ-SEC-003`; `VVP-009/011`; native confirmation where scope changes. |
| `IF-COMPANY-IDENTITY` | Future login Adapter / Identity and Accounts | Verified provider subject → explicitly linked internal Actor/Organization. | Future integration; failure cannot substitute another actor, auto-link by email or reinterpret retained Audit. Native login remains the initial method. | Protocol/provider and company authorization `UNKNOWN`; deferred, not implemented as an empty integration layer. |

A supported public integration interface is outside Core v0. Internal versioned interfaces do not
create a promise of ERP/MRP write-back, bidirectional synchronization or direct database access.

## 7. Key interaction and state sequences

### 7.1 Checkout and materialization

1. Desktop resolves the selected root and known Related Documents.
2. User confirms each item as Checkout, Reference or excluded; no hidden assembly-wide cascade.
3. Server authorizes the complete request and creates one Reservation per Checkout document against
   its expected Generation. One conflict refuses the proposed set and returns affected entries.
4. Controlled Product Data grants scoped Artifact transfer for the confirmed snapshot.
5. Workspace process materializes every exact file, verifies the digest and records its Workspace
   Manifest before Desktop reports completion and opens the root through the operating system.

### 7.2 Check-in and stale recovery

1. Workspace process scans/hashes the complete candidate scope and classifies unchanged, changed,
   missing, Out of date and modified-without-Checkout entries using the approved UI terms.
2. Desktop requires confirmation of exact scope and explains that a successful or No Change result ends Checkout for that scope. Core v0 offers no retain-after-Check-in option.
3. Content is staged privately. Server validates identity, digest, metadata, relations, policy,
   owner, Workspace, Reservation and expected Generation.
4. Any invalid entry refuses the entire confirmed Change Set. Local work is preserved; the response
   shows expected/current Generation and valid refresh/reapply, Save As, retry or governed recovery.
5. Verify and durably materialize immutable candidate bytes in private storage **before** publication. A failed or uncertain file write cannot reach ReadyToPublish. No filesystem/object-store write is assumed to participate in a database transaction.
6. One database transaction revalidates account/session eligibility, owner policy, Reservation, expected heads and scope, then records Artifact manifest references, required Structure Snapshots, Generations, Working Heads, Change Set, Audit/outbox and the release of in-scope Reservations. Each Module writes only its owned state through the shared unit of work.
7. A semantic No Change result creates no Generation and still records the result and ends every hold in the confirmed scope. A mixed changed/unchanged scope ends all confirmed holds when the whole operation succeeds. Failure preserves local work and any still-valid entitlement.
8. Retrying the same OperationId resolves the same operation; it does not create a new Change Set. After a database failure, unused bytes remain private and are reconciled only after proving no live operation or retained Generation references them.

### 7.3 Review, approval and Release

1. Submit pins the exact Generation and review scope under one Workflow/Approval Policy Version.
2. When an instance starts, Lifecycle Governance resolves the active default for its Document Class
   or an explicitly permitted selection, then pins that Workflow Definition and Approval Policy.
3. A later definition activation affects future instances only; migration of a running instance is
   a separately authorized, previewed and audited operation.
4. Later content change invalidates the pending review; it never inherits an earlier approval.
5. The seeded path requires one eligible independent approver and refuses self-approval/release.
   Missing actors or invalid configuration block the affected action with an explainable result.
6. Release revalidates exact Artifacts, Product Structure, decisions, exceptions, policy and Audit.
7. Success creates an immutable Release Record and reproducible Controlled Release Package;
   failure changes no release state and reports blocking entries.

### 7.4 Account provisioning and session loss

1. A controlled, one-time bootstrap provisions a named first account/recovery administrator. It does not bypass the separate Bootstrap Custodian/Access Policy adoption rules or grant itself document access.
2. An authorized Account Administrator issues an account in the Operating Organization. Activation/password setup uses framework-managed, one-use expiring proof through an approved delivery channel; open self-registration is disabled.
3. Native IDEA login establishes a protected session. All subsequent product access still reaches owner-enforced Access Policy. No username, email or provider claim is a durable document-owner key.
4. Password recovery invalidates prior recovery proof and affected sessions; suspension/revocation is recorded transactionally with attributable Audit. Requests beginning after that commit are refused for the affected old sessions; commands revalidate eligibility before their own commit.
5. Already running transfers are cancelled or revalidated at defined request/chunk checkpoints; bytes already delivered and saved local work cannot be remotely erased. Resume requires fresh authorization. Exact timing/checkpoints must be qualified, not described as instantaneous revocation of every byte.
6. UI explains reauthentication without deleting a local candidate. Re-enabling an account does not resurrect old sessions. Account/group changes do not rewrite historical Actor, Approval or Audit records.

## 8. Data, lifecycle and integration implications

| Topic | Architectural implication | Detailed authority | Status |
|---|---|---|---|
| Identity/version | Stable Logical Document and Business Revision identities point to immutable Generations. Version within Revision is the business-visible Generation order; there is no separate Version Sequence field. | DOC-06 sections 2–3; `REQ-ID-*` | `Draft` |
| Binary content | Artifact bytes are immutable and content-addressed; a Generation Manifest pins exact digests. | DOC-06; `REQ-ID-003/004` | `Draft` |
| Structure | Structure Snapshot is immutable and members pin exact Generations; unresolved required dependencies remain visible. | DOC-06 `DATA-REL-005`; `REQ-STR-*` | `Draft` |
| Workflow/release | Multiple definitions may coexist; a versioned assignment selects the active default per Document Class. Instances and decisions pin exact definition/policy versions, and Release never follows floating latest. A graphical designer is deferred; validated configuration data/forms are sufficient for Core v0. | DOC-06 `DATA-REL-008…010`; `REQ-LC-*` | `Draft` |
| Policy/configuration | Product defaults, organization-owned governed policies and low-impact operational settings follow distinct change paths. | `REQ-GOV-*`; proposed configuration ADR | `Draft`; approval pending |
| Store Existing | Bounded onboarding maps ordinary files into the same identity/content model; duplicates are shown, never silently merged. | DOC-06 section 5; `REQ-ID-005/006` | `Draft` |
| Export | Controlled Release Package is read-only and exact; external write-back remains deferred. | DOC-06 section 4; `REQ-LC-008` | `Draft` |
| Audit/recovery | Evidence is append-only in the logical product model; backup/restore covers one consistent metadata/content/configuration point, including account/security records and required keys. | DOC-06 sections 7–8; `REQ-AUD-*`, `REQ-OPS-*` | `Draft`; procedures `NOT-RUN` |
| Accounts/login | Stable Actor survives login-name changes, suspension and explicitly linked future authentication methods; credentials are not part of engineering-file manifests or exports. | DOC-06 `DATA-REL-013…015`; `REQ-IAM-*` | `Draft`; data migration only when approved |

## 9. Reliability, deployment and operations

### 9.1 Publication and background work

```text
Prepared → Uploading → Validating → ReadyToPublish → Published
    └──────────────────────────────────────────────→ Failed
    └──────────────────────────────────────────────→ Cancelled
Published | Failed | Cancelled = terminal Check-in Operation states
```

Private durable materialization precedes database publication as specified in section 7.2. Database
constraints, expected-state predicates and an appropriate locking/isolation strategy protect head,
scope and operation identity; PostgreSQL's default isolation alone is not proof of correctness.
Concurrent suspension, policy activation and publication need a defined serialization/revalidation
rule and race tests, not just a pre-request check.

Audit of the authoritative outcome and an outbox entry share the owner transaction. Projection/
notification/representation work consumes only committed outcomes, with idempotent retry and
bounded concurrency. No external broker, Redis or search service is required by this initial design.
Discovery requirements still need SPEC-OPEN-02; no advanced-search scope is inferred.

Reconciliation identifies abandoned staging, failed materialization, unreferenced private bytes,
missing/corrupt objects and projection drift. Collection has a grace/in-flight-reference rule and
a controlled record; it cannot delete an object required by a retained Generation or recovery set.
Physical durability, concurrent content-addressed writes and crash behavior of the selected store
must be qualified on the actual filesystem/storage stack.

### 9.2 Initial deployment candidate

Evaluate one company-controlled server/VM for the monolith, PostgreSQL and private Artifact volume,
with separate process identities, least-privilege filesystem access and no database/public-file
access from clients. This is a proposed evaluation topology, not demonstrated sizing or availability.

Evaluate Ubuntu Server 24.04 LTS first only if IT can support it; Windows Server 2025 remains a
company-skills/licensing alternative. Exact .NET/OS/package compatibility is pinned at qualification.
The current .NET 10 OS matrix explicitly lists 24.04, not 26.04; do not assume a newer OS is qualified.
The isolated format runtime may require a separate Windows worker host and license; that does not
require moving product authority into the worker or changing the whole server OS.

A single server is a single outage domain. No failover/zero-downtime claim is made. Reject or revise
this topology if the approved outage/recovery objective cannot be met or the company requires more
availability. A separate physical/administrative backup failure domain is required for the proposed
severe-server-loss drill; a second folder, RAID or same-host snapshot alone is not that evidence.

### 9.3 Recovery design and measurement

- Database base backup plus continuous WAL archiving is the PostgreSQL PITR candidate. Track
  archive failure/lag, not only job completion. Database WAL does not contain external Artifact bytes.
- Back up immutable Artifacts continuously/in bounded batches plus manifests, configuration/policy
  versions and required keys. A recovery-set record names the database recovery point and the
  complete matching content/configuration/key set. Extra newer unreferenced bytes may remain private.
- The usable recovery point is limited by the **oldest complete coordinated component**, not merely
  the newest database backup. Do not restore a database point whose referenced content is absent.
- Preliminary targets from TECH-CTX-008 are RTO ≤ four working hours and RPO ≤ one hour. Define
  incident start, business calendar/coverage, restore corpus and healthy-service acceptance before
  measuring. Record both elapsed wall time and agreed working-time measurement to avoid hiding delays.
- Restore to an isolated replacement environment, reconcile every retained Generation in the
  approved recovery scope and digest-check it, then exercise login, exact file open, Check-in and
  release reproduction. Incomplete/corrupt recovery is not PASS even if the clock target was met.
- Backups/keys require protected retention and recovery access; loss of credentials or encrypted
  key material is part of the drill. Recovery must not silently re-enable revoked sessions; invalidate
  restored sessions and reconcile account/security changes since the recovery point before reopening
  access. The one-hour loss objective does not authorize forgotten access revocations.
- The project user may operate initially. Name a backup operator/recovery custodian, supported hours,
  escalation path and repeatable runbook before operational rollout; no 24/7 or DevOps team assumed.

### 9.4 Delivery, rollback and observability

Plan versioned release bundles, dependency/license inventory, signed Desktop delivery where company
policy requires it, protected configuration, preflight checks, health checks and a documented
maintenance window. IT approves installation and update routes; no installation occurs in this task.

Test on a representative non-production environment before promotion. Database/account/policy
migrations record the pre-change backup and reconciliation criteria; replacing old binaries is not
automatically a safe schema downgrade. Choose forward repair or a proven full recovery path and
record its data-loss/compatibility consequences.

Monitor request failures/latency, database health/locks, disk free space and growth, digest failures,
transfer interruption, abandoned operations, worker limits, outbox lag, backup lag and latest
successful restore drill. Alert routes and ownership must be assigned; logs omit credentials and
sensitive unnecessary content. Representative concurrent users, maximum files, total corpus,
growth and resource thresholds are still measurement inputs, not invented server specifications.

## 10. Security and privacy design

Trust zones are browser, Web-rendered Desktop, native user session, Managed Workspace, Server,
relational store, private Artifact store, isolated format runtime, backup store and external tools.

| Control | Candidate design response | Required evidence |
|---|---|---|
| Native accounts | ASP.NET Core Identity behind an admin-authorized application workflow; no public registration endpoint or shared default password. Account admin is distinct from product policy/admin/approval permission. | REQ-IAM-001…007; VVP-015, including least-privilege provisioning and last-recovery-path protection |
| Password and recovery | Use maintained hashing/reset/token mechanisms; never log, email back or expose an existing password. Approved one-use delivery, password/lockout/rate-limit/MFA/recovery policy remains to be specified. | Recovery/replay/brute-force and privileged-reset abuse cases; security-policy review |
| Browser sessions | Same-origin HTTPS UI/API; Secure/HttpOnly session cookies and anti-CSRF protections on state changes. No session token in browser local storage. | CSRF, XSS/session, sign-out and suspension matrix |
| Native sessions | Qualify supported framework session/bearer integration, protected per-user credential storage and renewal. Identity API tokens are proprietary, not an OAuth/OIDC server. No hand-written authorization-code protocol, token injection into JavaScript or promise of cross-surface SSO. | Exact maintained-library/flow review and old-token revocation tests; future standards-based provider requires separate selection |
| Eligibility and authorization | Identity and Accounts validates current active account/session version; resource owner evaluates current policy and expected state. Revocation races are revalidated/serialized before authoritative commit. | Old cookie/token, removed group, concurrent suspension, Check-in/Release and transfer tests; fail closed if eligibility cannot be established |
| File transfer | Server-mediated scoped short-lived transfer initially, with account/policy revalidation at each protected request and before resume. No permanent store credential/public URI. Long streams have defined cancellation/revalidation checkpoints. | Old-grant, wrong-object, expiry, replay, revoked-session and interrupted-transfer tests |
| Local process | Authenticated per-user/session IPC, controlled startup and recovery manifests; no privileged machine-wide agent required. OS same-user isolation is not proof against every malicious same-user process. | Cross-user/session denial, spoofed connection, restart/update/logout and preserved-local-work evidence |
| Web/native bridge | Only approved origins/frames, allowlisted versioned messages and exact manifest-scoped intentions; validate source on every navigation/message. No generic host object, arbitrary filesystem or shell access. External/untrusted content never shares a privileged bridge. | Malformed messages, iframe/origin navigation, path traversal, stale session and focus/scale tests |
| Worker | Immutable input and bounded output; one-job least privilege and time/RAM/CPU/output quotas. Worker result is untrusted input to its owner. | Malformed/oversized/fault cases; original digest and product state unchanged |
| Audit / privacy | Account/security events use stable Actor and correlation without secrets; product Audit append-only under ordinary admin. High-privilege OS/database/backup access remains an explicit operational risk. | Event completeness, mutation denial, log inspection and access-review evidence |
| Secrets / backup | Protect TLS, server data-protection and recovery keys outside source; backup access separated from runtime access. Restored sessions invalidated; account/security changes reconciled before reopening. | Secret scan, access-denial tests and loss-of-server/key restore drill |
| Delivery integrity | Pin source/dependencies/toolchain; review licenses including transitive components; apply verified patches and test rollback. | Version/license manifest, provenance and deployment evidence |

The above are proposed implementation responses, not a claim of security from framework defaults.
Identity cookie stamps default to periodic validation, and already issued bearer tokens may outlive
a password change. The required eligibility check cannot be replaced by those defaults. Full MFA,
password, lockout, session-expiry and recovery-channel policy is still a qualification prerequisite.

## 11. Candidate technology decisions and trade-offs

The recommendation decomposes the former A/B/C bundles into independent decisions. Mandatory
criteria are the approved product invariants and company permissions; convenience cannot offset
failure of those criteria. No performance score, approved numeric weighting, budget or expertise
claim is invented.

| Decision ID / concern | Recommended candidate | Alternative and selection trigger | Cost / limitation / evidence |
|---|---|---|---|
| TECH-STACK-001 — server | C#/.NET 10 LTS, ASP.NET Core, modular monolith | Java/Spring if established company skills/support justify a second runtime alongside Windows .NET; distributed services only with a separate measured need | Shared runtime family, not free implementation or presumed C# expertise; patch and supported-OS obligations |
| TECH-DATA-001 — database | PostgreSQL 18, aligned EF10/Npgsql provider10/driver versions | SQL Server 2025 production-licensed edition if company entitlements and operations make it preferable | PostgreSQL license has no fee, but support/DBA/backup work remains; SQL Developer is not a production entitlement |
| TECH-WEB-001 — Web UI | React + TypeScript SPA, Vite build, served with Server | React framework in SPA/static mode if routing/data/error handling is simpler and maintainable; SSR only for evidenced need | React normally recommends a framework. Vite alone is not routing/data/security design; no automatic extra Node production host is assumed |
| TECH-DESKTOP-001 — Windows UI | WPF/.NET 10 shell + WebView2 rendered regions; shared React UI where appropriate | WinUI 3/Windows App SDK after focus/scaling/toolchain/support comparison; WinForms only if complex workspace fit is demonstrated | Microsoft recommends WinUI 3 for new native apps. WPF is an IDEA-specific runtime/tooling trade-off, with a separate WebView2 update/bridge obligation |
| TECH-IDENTITY-001 — accounts | ASP.NET Core Identity native accounts within the monolith | Future company login or maintained OIDC provider only when protocol/requirements/ownership are established | No public signup; account workflows and revocation still need design. Built-in bearer tokens are not OAuth/OIDC; native session qualification remains open |
| TECH-FILES-001 — Artifacts | Private immutable content-addressed filesystem Adapter, server-only access | Private object-storage Adapter if shared/multi-node capacity or existing managed operations justify another dependency | Must qualify durable writes, digest, atomic naming, concurrent deduplication, capacity and coordinated backup; not a user SMB share or physical WORM guarantee |
| TECH-HOST-001 — server OS | Evaluate Ubuntu Server 24.04 LTS with IT first | Windows Server 2025 when operator skills, support and licensing make it safer to maintain | Company decision outstanding; Windows design PCs do not determine server OS. No unsupported-OS or exact sizing claim |
| TECH-OPS-001 — topology | Single server/VM candidate; separate backup failure domain; limited outbox/worker concurrency | Separate DB/file/worker hosts or stronger availability if measured needs/recovery results require it | One server remains an outage point; not a demonstrated 50–100-concurrent-user configuration |
| TECH-FORMAT-001 — format runtime | Isolated external runner, exact versioned profiles; IRONCAD first deep profile | Add tools/profiles only after entitlement and conformance evidence | OS/license/resources can require a Windows worker independent of the main server; never an in-CAD add-in |

Sources and licensing/support detail are retained in the
[2026-09-03 primary-source note](../../../research/2026-09-03-idea-tech-stack-primary-sources.md).
The note documents .NET 10 support to 2028-11-14, .NET 8 to 2026-11-10, PostgreSQL 18 to 2030-11-14,
actual provider-major dependencies, and the separate EF10 page date of 2028-11-10. Resolve the
source-date discrepancy before adopting an upgrade calendar; do not silently promise the longer date.

.NET has no use charge, but official Windows binaries are not uniformly MIT. PostgreSQL/Npgsql
and EF/React/TypeScript/Vite carry their respective licenses; dependency trees, tooling, Windows,
WebView2 and CAD/Office products need an actual inventory. No company entitlement or total-cost
estimate is asserted. Vite and WebView2 have update obligations separate from .NET LTS.

The selected .NET 10 OS matrix lists Ubuntu 24.04 and Windows Server 2025. Canonical currently lists
24.04 standard security maintenance through May 2029. More recent OS releases are not automatically
supported by the chosen component combination. Pin exact major/minor/patch, installer, runtime,
dependency lockfiles, license notices and supported environment at qualification.

WebView2 Evergreen is preferred if IT supports managed updates and compatibility testing; a Fixed
Version requires explicit patch ownership and redistribution review. The native host must preserve
local candidates during restart/update. Browser/renderer credentials and native Workspace session
proof stay in their respective protected contexts; a shared UI does not imply a shared auth token.

No additional Adapter/service abstraction is created solely for a possible future provider. Use
small owned Interfaces at the file-store, authentication, format and client boundaries where
variation or a genuine security seam already exists; defer unused integrations.

## 12. Decisions, risks and constraints

| Record | ID | Decision/risk/constraint | Owner / treatment | Status |
|---|---|---|---|---|
| Accepted ADR | `IE-ADR-C1-001` | C1 remains independently useful and evolves from PDM to PLM before any platform dependency. | Architecture owner; preserve stable contracts without premature distributed design. | `Accepted` |
| Accepted ADR | `IE-ADR-C1-002` | No IDEA code runs inside design applications. | Desktop/Workspace/Format designs keep all execution external. | `Accepted` |
| Accepted ADR | `IE-ADR-C1-003` | Start the Server as a modular monolith with deep Modules. | Enforce Interface/schema ownership; split only on evidence. | `Accepted` |
| Accepted ADR | `IE-ADR-C1-004` | Immutable Generations and atomic Check-in Change Sets. | Transaction, staging, digest and idempotency design. | `Accepted` |
| Accepted ADR | `IE-ADR-C1-005` | Reservation binds document, actor, Workspace, lease and expected Generation. | Optimistic concurrency and explicit recovery; no binary auto-merge. | `Accepted` |
| Accepted ADR | `IE-ADR-C1-006` | Generic file control plus external Format Intelligence. | Versioned Capability Profiles and isolated Adapters. | `Accepted` |
| Proposed decision | `IE-ADR-C1-008` | Separate operational settings, governed policies and solution changes. | Product Decision Authority must approve the boundary/defaults before reliance. | `Proposed`; Tech input only |
| Tech choices | `TECH-STACK-001` and section 11 decision IDs | Choose each proposed component/topology or require a justified alternative; not a pre-approved bundle. | Product Decision Authority at Tech decision. | `NOT-RUN` |
| Risk | `ARCH-RSK-001` | Planning context is confirmed, but IT allowlist, exact host/browser/CAD versions, license entitlements, support ownership and measured workload remain unknown. | Project user coordinates system management/technical support before final deployment qualification. | `PARTIALLY CLARIFIED`; no company deployment approval |
| Risk | `ARCH-RSK-002` | One author is also reviewer; architecture/security/operations specialist review is unavailable. | Record the limitation; assign review before any gate requiring independence. | `BLOCKED` |
| Risk | `ARCH-RSK-003` | Exact IRONCAD profile/tool version and isolated-processing entitlement are unknown. | Run a bounded non-production spike after exact environment/version is identified. | `BLOCKED` |
| Risk | `ARCH-RSK-004` | One Proposed source decision describes broader workflow-design scope than the current Core v0 Feature boundary. | The current instance follows the user-reviewed Feature Draft: seeded configurable workflow is required and a full graphical designer is deferred; Product Decision Authority resolves the source difference in the Feature decision. | `OPEN`; does not authorize the deferred feature |
| Risk | `ARCH-RSK-005` | Native account issuance/reset can be abused; account suspension may leave old sessions usable under library defaults. | Account Administrator plus assigned security reviewer; current-session checks, recovery controls and VVP-015 before live accounts. | `OPEN`; specialist unassigned |
| Risk | `ARCH-RSK-006` | Browser/native bridge exposes local work if origin, session or path validation fails. | Desktop/Workspace owner; narrow messages and VVP-009/011 before enabling bridge. | `OPEN` |
| Risk | `ARCH-RSK-007` | One operator/server and mismatched DB/file backups could make recovery targets unattainable. | User coordinates backup operator/storage and executes VVP-013/014 before rollout; revise topology if unsuccessful. | `OPEN`; targets unqualified |
| Risk | `ARCH-RSK-008` | Separate framework, OS, renderer, dependency and format-tool lifecycles create patch/license work. | Technical owner + IT; inventory, compatibility tests and upgrade budget before component pin. | `OPEN` |
| Constraint | `ARCH-CON-001` | Full graphical workflow design, bulk migration, general external integration and multisite behavior are outside Core v0. | Preserve configuration/interfaces without implementing deferred capability. | `Draft boundary` |

## 13. Verification and gate readiness

| Gate / verification item | Required evidence | Result |
|---|---|---|
| Feature prerequisite | Product Decision Authority decision on `FEATURE-001@0.5` | `NOT-RUN` |
| Spec prerequisite | Approved exact Spec baseline and resolved/owned requirement gaps | `NOT-RUN`; `SPEC-001@0.6` is Draft |
| Requirement consistency | Architecture traces every response to DOC-04 and does not weaken negative paths | Trace authored; review `NOT-RUN` |
| PG3 architecture review | Context, views, Hosts, Modules, Interfaces, quality responses, data, deployment, security, risks and ADR status | Draft authored; review `NOT-RUN` |
| Technology comparison | At least one realistic alternative plus lifecycle, licensing, skills, deployment and operations facts | Independent decisions compared; context confirmed, actual company deployment/license/skills and qualification gaps remain |
| Technical spikes | Transaction/fault injection, accounts/revocation, Desktop bridge, Workspace transfer/recovery, exact format profile and timed restore feasibility | Planned through VVP; execution `NOT-RUN` |
| Increment readiness | DOC-07 pins bounded scope, tests, migration/recovery and rollback after approved Feature/Spec/Tech | `BLOCKED` until decisions pass |
| Change impact | CHG/Work Item covers requirement, data, interface, UX, security, test, operation and release impact | [IE-CHG-TECH-001](registers/CHG-2026-09-03-tech-context-and-proposal.md) records this change; review/closure remains open |

## 14. Typed trace, supporting records and rendition controls

| Link type | Target and purpose | Result |
|---|---|---|
| `SOURCE-NEED` / `SOURCE-DECISION` | DOC-04 requirements; accepted ADRs; approved Feature/Spec decisions | Requirements/ADRs linked; Feature/Spec decisions `NOT-RUN` |
| `SOURCE-EVIDENCE` | DOC-02 options, DOC-06 data contracts, DOC-08 interaction design and official technology lifecycle sources | Draft sources and confirmed planning context linked; target operational/IT evidence still missing |
| `DOWNSTREAM` | DOC-06 realization constraints, DOC-07 increments, DOC-08 surfaces and future implementation contracts | Architecture response authored; downstream reconciliation required on change |
| `CHANGE` | CHG with architecture, data, interface, UX, risk, tests, operations and release impact | `IE-CHG-TECH-001`; prior source bytes retained; no implementation authorization |
| `VERIFICATION` | VVP/VEV requirement, quality, security, recovery, format and interaction evidence | VVP Draft exists; execution `NOT-RUN` |
| `RELEASE` | REL exact source/technology/build baseline and authorized scope | `NOT APPLICABLE` at analysis/design stage |
| `RENDITION` | Source-pinned DOCX/PDF with current/stale/superseded/withdrawn state | No rendition created |

An architecture statement cannot override DOC-04. A technology selection cannot silently add a
Feature or weaken acceptance/failure behavior. Any changed source baseline makes an earlier Tech
brief/rendition stale until its manifest and impact are reviewed.

<!-- AUTHOR CONTENT END -->

## Contract references

- [Core document catalogue](../../../../specs/003-controlled-documentation/contracts/document-catalogue.md)
- [Evidence and trace](../../../../specs/003-controlled-documentation/contracts/evidence-and-trace.md)
- [Gate package](../../../../specs/003-controlled-documentation/contracts/gate-package.md)
- [Project domain language](../../../../CONTEXT.md)
