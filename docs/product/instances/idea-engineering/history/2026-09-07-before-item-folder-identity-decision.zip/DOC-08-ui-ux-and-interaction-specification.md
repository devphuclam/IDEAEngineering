# IDEA Engineering Core v0 UI/UX and Interaction Specification

> **Instance state**: controlled `Draft 0.3`. This document defines proposed user journeys,
> information architecture, interaction states, accessibility and localization obligations. The
> accepted HTML prototype is design evidence only; it is not a production UI or conformance result.

## Control envelope

| Field | Recorded value |
|---|---|
| Stable Document ID | `IE-PROD-UX-001` |
| Document Class | `DOC-08` |
| Title | IDEA Engineering Core v0 UI/UX and Interaction Specification |
| Owner | `Principal Product Author`; named product/design owner is `BLOCKED` before `Proposed` |
| Document Status | `Draft` |
| Document Version | `0.3` |
| Applicable Baseline | `IDEA-C1-ANALYSIS-DESIGN-001`; `IE-SPEC-CORE-V0-001@0.3` |
| Effective Date | `NOT APPLICABLE` until approval |
| Authors / Reviewers | Principal Product Author (assistant prepares) / project user (internal document review); required HCD, accessibility, Vietnamese and Japanese reviewers are not assigned |
| Approvers | Product Decision Authority for Spec/Tech as applicable; decisions `NOT-RUN` |
| Source Links | [DOC-03](DOC-03-business-requirements.md), [DOC-04](DOC-04-software-requirements-specification.md), [HTML prototype](../../../../prototypes/controlled-document-workspace.html), [standards register](../../../governance/standards-register.md) |
| Downstream Links | [DOC-05](DOC-05-architecture-description.md), [DOC-06](DOC-06-data-integration-and-migration-specification.md), [DOC-07](DOC-07-mvp-roadmap-and-delivery-plan.md), [VVP](registers/VVP-core-v0-verification-validation-plan.md), future UI implementation/VEV |
| Evidence / Claim Status | User-reviewed prototype direction; requirements/design are `Draft`; usability/accessibility/locale execution `NOT-RUN` |
| Change History | 0.3: show one Version within Revision and the exact Generation; remove Version Sequence from the UI and prototype through [IE-CHG-VERSION-001](registers/CHG-2026-09-04-version-model-clarification.md). 0.2 added account/login/recovery tasks. |
| Access Classification | `INTERNAL`; prototype uses synthetic data only |
| Retention Rule | Retain with the requirements/design baseline; exact organizational period `UNKNOWN`, owner Product Decision Authority, trigger before `Approved` |
| Content State | `COMPLETE CONTROLLED DRAFT` with explicit user-population and specialist-review gaps |

<!-- AUTHOR CONTENT START -->

## 1. Users and operating context

| Role / context | Goal and task | Environment / device | Accessibility or language need | Evidence / population status |
|---|---|---|---|---|
| Design Engineer | Find a Product Definition, Checkout/Reference files, open external application, understand change status and Check-in safely. | Company Windows desktop; browser and Desktop surface; common Office/CAD applications. | Keyboard and pointer; `en`/`vi`/`ja`; clear conflict/recovery wording. | Role accepted; representative users/project `BLOCKED`. |
| Reviewer / Approver | See exact Revision/Generation/Structure, inspect files/evidence, approve or reject with reason. | Primarily Web; possible Web-rendered Desktop. | Dense but readable evidence, keyboard navigation, no ambiguous action state. | Role accepted; eligible independent participant `BLOCKED`. |
| Release Authority | Confirm complete exact Release Scope and respond to blockers. | Web/Desktop according to policy. | Clear scope differences, blocking reason and irreversible-action confirmation. | Named authority `UNKNOWN`. |
| PDM Administrator | Configure metadata, numbering, access, workflow, locale and format policies. | Web administration surface; not part of the Core v0 item-workspace prototype. | Understand effect/version before activation. | Detailed admin UI deferred; representative administrator `UNKNOWN`. |
| Account Administrator | Issue/suspend accounts and assist recovery; inspect account-only authority and retain attribution. | Web account-administration surface, separate from document policy administration. | Plain account status and consequences; keyboard/locale support; no display of existing passwords. | Project user performs initial duty per TECH-CTX-004; security policy/visual design unqualified. |
| Quality / Auditor | Follow Audit, decisions, structure and Release evidence without changing product state. | Web read-only detail views/export. | Findability, exact identities, timestamp/actor context. | Specialist participant `BLOCKED`. |
| Product Decision Authority | Review Feature/Spec/Tech briefs and demonstrations without navigating the complete engineering UI. | Boss-facing brief and guided demo. | Plain language with technical terms explained; decision boundary visible. | Role assigned; decision identity not yet recorded. |

The canonical design viewport is 1440×900. This is a repeatable demo/verification baseline, not yet
the minimum supported production device. Exact production viewport, browser versions, display scale,
assistive technology and corporate device inventory are `UNKNOWN`; owner Product Decision Authority
with HCD/IT input, trigger before Spec approval for mandatory support and before rollout for evidence.

## 2. Journey and task-flow model

| Journey / task ID | Trigger and preconditions | Steps and decision points | Success / failure outcome | Requirement / evidence trace |
|---|---|---|---|---|
| `UX-JRN-001` Find and inspect item | Authorized user opens My Work or a Product context. | Expand/collapse tree groups; select item; read identity/state/next action; open detailed files/structure/Audit only when needed. | Selected item is unambiguous; tree position remains; unavailable data shows empty/error state. | `REQ-UX-001/002/003/004/005` |
| `UX-JRN-002` Checkout or Reference scope | User selects a root and requests work. | System previews root/related documents and each proposed mode; user changes/accepts exact scope. | Workspace Manifest is created only for confirmed scope; conflict lists blocked entries and supports reconfirmation. | `REQ-WS-001`…`REQ-WS-004` |
| `UX-JRN-003` Check-in work | User returns after saving in external application. | Full scan shows changed/unchanged/unreserved/missing/out-of-date entries; user resolves blockers and confirms. | Changed scope publishes atomically; No Change creates no Generation; success ends Checkout. | `REQ-WS-005`…`REQ-WS-009` |
| `UX-JRN-004` Resolve Out-of-date work | Check-in detects a newer server Generation or invalid owner/Workspace. | Show expected/current Generation, local-work safety and allowed actions; user refreshes baseline, compares and reapplies deliberately or uses governed recovery. | No overwrite; local candidate remains; user reaches valid new scope or exits safely. | `REQ-WS-010/011/013` |
| `UX-JRN-005` Review, approve and release | Exact complete baseline is submitted and actor is eligible. | Inspect overview/files/structure/Audit; approve or reject with reason; preview Release Scope; confirm Release. | Valid scope releases atomically; missing role/evidence/stale dependency blocks and explains why. | `REQ-LC-001`…`REQ-LC-008` |
| `UX-JRN-006` Create next Revision | Released item requires controlled change. | Select Create Revision; show predecessor/new Revision and reused baseline; confirm reason/policy. | New Revision starts separately; predecessor/release remains unchanged. | `REQ-LC-009` |
| `UX-JRN-007` Inspect secondary detail | User opens files, relationships, full Audit, properties or diagnostic state. | Open drawer/modal/dedicated view; filter/scroll only the same data type; close with button/Escape and restore focus. | Main workspace position and selected item remain unchanged; overflow does not distort table/layout. | `REQ-UX-004/006` |
| `UX-JRN-008` Change language | User selects `en`, `vi` or `ja`. | Persist preference; reload product-controlled resources; use English fallback for missing key. | Identity/state/permission does not change; authored Unicode remains unchanged. | `REQ-LOC-001`…`REQ-LOC-003` |
| `UX-JRN-009` Provision or suspend account | Current actor holds account-administration permission; target Organization/account is explicit. | Show account identity/status and allowed operations; issue setup/reset proof via approved channel; explain suspension and last-recovery-path consequences before confirmation. | Outcome is audited; existing passwords hidden; no implicit document access; last recovery path cannot be removed without a governed replacement. | `REQ-IAM-002/003/005/007`; `VVP-015` |
| `UX-JRN-010` Sign in, recover or reauthenticate | User has an issued native IDEA account; protected request requires valid session. | Sign in/out or use approved one-use recovery; explain expired/ineligible session and ask for fresh proof; preserve selected context and local work. | No public signup or mandatory company-login step; revoked session is refused, not hidden by a UI-only state; candidate files are not deleted. | `REQ-IAM-001/003/004/006`; `VVP-015` |

## 3. Information architecture and navigation

The primary screen is an engineering item workspace, not a dashboard containing every possible
detail. It follows an explorer pattern with one selected item and progressive disclosure.

| Area / object | Hierarchy and entry point | Findability / labeling rule | Cross-document authority link | Status |
|---|---|---|---|---|
| Application shell | Product name, common menu, locale and signed-in account controls. Demo actor switching and boss-demo entry remain prototype-only. | Avoid repeated titles; show real sign-in/out and account eligibility without implying demo actor selection is authentication. | DOC-05 host/surface view; `REQ-IAM-001/004` | `Draft` |
| Context bar | My Work → Product context → selected Logical Document. | Each breadcrumb changes context; group labels such as Product Definition are navigation categories, not document identities. | `REQ-ID-001/002`; DOC-06 | `Draft` |
| Item navigator | Product tree with collapsible Product Definition, CAD artifacts and Controlled records groups. | Group and document-family icons differ; every icon has a text label; collapse/expand is operable. | `REQ-UX-005`; Product Structure | `Draft` |
| Item header | Title, Stable ID, class, Revision, Version, Generation and lifecycle state. | Each field appears once. Version is the user-facing number inside the Revision; Generation is the exact technical snapshot. The UI does not show a duplicate Version Sequence field. | `REQ-ID-001/002` | `Draft` |
| Command bar | Only the currently relevant primary actions plus `More actions`. | Use task names such as Checkout, Check-in, Update information, Submit for review and Release; disabled commands explain why. | `REQ-UX-002`; policy/action query | `Draft` |
| Next-action strip | One recommended next step and, when unavailable, one neutral waiting/blocking explanation. | Red is reserved for actual error/destructive risk; normal waiting for another role uses neutral/amber styling. | `REQ-UX-002` | `Draft` |
| Primary tabs | Overview, Files, Structure, Lifecycle; Audit summary remains visible in the right rail and full Audit opens as detail. | Tabs change same-item work area; they do not duplicate the right-rail summary. | `REQ-UX-003/004` | `Draft` |
| Overview | Key properties, lifecycle and compact relationship summary. | Only decision-relevant values; full properties/relationships open detail. | DOC-06 and DOC-04 | `Draft` |
| Right rail | Control information, counts/shortcuts and recent Audit events. | Shows current edit entitlement, pinned/current Generation, gate/check result and recent events; no generic “evidence” wording without purpose. | `REQ-AUD-001`; `REQ-UX-002/004` | `Draft` |
| Detail drawer/modal | Full files, relationships, Audit, properties, conflict/recovery or confirmation. | One data type per scroll region; column overflow wraps/clamps or scrolls horizontally inside table. | `REQ-UX-004/006` | `Draft` |
| Executive review | Guided demonstration and summary only. | Does not alter authoritative product state or replace the three decision briefs. | DOC-07 decision plan | Prototype-only |

## 4. Interaction states and rationale

| Component / state | Trigger | Visible state and feedback | Keyboard/pointer/assistive behavior | Failure/recovery behavior | Rationale / trace |
|---|---|---|---|---|---|
| Tree group collapsed/expanded | Activate disclosure control. | Arrow direction and child visibility change; selection remains. | Button semantics, `aria-expanded`, Enter/Space; focus stays on toggle. | Failure leaves prior state and announces error if data load is needed. | `UX-JRN-001`; prototype feedback |
| Item selected | Select tree row or linked item. | Highlight row; header, commands, tabs and right rail update to one item. | Focus/selection state announced; pointer target meets approved size. | Load failure preserves tree context and offers retry. | `REQ-UX-002` |
| Action ready | Policy and item state permit action. | Primary action has normal emphasis and clear verb. | Accessible name includes action and item context where needed. | Server revalidation may still refuse safely. | `REQ-GOV-002`; `REQ-UX-002` |
| Action unavailable | Policy/state/evidence prevents action. | Disabled or read-only presentation plus concise reason/required next step; never color alone. | Reason reachable by focus/help text; disabled semantics do not hide explanation. | Refresh/retry only when valid. | `REQ-UX-002/006` |
| Normal wait for role | Item waits for reviewer/approver or another expected actor. | Neutral or amber next-action strip naming the role; not red. | Text announces state/role. | Missing eligible role becomes explicit blocked state. | `REQ-LC-005`; prototype feedback |
| Actual error/conflict | Validation, stale head, wrong owner/Workspace or failed operation. | Error heading, affected scope, what remains safe and allowed actions. | Focus moves to summary; field/table errors linked; no automatic destructive action. | Preserve local work; modal/panel supports refresh/reapply, Save As, retry or recovery. | `REQ-WS-010/011` |
| Checkout success | Server confirms Reservation and materialization. | Edit entitlement shows user/Workspace; Check-in becomes available when appropriate. | Success status announced without stealing focus unnecessarily. | Digest/materialization failure remains not ready and offers retry. | `REQ-WS-002/004` |
| Check-in success / No Change | Server returns terminal result. | New Generation or No Change is shown; edit entitlement is no longer “held” for confirmed scope. | Result and next lifecycle action announced; focus returns to stable command region. | If final response is uncertain, query by OperationId rather than repeat as new operation. | `REQ-WS-008/009/012` |
| Review/Release confirmation | User invokes decision or irreversible release. | Modal shows exact Generation/Revision/scope and consequences; reject requires reason. | Focus trapped within modal; Escape/cancel safe; confirm is explicit. | Revalidation error returns blocking entries without losing entered reason. | `REQ-LC-004/006/007` |
| Detail drawer open | User requests full same-type data. | Drawer overlays right side; background inert; internal list/table scroll only. | Focus moves to heading/first meaningful control and returns to invoker on close. | Load failure stays in drawer with retry/close. | `REQ-UX-004/006` |
| Loading | Data/action pending. | Keep item context, show bounded progress and prevent duplicate destructive submission. | Announce busy state; no focus thrashing. | Timeout/cancel/retry rules are action-specific. | General interaction safety |
| Empty | No files/relations/Audit rows. | Plain statement naming what is empty and, if allowed, how to add/create. | Readable text, not icon-only. | No fabricated placeholder data outside demo. | Prototype feedback |
| Locale fallback | Selected locale lacks a resource. | English text displayed with no change to persisted domain codes. | Accessible name uses displayed fallback. | Missing key is diagnosable; user-authored content unchanged. | `REQ-LOC-001/002` |
| Sign-in/setup/recovery failure | Wrong credentials, expired/used proof or unavailable service. | Plain safe message with retry/recovery path; unauthenticated messages do not disclose whether an account exists. | Focus linked to form/error summary, no secret read-back; keyboard and en/vi/ja resources. | Retain safe form/context data, not secret values in logs; no public signup. | `REQ-IAM-001/003`; `UX-JRN-010` |
| Session revoked/account disabled | Server refuses affected old session or account. | Explain sign-in or administrator contact; clearly state local work is retained and cannot be Check-in while unauthorized. | Accessible status and stable focus; no automatic candidate deletion. | Fresh authorization required; reactivation does not revive old sessions; already downloaded bytes cannot be recalled. | `REQ-IAM-004`; `UX-JRN-010` |
| Account-only administration | Administrator views/changes an account. | Separate account controls from document/approval controls; confirmation identifies target and consequences. | Clear labels and keyboard-accessible confirmation, not color alone. | Denied action or last-admin protection shows recovery guidance without exposing credentials. | `REQ-IAM-002/005/007`; `UX-JRN-009` |

## 5. Surface-specific HCD and accessibility profiles

| Surface profile | Primary interaction boundary | Conditional source/applicability | Manual evidence | Assistive evidence | Known limitation / status |
|---|---|---|---|---|---|
| Desktop | Native shell controlling Workspace, file materialization/open and recovery; may host approved Web-rendered regions. | ISO 9241-210/11/110 tailored; ISO 9241-171 applicability `BLOCKED`. | Keyboard, focus, error/recovery, Windows scaling and OS-association walkthrough. | Windows screen-reader/high-contrast evidence requires assigned specialist/environment. | WPF/.NET 10 is the Tech candidate; toolkit acceptance and assistive baseline unqualified; `NOT-RUN`. |
| Web | Browser item/review/admin surfaces. | ISO HCD sources tailored; WCAG 2.2 and WAI-ARIA conditional applicability remain `BLOCKED` pending approved scope. | Keyboard-only, zoom/reflow, focus, table/drawer/dialog and error-state procedures. | Screen-reader/browser matrix `UNKNOWN`; specialist `BLOCKED`. | No conformance claim; `NOT-RUN`. |
| Web-rendered Desktop | Browser semantics inside the Desktop-hosted rendered region; native shell responsibility remains separate. | Web sources apply only to rendered region; native boundary documented separately. | Cross-boundary focus, keyboard, scaling and dialog/drawer behavior. | Combined native/browser assistive behavior requires exact toolkit/runtime. | WPF-hosted WebView2 is the Tech candidate, not an approved selection; `NOT-RUN`. |

Common design rules:

- keyboard access and visible focus for every action;
- native semantic elements before custom ARIA;
- accessible name and state for icon-only or disclosure controls;
- text plus shape/icon/state, never color alone;
- focus preservation across tree selection, tabs, drawer/modal open/close and errors;
- error message states what failed, what remains safe and the allowed next action;
- tables wrap, clamp or scroll inside their data region without distorting the page;
- touch/pointer target and text-size thresholds remain subject to the approved accessibility profile.

## 6. Locale Profile matrix

The controlled source and field vocabulary remain English. The same locale keys and product-state
codes serve all surfaces; translations are resources, not business rules.

| Cell ID | Locale | Surface | Resource catalogue | English fallback | Locale review status | Persisted preference | Unicode / Japanese input and search evidence | Cross-locale parity result |
|---|---|---|---|---|---|---|---|---|
| `en-desktop` | `en` | Desktop | One versioned catalogue | Required | Source review required | Required | Unicode round-trip | `NOT-RUN` |
| `en-web` | `en` | Web | Same key catalogue | Required | Source review required | Required | Unicode round-trip | `NOT-RUN` |
| `en-web-rendered-desktop` | `en` | Web-rendered Desktop | Same key catalogue | Required | Source review required | Required | Unicode round-trip | `NOT-RUN` |
| `vi-desktop` | `vi` | Desktop | Same key catalogue | Required | Vietnamese reviewer `BLOCKED` | Required | Vietnamese/Unicode round-trip | `NOT-RUN` |
| `vi-web` | `vi` | Web | Same key catalogue | Required | Vietnamese reviewer `BLOCKED` | Required | Vietnamese/Unicode round-trip | `NOT-RUN` |
| `vi-web-rendered-desktop` | `vi` | Web-rendered Desktop | Same key catalogue | Required | Vietnamese reviewer `BLOCKED` | Required | Vietnamese/Unicode round-trip | `NOT-RUN` |
| `ja-desktop` | `ja` | Desktop | Same key catalogue | Required | Japanese reviewer `BLOCKED` | Required | IME, normalization, width, search, font fallback, line breaking | `NOT-RUN` |
| `ja-web` | `ja` | Web | Same key catalogue | Required | Japanese reviewer `BLOCKED` | Required | IME, normalization, width, search, font fallback, line breaking | `NOT-RUN` |
| `ja-web-rendered-desktop` | `ja` | Web-rendered Desktop | Same key catalogue | Required | Japanese reviewer `BLOCKED` | Required | IME, normalization, width, search, font fallback, line breaking | `NOT-RUN` |

## 7. Component and semantic contracts

| Component / pattern | Semantic role and name | Inputs / outputs | State and error contract | Requirement / architecture trace | Status |
|---|---|---|---|---|---|
| Item Tree | Navigate Product context, group and Logical Document. | Input hierarchy/selection; output selected `DocumentId`. | Collapsed/expanded/loading/empty/error/selected; group icon differs from document-family icon. | `REQ-UX-002/005`; Product Structure/Discovery query | `Draft` |
| Identity Header | Show one selected item's exact identity/lifecycle coordinate. | Document summary query. | Read-only; unavailable field is `—` with accessible label, never guessed. | `REQ-ID-001/002` | `Draft` |
| Command Bar | Invoke allowed item commands. | Allowed-action query plus command input; terminal/blocked result. | Relevant actions first; disabled reason; double-submit protection. | `REQ-GOV-002`; `REQ-UX-002` | `Draft` |
| Next Action | Explain the next expected user/role action. | Current state, allowed actions, blockers. | Ready, normal wait, blocked, error and completed presentation; red only for error/risk. | `REQ-UX-002`; `REQ-LC-005` | `Draft` |
| Scope Editor | Preview and confirm Checkout, Check-in or Release membership. | Candidate rows with mode/status; confirmed exact scope. | Add/remove/reconfirm; blocked/unresolved visible; no hidden cascade. | `REQ-WS-001/006`; `REQ-LC-006` | `Draft` |
| Conflict Panel | Explain failed publish/recovery options. | Expected/current Generation, owner visibility, Workspace/local state, actions. | Preserves candidate; no automatic binary merge; each action states consequence. | `REQ-WS-010/011/013` | `Draft` |
| State Badge | Compact lifecycle/readiness/operation state. | Locale-neutral code to translated label. | Text and non-color cue; one meaning across surfaces. | `REQ-UX-001/005`, `REQ-LOC-002` | `Draft` |
| Detail Drawer | Show one secondary collection without leaving context. | Files, relationships, Audit or properties query. | Loading/empty/error/data; internal scroll; focus return. | `REQ-UX-004/006` | `Draft` |
| Decision Modal | Confirm approve/reject/release/recovery operations. | Exact scope/pins, reason and policy consequence. | Cancel safe; required reason; server revalidation errors preserved. | `REQ-LC-004/006/007`; `REQ-UX-006` | `Draft` |
| Audit Timeline | Read attributable events in time order. | Evidence records authorized for actor. | Recent compact right rail; full detail drawer; restricted fields withheld. | `REQ-AUD-001/002` | `Draft` |
| Locale Selector | Choose product UI locale. | `en`/`vi`/`ja`; persisted preference. | English fallback; no domain-state change. | `REQ-LOC-001/002/003` | `Draft` |
| Account Session | Sign in/out, setup/recovery and reauthentication on each applicable surface. | Native-account/session result; never expose passwords or native tokens to rendered JavaScript. | Ready/loading/error/expired/disabled; preserve local candidates and distinguish account from document rights. | `REQ-IAM-001/003/004/006`; `UX-JRN-010` | `Draft` |
| Account Administration | Account-only list/detail and controlled issue/suspend/recovery actions. | Stable target Actor/account, permitted action and explicit confirmation. | No open signup, password read-back or hidden grant of document rights; last-recovery-path safeguard. | `REQ-IAM-002/003/005/007`; `UX-JRN-009` | `Draft` |

Components use one shared semantic contract across surfaces, but a future native Desktop adapter and
Web adapter may render it differently. The interface includes state, errors, focus and authorization
meaning; it is not only a visual component signature.

The existing item-workspace HTML does not implement these account tasks. The new rows specify
behavior to be designed and tested later; they do not change or claim screenshots from that prototype.
A single account does not promise cross-surface SSO. Web-rendered regions and native Workspace
sessions have distinct security boundaries; focus/session recovery must be qualified across them.

## 8. Usability objectives and evaluation

| Objective ID | User outcome / metric | Method and environment | Participant population | Reviewer independence / competence | Result |
|---|---|---|---|---|---|
| `UX-OBJ-001` | At 1440×900, selected identity, primary command, next action and overview are usable without page-level vertical scroll. | Browser capture plus task walkthrough on exact prototype/build. | Project user for initial internal review; representative engineer later. | HCD competence not assigned. | `NOT-RUN` against this Draft |
| `UX-OBJ-002` | User can identify Stable ID, Revision, Version, Generation, state and current edit entitlement without opening secondary detail. | Five-field identification task and error count. | At least one intended engineer before internal pilot acceptance. | Representative population `BLOCKED`. | `NOT-RUN` |
| `UX-OBJ-003` | User can explain Checkout versus Reference and knows that successful Check-in ends Checkout. | Scenario questions plus Checkout/Check-in task. | Intended engineer/reviewer. | Population `BLOCKED`. | `NOT-RUN` |
| `UX-OBJ-004` | On Out-of-date conflict, user can state what failed, which work is safe and the correct next action without losing the candidate. | Stale-conflict walkthrough and before/after digest evidence. | Intended engineer; test identities may support technical verification only. | Representative acceptance `BLOCKED`. | `NOT-RUN` |
| `UX-OBJ-005` | Long file, relationship and Audit data can be inspected without losing selected item or main scroll position. | Drawer/modal focus and navigation task with overflow fixtures. | Keyboard and pointer participants; assistive review later. | Accessibility reviewer `BLOCKED`. | `NOT-RUN` |
| `UX-OBJ-006` | The same core task has equivalent outcome in `en`, `vi`, `ja` with no clipped critical command/state label. | Nine-cell locale task matrix at defined viewport/scale. | English, Vietnamese and Japanese reviewers. | Vietnamese/Japanese assignments `BLOCKED`. | `NOT-RUN` |
| `UX-OBJ-007` | User distinguishes account login/admin from document permissions, can recover safely and understands that session loss does not delete local work. | Provision/sign-in/reset/suspend task plus old-session and local-candidate checks. | Project user as initial admin; representative users and security reviewer later. | HCD/security assignments remain open. | `NOT-RUN` |

The prototype has already received iterative stakeholder feedback on density, duplicate information,
scrolling, drawers, Audit placement, tree controls, terminology, icons, Checkout/Check-in and conflict
wording. That feedback establishes design direction; it is not a measured usability PASS for the
future implementation.

## 9. Deviations, residual risk and gate readiness

| Deviation / risk | Affected surface/cell | Rationale and impact | Owner / expiry or review trigger | Evidence / CHG link | Status |
|---|---|---|---|---|---|
| Canonical viewport is not a production support matrix. | All surfaces | Corporate device/browser/scale inventory is absent. | Product Decision Authority/HCD/IT; before Spec support commitment. | Future environment record | `UNKNOWN` |
| Native Desktop toolkit and Web-rendered approach are proposed, not selected. | Desktop/rendered cells | WPF/WebView2 focus, scaling, protected native bridge, updates and assistive behavior need exact-version qualification. | Architecture/HCD owner; Tech decision. | DOC-05/TECH-001; VVP-009/011 | `BLOCKED` for approval |
| No eligible HCD/accessibility specialist is assigned. | All profiles | Prevents specialist assessment and conformance claim. | Product Decision Authority; before PG3/claim. | Reviewer assignment | `BLOCKED` |
| Vietnamese and Japanese linguistic reviewers are not assigned. | `vi`/`ja` cells | Prevents translation-quality acceptance. | Product Decision Authority; before locale acceptance. | Locale review record | `BLOCKED` |
| Admin/account UI is not represented by the item-workspace prototype. | Web admin and applicable login surfaces | Initial account tasks are now specified; detailed screen design and policy-admin task design still need evaluation. | Principal Product Author; before the corresponding implementation. | UX-JRN-009/010; future detailed DOC-08 work | `OPEN`; required account functionality is not deferred |

| Gate item | Required evidence | Result |
|---|---|---|
| Feature prerequisite | Product Decision Authority decision on `FEATURE-001@0.5` | `NOT-RUN` |
| Requirements trace | Every material interaction obligation links to DOC-04 and DOC-06 | Draft trace complete; review `NOT-RUN` |
| Design trace | Component/surface realization aligns with DOC-05 | DOC-05 Draft authored and source-level reconciliation complete; review `NOT-RUN` |
| HCD/accessibility review | Surface profile, manual/assistive evidence and specialist assessment | `BLOCKED` |
| Locale review | Nine cells specified; catalogue and linguistic evidence executed | Matrix specified; execution `NOT-RUN` |

## Standards applicability and objective evidence

| Surface | Conditional source | Exact edition / scope | Classification | Applicability / tailoring | Evidence expectation | Status |
|---|---|---|---|---|---|---|
| All applicable surfaces | ISO 9241-210:2019, ISO 9241-11:2018, ISO 9241-110:2020 | Context, usability and interaction design for Core v0 tasks | `STANDARD-GUIDED` | `TAILOR` to internal roles, three surfaces and exact journeys | Context/task rationale plus evaluated objectives | Draft mapping; evidence `NOT-RUN` |
| Native Desktop | ISO 9241-171:2025 when lawful source/applicability approved | Native shell and Workspace interaction | `STANDARD-GUIDED` | `BLOCKED` pending source, toolkit and specialist | Manual/assistive evidence | `BLOCKED` |
| Web | WCAG 2.2; WAI-ARIA 1.2 only where native semantics are insufficient | Applicable Web UI regions | `STANDARD-GUIDED, CONDITIONAL` | `BLOCKED` pending approved scope/profile; prefer native semantics | Keyboard, zoom/reflow and screen-reader/browser evidence | `BLOCKED` |
| Web-rendered Desktop | Approved Web sources for rendered region plus native-shell boundary | Rendered region only | `STANDARD-GUIDED, CONDITIONAL` | `BLOCKED` pending Tech surface decision | Cross-boundary manual/assistive evidence | `BLOCKED` |

No row is a conformity claim. Exact technology, source access, reviewer competence, procedures and
retained results are required before any accessibility or usability PASS.

## Typed trace, supporting records and rendition controls

| Link type | Required target and purpose | Result |
|---|---|---|
| `SOURCE-NEED` / `SOURCE-DECISION` | DOC-03 needs, DOC-04 requirements, prototype feedback and approved HCD decision | Draft sources linked; Feature/Spec decisions `NOT-RUN` |
| `DOWNSTREAM` | DOC-05 surface/interface design, DOC-07 increment, VVP/VEV and UI implementation | DOC-05 Draft maps Hosts, Interfaces and surfaces; review `NOT-RUN` |
| `CHANGE` | CHG covering interaction, accessibility, locale, risk, tests and release impact | IE-CHG-TECH-001 records account/Desktop consequences; IE-CHG-VERSION-001 aligns the Version display and prototype transitions without adding production code |
| `VERIFICATION` | VVP/VEV manual, assistive, Unicode and cross-locale task evidence | `IE-VVP-CORE-001@0.3` authored; all execution `NOT-RUN` |
| `RELEASE` | Future REL baseline and approved UI/locale claim scope | `NOT APPLICABLE` to this Draft |
| `RENDITION` | Source-pinned DOCX/PDF identity/status | No rendition generated |

<!-- AUTHOR CONTENT END -->

## Contract references

- [DOC-08 class template](../../definition/DOC-08-ui-ux-and-interaction-specification.md)
- [Core document catalogue](../../definition/README.md)
- [Evidence and trace](../../../../specs/003-controlled-documentation/contracts/evidence-and-trace.md)
- [Validation contract](../../../../specs/003-controlled-documentation/contracts/validation.md)
- [Project domain language](../../../../CONTEXT.md)
